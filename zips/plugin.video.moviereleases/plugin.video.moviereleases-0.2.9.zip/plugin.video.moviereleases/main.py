﻿# -*- coding: utf-8 -*-

import os
import shutil
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


__addon__ = xbmcaddon.Addon()
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')

__cwd__        = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
__profile__    = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode("utf-8")
__resource__   = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'lib')).decode("utf-8")
__temp__       = xbmc.translatePath(os.path.join(__profile__, 'temp', ''))

if xbmcvfs.exists(__temp__):
    shutil.rmtree(__temp__)
xbmcvfs.mkdirs(__temp__)

packages_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
try:
    for root, dirs, files in os.walk(packages_path,topdown=False):
        for name in files :
            os.remove(os.path.join(root,name))
except: pass

class window(xbmcgui.WindowDialog):

    def get_n(self):
        fundal = os.path.join(__cwd__, 'dedicatie_speciala.jpg')
        self.background = xbmcgui.ControlImage(0, 0, 1280, 720, fundal)
        self.addControl(self.background)

disp = window()
disp.get_n()
disp.doModal()
del disp
