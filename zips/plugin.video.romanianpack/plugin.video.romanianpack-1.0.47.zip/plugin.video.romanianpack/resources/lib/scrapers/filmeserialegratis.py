# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'https://filme-seriale.net'

class filmeserialegratis:
    
    thumb = os.path.join(media, 'filmeserialegratis.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'Filme-Seriale.gratis'
    menu = [('Recente', base_url, 'recente', thumb),
            ('Filme', base_url + '/filmeonline/', 'rece', thumb),
            ('Seriale', base_url + '/seriale/', 'rece', thumb),
            ('Episoade', base_url + '/episode/', 'rece', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword):
        return self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')

    def parse_menu(self, url, meniu, info={}):
        lists = []
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta' or meniu == 'rece':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                regex_all = '''data-movie-id="(.+?)"jtip-bottom"'''
                regex_info = '''href="(.+?)".+?oldtitle="(.+?)".+?(?:.+?"mli-quality">(.+?)<)?.+?img data-original="(.+?)".+?(?:.+?(?:IMDB|TMDb):(.+?)<)?.+?(?:.+?tag">(.+?)<)?.+?(?:.+?>Season(.+?)<.+?Episode:(.+?)<)?(?:.+?f-desc">(.+?)<)?(?:.+?ep_title">(.+?)<.+?Serie:.+?>(.+?)<)?'''
                regex_n_v = '''(?:IMDB|TMDb):(.+?)</s.+?type.+?>(.+?)<'''
                if link:
                    for bloc in re.findall(regex_all, link, re.IGNORECASE | re.MULTILINE | re.DOTALL):
                        match = re.findall(regex_info, bloc, re.DOTALL)
                        voturi = re.findall(regex_n_v, bloc, re.IGNORECASE | re.DOTALL)
                        if voturi:
                            rating = striphtml(voturi[0][0]).split("/")[0].strip()
                            votes = striphtml(voturi[0][0]).split("/")[1].strip()
                            post = voturi[0][1]
                        else: rating = None; votes = None; post = ''
                        for legatura, nume, tip, imagine, rating, an, sezon, episod, descriere, nume_episod, nume_serial in match:
                            imagine = imagine.strip()
                            try: imagine = re.findall('url=(.+?)$', imagine)[0]
                            except: pass
                            nume = htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')
                            descriere = htmlparser.HTMLParser().unescape(striphtml(descriere).decode('utf-8')).encode('utf-8')
                            info = {
                            'Title': nume,
                            'Poster': imagine,
                            'Plot': descriere.strip() + ' ' + nume_episod + ' ' + nume_serial,
                            'Year': an,
                            'Rating': '%s' % rating,
                            'PlotOutline': '%s' % (descriere.strip())
                            }
                            if sezon: info['Season'] = sezon.strip()
                            if episod: info['Episode'] = episod.strip()
                            if nume_serial: info['TvShowTitle'] = nume_serial.strip()
                            if nume_episod: info['Title'] = nume_episod.strip()
                            nume = (nume + ' - ' + tip) if tip else nume
                            if '/seriale/' in legatura:
                                lists.append((nume, legatura, imagine, 'get_episoade', info))
                            else:
                                lists.append((nume, legatura, imagine, 'get_links', info))
                match = re.search('"pagination"|"paginador"', link, flags=re.IGNORECASE)
                if match:
                    if '/page/' in url:
                        new = re.findall('/page/(\d+)', url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        if '/?s=' in url:
                            nextpage = re.findall('\?s=(.+?)$', url)
                            nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                        else: nexturl = url + "/page/2"
                    lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_episoade':
            link = fetchData(url)
            regex_season = '''tvseason".+?>Season (\d+)<(.+?)</div>\s+</div>'''
            regex_episode = '''href="(.+?)">\s+Episode\s+(\d+)\s+(?:-(.+?))?<'''
            #regex_all = '''numerando">(\d+ x \d+)<.+?href="(.+?)">(.+?)<.+?date">(.+?)<'''
            season = re.compile(regex_season, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
            info = eval(str(info))
            title = info['Title']
            for seasone, content in season:
                episode = re.compile(regex_episode, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(content)
                #log(episode)
                for legatura, episod, nume_episod in episode:
                    info['TVShowTitle'] = title
                    info['Title'] = '%s S%02dE%02d %s' % (title.decode('utf-8').encode('utf-8'), int(seasone), int(episod), (nume_episod if nume_episod else ''))
                    info['Season'] = seasone
                    info['Episode'] = episode
                    lists.append((striphtml(title + ' ' + str('S%02dE%02d' % (int(seasone), int(episod)))).replace("\n", ""), legatura, '', 'get_links', str(info)))
        elif meniu == 'get_links':
            link = fetchData(url)
            links = []
            regex_lnk = '''<(?:iframe.+?|script(?:\s)?)src=[\'"]((?:[htt]|[//]).+?(?!\.js))["\']'''
            match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
            for host, link1 in get_links(match_lnk):
                if not link1.endswith('.js'):
                    lists.append((host,link1,'','play', info, url))
                
        return lists
              
