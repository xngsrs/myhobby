# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'openpirate.org'

class piratebay:
    
    thumb = os.path.join(media, 'piratebay.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'ThePirateBay'
    build_url = 'https://%s/api?url=/q.php?q=' % base_url
    tracker_list = 'https://%s/static/main.js' % base_url
    menu = [('Recente', "%s%s" % (build_url, quote('category:200')), 'recente', thumb),
            ('Populare', "%s%s" % (build_url, quote('top100:200')), 'get_torrent', thumb),
            ('Filme', "%s%s" % (build_url, quote('category:201')), 'recente', thumb),
            ('Filme DVDR', "%s%s" % (build_url, quote('category:202')), 'recente', thumb),
            ('Filme HD', "%s%s" % (build_url, quote('category:207')), 'recente', thumb),
            ('Filme 3D', "%s%s" % (build_url, quote('category:209')), 'recente', thumb),
            ('Filme altele', "%s%s" % (build_url, quote('category:299')), 'recente', thumb),
            ('Seriale', "%s%s" % (build_url, quote('category:205')), 'recente', thumb),
            ('Seriale HD', "%s%s" % (build_url, quote('category:208')), 'recente', thumb),
            ('Videoclipuri', "%s%s" % (build_url, quote('category:203')), 'recente', thumb),
            ('Clipuri', "%s%s" % (build_url, quote('category:204')), 'recente', thumb),
            ('Handheld', "%s%s" % (build_url, quote('category:206')), 'recente', thumb),
            ('Porn', "%s%s" % (build_url, quote('category:500')), 'recente', thumb),
            ('Porn Movies', "%s%s" % (build_url, quote('category:501')), 'recente', thumb),
            ('Porn Movies DVDR', "%s%s" % (build_url, quote('category:502')), 'recente', thumb),
            ('Porn HD Movies', "%s%s" % (build_url, quote('category:505')), 'recente', thumb),
            ('Porn Clipuri', "%s%s" % (build_url, quote('category:506')), 'recente', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]

    categories = [('Filme', '201'),
               ('Filme DVDR', '202'),
               ('Filme HD', '207'),
               ('Filme 3D', '209'),
               ('Filme Others', '299'),
               ('Seriale', '205'),
               ('Seriale HD', '208'),
               ('Videoclipuri', '203'),
               ('Clipuri', '204'),
               ('Handheld', '206'),
               ('Porn', '500'),
               ('Porn Movies', '501'),
               ('Porn Movies DVDR', '502'),
               ('Porn HD Movies', '505'),
               ('Porn Clipuri', '506')]
    
    def getKey(self, item):
        return item[1]

    def cauta(self, keyword):
        url = "%s%s" % (self.build_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')
    
    def format_bytes(self, size):
        B = float(size)
        KB = float(1024)
        MB = float(KB ** 2) # 1,048,576
        GB = float(KB ** 3) # 1,073,741,824
        TB = float(KB ** 4) # 1,099,511,627,776

        if B < KB:
            return '{0} {1}'.format(B,'Bytes' if 0 == B > 1 else 'Byte')
        elif KB <= B < MB:
            return '{0:.2f} KB'.format(B/KB)
        elif MB <= B < GB:
            return '{0:.2f} MB'.format(B/MB)
        elif GB <= B < TB:
            return '{0:.2f} GB'.format(B/GB)
        elif TB <= B:
            return '{0:.2f} TB'.format(B/TB)

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url, rtype='json')
                if link:
                    try:
                        trackers = fetchData(self.tracker_list)
                        trackers = re.findall('encodeURIComponent\(\'(.+?)\'', trackers)
                        trackers = ''.join([('&tr=%s' % quote(track)) for track in trackers])
                    except: trackers = ''
                    for torrent in link:
                        proceed = False
                        numecategorie = ''
                        category = torrent.get('category')
                        for catname, catnumber in self.categories:
                            if catnumber == torrent.get('category'):
                                proceed = True
                                numecategorie = catname
                                break
                        if proceed:
                            name = torrent.get('name')
                            seeds = torrent.get('seeders')
                            leechs = torrent.get('leechers')
                            size = torrent.get('size')
                            status = torrent.get('status')
                            nume = '%s [COLOR lime]%s[/COLOR]%s (%s) [S/L: %s/%s] ' % (name, status, ((' [COLOR green]%s[/COLOR]' % numecategorie) if numecategorie else ''), self.format_bytes(size), seeds, leechs)
                            info = {'Title': nume,
                                    'Plot': nume,
                                    'Size': size,
                                    'Poster': self.thumb}
                            legatura = 'magnet:?xt=urn:btih:'
                            legatura += torrent.get('info_hash')
                            legatura += '&dn=%s' % (quote(name))
                            if trackers: legatura += trackers
                            else:
                                legatura += '&tr=udp%3A%2F%2Ftracker.coppersurfer.tk%3A6969%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2F9.rarbg.to%3A2920%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337'
                                legatura += '&tr=udp%3A%2F%2Ftracker.internetwarriors.net%3A1337%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2Ftracker.coppersurfer.tk%3A6969%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2Ftracker.pirateparty.gr%3A6969%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2Ftracker.cyberia.is%3A6969%2Fannounce'
                            lists.append((nume,legatura,self.thumb,'torrent_links', info))
        
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
              
