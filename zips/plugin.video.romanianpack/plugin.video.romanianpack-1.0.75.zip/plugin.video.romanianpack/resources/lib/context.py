import sys
import xbmc
import urllib

def ensure_str(string, encoding='utf-8'):
    if isinstance(string, unicode):
        string = string.encode(encoding)
    if not isinstance(string, str):
        string = str(string)
    return string

def quote(string, ret=None):
    string = ensure_str(string)
    try:
        return urllib.quote_plus(string)
    except:
        if ret:
            return ret
        else:
            return string

if __name__ == '__main__':
    base = 'plugin://plugin.video.romanianpack'
    info = sys.listitem.getVideoInfoTag()
    tip = info.getMediaType()
    if tip == 'episode':
        word = quote(info.getTVShowTitle())
        try:
            if info.getSeason(): word = '%s S%02d' % (word, int(info.getSeason()))
        except:
            word = '%s S01' % (word)
        try:
            if info.getEpisode(): word = '%sE%02d' % (word, int(info.getEpisode()))
        except:
            word = '%sE01' % (word)
        url = '%s?action=searchSites&searchSites=cuvant&cuvant=%s' % (base, word)
    elif tip == 'movie':
        url = '%s?action=searchSites&searchSites=cuvant&cuvant=%s' % (base, quote(info.getTitle()))
    xbmc.executebuiltin('Container.Update(%s)' % url)
