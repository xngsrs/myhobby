# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from functions import *
import threading
from resources.lib.scrapers import __all__


#class player(xbmc.Player):
    #def __init__ (self):
        #xbmc.Player.__init__(self)
        
    #def run(self, url, item, params):
        #xbmc.sleep(200)
        #self.totalTime = 0
        #self.currentTime = 0
        #self.total = 0
        #if params.get('landing'): 
            #self.landing = params.get('landing')
            #params.update({'link': self.landing, 'switch' : 'get_links'})
        #else: self.landing = None
        #self.info = params
        #xbmcgui.ListItem(path=url)
        #xbmc.Player().play(url, item)
        #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        #xbmcgui.Window(10000).setProperty('plugin.video.romanianpack', str(url))
        #self.looptime()
        #xbmcgui.Window(10000).clearProperty('plugin.video.romanianpack')
        
        
    #def looptime(self):
        #pname = '%s.player.overlay' % xbmcaddon.Addon().getAddonInfo('id')
        #xbmcgui.Window(10000).clearProperty(pname)
        #for i in range(0, 100):
            #if self.isPlayingVideo(): break
            #xbmc.sleep(1000)
        #while self.isPlayingVideo():
                    #self.totalTime = self.getTotalTime()
                    #self.currentTime = self.getTime()
                    #self.total = ((float(self.currentTime)/float(self.totalTime))*100) if self.currentTime > 0 else 0
                    #xbmc.sleep(2000)
        #xbmcgui.Window(10000).clearProperty(pname)

    #def onPlayBackStopped(self):
        #if self.total > 80 and self.landing and self.totalTime > 1000:
            #Core().watched({'watched' : 'save', 'watchedlink' : self.landing, 'detalii': quote(str(self.info)), 'norefresh' : '1'})
            
    #def onPlayBackEnded(self):
        #self.onPlayBackStopped()


class Core:
    __plugin__ = sys.modules["__main__"].__plugin__
    __settings__ = sys.modules["__main__"].__settings__
    __scriptname__ = __settings__.getAddonInfo('name')
    ROOT = sys.modules["__main__"].__root__
    scrapers = os.path.join(ROOT, 'resources', 'lib', 'scrapers')
    if scrapers not in sys.path: sys.path.append(scrapers)
    media = sys.modules["__main__"].__media__
    create_tables()

    def sectionMenu(self):
        
        self.drawItem('Recente', 'recents', {}, image=self.media + '/search.png')
        for site in __all__:
            imp = getattr(__import__(site), site)
            name = imp().name
            params = {'site': site}
            self.drawItem(name, 'openMenu', params, image=imp().thumb)
        self.drawItem('Favorite', 'favorites', {'site': site, 'favorite': 'print'}, image=self.media + '/search.png')
        self.drawItem('Cautare', 'searchSites', params, image=self.media + '/search.png')
        self.drawItem('Marcate ca vizionate', 'watched', {'watched': 'list'}, image=self.media + '/search.png')

        ListString = 'XBMC.RunPlugin(%s)' % (sys.argv[0] + '?action=%s&action2=%s&%s=%s')
        contextMenu = []

        ##Media
        #CLcontextMenu=[]
        #CLcontextMenu.extend(contextMenu)
        #CLcontextMenu.append((self.localize('Reset All Cache DBs'),
                            #ListString % ('full_download', '', 'url', json.dumps({'action': 'delete'}))))
        #self.drawItem('< %s >' % self.localize('Content Lists'), 'openContent', image=self.ROOT + '/icons/media.png',
                      #contextMenu=CLcontextMenu, replaceMenu=False)

        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)

    def openMenu(self, params={}):
        get = params.get
        site = get('site')
        imp = getattr(__import__(site), site)
        menu = imp().menu
        if menu:
            for name, url, switch, image in menu:
                params = {'site': site, 'link': url, 'switch': switch }
                self.drawItem(name, 'OpenSite', params, image=image)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
        
    def OpenSite(self, params={}, handle=None, limit=None, all_links=[]):
        cm = []
        get = params.get
        switch = get('switch')
        link = unquote(get('link'))
        nume = get('nume')
        site = get('site')
        info = unquote(get('info')) if get('info') else None
        if switch == 'play':
            liz = xbmcgui.ListItem(nume)
            if info: 
                info = eval(info)
                liz.setInfo(type="Video", infoLabels=info); liz.setArt({'thumb': info['Poster']})
            else: liz.setInfo(type="Video", infoLabels={'Title':unquote(nume)})
            import urlresolver
            try:
                hmf = urlresolver.HostedMediaFile(url=link, include_disabled=True, include_universal=False)
                params.update({'info' : info})
                #player().run(hmf.resolve(), liz, params)
                xbmc.Player().play(hmf.resolve(), liz, False)
            except Exception as e: 
                xbmc.executebuiltin('XBMC.Notification("Eroare", "%s")' % e)
        else:
            menu = getattr(__import__(site), site)().parse_menu(link, switch, info)
            count = 1
            if menu:
                for datas in menu:
                    count += 1
                    nume = datas[0]
                    url = datas[1]
                    imagine = datas[2]
                    switch = datas[3]
                    infoa = datas[4]
                    if len(datas) == 6: landing = datas[5]
                    else: landing = None
                    
                    params = {'site': get('site'), 'link': url, 'switch': switch, 'nume': nume, 'info': infoa, 'favorite': 'check', 'watched': 'check'}
                    if not nume == 'Next':
                        if self.favorites(params):
                            nume = '[COLOR yellow]Fav[/COLOR] - %s' % nume
                            cm = [('Șterge din favorite',
                                    'xbmc.RunPlugin(%s?action=favorites&favorite=delete&favlink=%s&nume=%s,)' % (sys.argv[0],
                                                                                                                 quote(url),
                                                                                                                 quote(nume)))]
                        else:
                            cm = [('Adaugă la favorite',
                                    'xbmc.RunPlugin(%s?action=favorites&favorite=save&favlink=%s&nume=%s&detalii=%s,)' % (sys.argv[0],
                                                                                                               quote(url),
                                                                                                               quote(nume),
                                                                                                               quote(str(params))))]
                        if self.watched(params):
                            params['info'].update({'playcount': 1, 'overlay': 7})
                            cm.append(('Marchează ca nevizionat',
                                    'xbmc.RunPlugin(%s?action=watched&watched=delete&watchedlink=%s,)' % (sys.argv[0],quote(url))))
                        else:
                            cm.append(('Marchează ca vizionat',
                                    'xbmc.RunPlugin(%s?action=watched&watched=save&watchedlink=%s&detalii=%s,)' % (sys.argv[0],
                                                                                                                   quote(url),
                                                                                                                   quote(str(params)))))
                        if landing: params.update({'landing': landing})
                        
                    #if switch == 'get_links': self.drawItem(nume, 'OpenSite', params, isFolder=False, image=imagine, contextMenu=cm)
                    if handle: all_links.append(['[COLOR red]%s:[/COLOR] %s' % (getattr(__import__(get('site')), get('site')).name, nume), 'OpenSite', params, imagine, cm])
                    else: self.drawItem(nume, 'OpenSite', params, image=imagine, contextMenu=cm)
                    if limit:
                        if count > int(limit):
                            break
            if not handle:
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
    
    def recents(self, params):
        all_links = []
        threads = []
        for site in __all__:
            imp = getattr(__import__(site), site)
            menu = imp().menu
            if menu:
                for name, url, switch, image in menu:
                    if name.lower() == 'recente':
                        params = {'site': site, 'link': url, 'switch': switch }
                        threads.append(threading.Thread(name=site, target=self.OpenSite, args=(params, '1', '5', all_links)))
                        #self.OpenSite(params, '1', '5')
        [i.start() for i in threads]
        [i.join() for i in threads]
        for nume, action, params, imagine, cm in all_links:
            self.drawItem(nume, action, params, image=imagine, contextMenu=cm)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
    
    def favorites(self, params):
        get = params.get
        action = get('favorite')
        if action == "save":
            save_fav(unquote(get('nume')), unquote(get('favlink')), unquote(get('detalii')))
        elif action == "check":
            check = get_fav(get('link'))
            if check: return True
            else: return False
        elif action == "delete":
            del_fav(unquote(get('favlink')))
        elif action == "print":
            favs = get_fav()
            if favs:
                for fav in favs[::-1]:
                    if fav[0]:
                        cm = [('Șterge din favorite',
                                    'xbmc.RunPlugin(%s?action=favorites&favorite=delete&favlink=%s&nume=%s,)' % (sys.argv[0],
                                                                                                                 quote(fav[0]),
                                                                                                                 quote(fav[1])))]
                        fav_info = eval(fav[2])
                        name = getattr(__import__(fav_info.get('site')), fav_info.get('site'))().name
                        self.drawItem('[COLOR red]%s:[/COLOR] %s' % (name, fav[1]), 'OpenSite', fav_info, contextMenu = cm)
            xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
    
    def watched(self, params):
        get = params.get
        action = get('watched')
        if action == 'save':
            if get('norefresh'): save_watched(unquote(get('watchedlink')), unquote(get('detalii')), '1')
            else: save_watched(unquote(get('watchedlink')), unquote(get('detalii')))
        elif action == 'delete':
            delete_watched(unquote(get('watchedlink')))
        elif action == 'check':
            return get_watched(unquote(get('link')))
        elif action == 'list':
            watch = list_watched()
            if watch:
                for watcha in watch[::-1]:
                    if watcha[0]:
                        watcha_info = eval(unquote(watcha[1]))
                        watcha_ii = watcha_info.get('info').get('title')
                        cm = [('Marchează ca nevizionat',
                                    'xbmc.RunPlugin(%s?action=watched&watched=delete&watchedlink=%s,)' % (sys.argv[0],quote(watcha[0])))]
                        name = getattr(__import__(watcha_info.get('site')), watcha_info.get('site'))().name
                        self.drawItem('[COLOR red]%s:[/COLOR] %s' % (name, watcha_info.get('info').get('Title')), 'OpenSite', watcha_info, contextMenu = cm)
            xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
    
    def searchSites(self, params={}):
        get = params.get
        log('params: ' + str(params))
        if get('landsearch'): landing = get('landsearch')
        else: landing = None
        if get('cautare') == 'sterge':
            del_search(get('cuvant'))
        elif get('cautare') == 'noua':
            keyboard = xbmc.Keyboard('')
            keyboard.doModal()
            if (keyboard.isConfirmed() == False): return
            keyword = keyboard.getText()
            if len(keyword) == 0: return
            else: self.get_searchsite(keyword, landing)
        elif get('cautare') == 'cuvant':
            self.get_searchsite(get('cuvant'), landing)
        elif not get('cautare'):
            cautari = get_search()
            if cautari:
                param_new = params
                param_new['cautare'] = 'noua'
                if get('landsearch'):
                    param_new['landsearch'] = get('landsearch')
                self.drawItem('Căutare nouă' , 'searchSites', param_new, image=self.media + '/search.png')
                for cautare in cautari[::-1]:
                    new_params = params
                    new_params['cuvant'] = cautare[0]
                    new_params['cautare'] = 'cuvant'
                    if get('landsearch'):
                        param_new['landsearch'] = get('landsearch')
                    cm = [('Șterge din căutări',
                                    'xbmc.RunPlugin(%s,)' % (sys.argv[0] + '?action=searchSites&cautare=sterge&cuvant=%s' % quote(cautare[0])))]
                    self.drawItem(unquote(cautare[0]) , 'searchSites', new_params, image=self.media + '/search.png', contextMenu=cm )
            else:
                keyboard = xbmc.Keyboard('')
                keyboard.doModal()
                if (keyboard.isConfirmed() == False): return
                keyword = keyboard.getText()
                if len(keyword) == 0: return
                else: self.get_searchsite(keyword, landing)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)

    def get_searchsite(self, word, landing=None):
        log('word: ' + str(word))
        log('landing: ' + str(landing))
        dp = xbmcgui.DialogProgress()
        dp.create(self.__scriptname__, 'Căutare...')
        threads = []
        result = []
        save_search(quote(word))
        if landing:
            imp = getattr(__import__(landing), landing)
            site_name = imp().name
            total = 1
            imp().cauta(word, result)
        else:
            for i in range(len(__all__)):
            #for site in __all__:
                    site = __all__[i]
                    imp = getattr(__import__(site), site)
                    site_name = imp().name
                    #dp.update(int((100 / float(len(__all__))) * i), site_name, site_name)
                    threads.append(threading.Thread(name=site_name, target=imp().cauta, args=(word, result,)))
            [i.start() for i in threads]
            for i in threads:
                dp.update(1, 'Căutare in:', str(i.getName()))
                i.join()
            total = len(threads)
        current = 0
        log('results: ' + str(result))
        for results in result:
            current += 1
            percent = int((current * 100) / total)
            dp.update(percent, "", site_name, "")
            if results[2]:
                site = results[0]
                site_name = results[1]
                for link in results[2]:
                    nume = link[0]
                    url = link[1]
                    imagine = link[2]
                    switch = link[3]
                    infoa = link[4]
                    params = {'site': site, 'link': url, 'switch': switch, 'nume': nume, 'info': infoa, 'favorite': 'check'}
                    if nume != 'Next' or landing:
                        if self.favorites(params):
                            nume = '[COLOR yellow]Fav[/COLOR] - %s' % nume
                            cm = [('Șterge din favorite',
                                    'xbmc.RunPlugin(%s?action=favorites&favorite=delete&favlink=%s&nume=%s,)' % (sys.argv[0],
                                                                                                                quote(url),
                                                                                                                quote(nume)))]
                        else:
                            cm = [('Adaugă la favorite',
                                    'xbmc.RunPlugin(%s?action=favorites&favorite=save&favlink=%s&nume=%s&detalii=%s,)' % (sys.argv[0],
                                                                                                            quote(url),
                                                                                                            quote(nume),
                                                                                                            quote(str(params))))]
                        self.drawItem('[COLOR red]%s[/COLOR] - %s' % (site_name, nume) if not landing else nume, 'OpenSite', params, image=imagine, contextMenu=cm)
        dp.close()
    def drawItem(self, title, action, link='', image='', isFolder=True, contextMenu=None, replaceMenu=True, action2='', fileSize=0L):
        #log('[drawItem]:'+str((title, action, image, isFolder, contextMenu, replaceMenu, action2, info)))
        """
        setArt(values) -- Sets the listitem's art
         values : dictionary - pairs of { label: value }.
            - Some default art values (any string possible):
                - thumb : string - image filename
                - poster : string - image filename
                - banner : string - image filename
                - fanart : string - image filename
                - clearart : string - image filename
                - clearlogo : string - image filename
                - landscape : string - image filename
                - icon : string - image filename
        example:
                - self.list.getSelectedItem().setArt({ 'poster': 'poster.png', 'banner' : 'banner.png' })
        """
        if isinstance(link, dict):
            link_url = ''
            for key in link.keys():
                if link.get(key):
                    if isinstance(link.get(key), dict):
                        link_url = '%s&%s=%s' % (link_url, key, quote(json.dumps(link.get(key), ensure_ascii=False)))
                    else:
                        link_url = '%s&%s=%s' % (link_url, key, quote(link.get(key)))
            info = link.get('info')
            if info:
                if isinstance(info, str):
                    info  = eval(info)
                if isinstance(info, dict):
                    image = info.get('Poster')
            url = '%s?action=%s' % (sys.argv[0], action) + link_url
        else:
            info = {"Title": title, "plot": title}
            if not isFolder and fileSize:
                info['size'] = fileSize
            url = '%s?action=%s&url=%s' % (sys.argv[0], action, quote(link))
        if action2:
            url = url + '&url2=%s' % quote(ensure_str(action2))
        listitem = xbmcgui.ListItem(title)
        images = {'icon':image, 'thumb':image}
        images = {'icon': image, 'thumb': image,
                  'poster': image, 'banner': image,
                  #'fanart': image, 'landscape': image,
                  #'clearart': image, 'clearlogo': image,
                  }
        listitem.setArt(images)
        if isFolder:
            listitem.setProperty("Folder", "true")
            listitem.setInfo(type='Video', infoLabels=info)
        else:
            listitem.setProperty('isPlayable', 'true')
            listitem.setInfo(type='Video', infoLabels=info)
            listitem.setArt({'thumb': image})
        if contextMenu:
            listitem.addContextMenuItems(contextMenu, replaceItems=replaceMenu)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=isFolder)

    def getParameters(self, parameterString):
        commands = {}
        splitCommands = parameterString[parameterString.find('?') + 1:].split('&')
        for command in splitCommands:
            if (len(command) > 0):
                splitCommand = command.split('=')
                if (len(splitCommand) > 1):
                    name = splitCommand[0]
                    value = splitCommand[1]
                    commands[name] = value
        return commands

    def executeAction(self, params={}):
        get = params.get
        if hasattr(self, get("action")):
            getattr(self, get("action"))(params)
        else:
            self.sectionMenu()

    def localize(self, string):
        #try:
            #return Localization.localize(string)
        #except:
        return string
