# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'https://www.zfilme-online.net'
    
class zfilmeonline:
    
    thumb = os.path.join(media, 'zfilmeonline.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'ZFilme-Online.net'
    menu = [('Recente', base_url, 'recente', thumb), 
            ('Genuri', base_url, 'genuri', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
                

    def cauta(self, keyword, result):
        result.append((self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')))
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + quote(keyword)
        return url

    def parse_menu(self, url, meniu, info={}):
        lists = []
        link = fetchData(url)
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else: 
                link = fetchData(url)
                regex_menu = '''<article(.+?)</art'''
                regex_submenu = '''href=['"](.+?)['"].+?title=['"](.+?)['"].+?src=['"](.+?)['"]'''
                if link:
                    for movie in re.compile(regex_menu, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                        match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                        for legatura, nume, imagine in match:
                            nume = htmlparser.HTMLParser().unescape(nume.decode('utf-8')).encode('utf-8')
                            info = {'Title': nume,'Plot': nume,'Poster': imagine}
                            lists.append((nume, legatura, imagine, 'get_links', info))
                    match = re.compile('"pagination"', re.IGNORECASE).findall(link)
                    match2 = re.compile('nav-previous', re.IGNORECASE).findall(link)
                    if len(match) > 0 or len(match2) > 0:
                        if '/page/' in url:
                            new = re.compile('/page/(\d+)').findall(url)
                            nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                        else:
                            if '/?s=' in url:
                                nextpage = re.compile('\?s=(.+?)$').findall(url)
                                nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                            else: nexturl = url + "/page/2"
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_links':
            link = fetchData(url)
            links = []
            nume = ''
            regex_base = '''var[\s*]s[\d\s=]+\'(.+?)\''''
            reg_id = '''data-singleid="(.+?)"'''
            reg_server = '''data-server="(.+?)"'''
            regex_lnk = r'''(?:<iframe|<script)[\s]src=['"]((?:[htt]|[//]).+?)["']'''
            regex_seriale = '''(?:<h3>.+?strong>(.+?)<.+?href=['"](.+?)['"].+?)'''
            regex_infos = '''detay-a.+?description">(.+?)</div'''
            match_base = re.findall(regex_base, link, re.IGNORECASE | re.DOTALL)
            match_srl = re.findall(regex_seriale, link, re.IGNORECASE | re.DOTALL)
            match_nfo = re.findall(regex_infos, link, re.IGNORECASE | re.DOTALL)
            match_id = re.findall(reg_id, link, re.IGNORECASE | re.DOTALL)
            match_server = re.findall(reg_server, link, re.IGNORECASE | re.DOTALL)
            try:
                mid = list(set(match_id))[0]
                mserver = list(set(match_server))
                for code in mserver:
                    try:
                        get_stupid_links = fetchData('%s/wp-admin/admin-ajax.php' % base_url, data = {'action': 'samara_video_lazyload', 
                                                                                'server': code,
                                                                                'singleid': mid})
                        match_lnk = re.findall(regex_lnk, get_stupid_links, re.IGNORECASE | re.DOTALL)
                        links.append(match_lnk[0])
                    except: pass
            except: pass
            try:
                info = eval(str(info))
                info['Plot'] = (striphtml(match_nfo[0]).strip())
            except: pass
            for host, link1 in get_links(links):
                lists.append((host,link1,'','play', info, url))
        elif meniu == 'genuri':
            link = fetchData(url)
            regex_cat = '''class="cat-item.+?href=['"](.+?)['"\s]>(.+?)<'''
            if link:
                match = re.findall(regex_cat, link, re.IGNORECASE | re.DOTALL)
                if len(match) > 0:
                    for legatura, nume in match:
                        lists.append((nume,legatura.replace('"', ''),'','recente', info))
        return lists
              
