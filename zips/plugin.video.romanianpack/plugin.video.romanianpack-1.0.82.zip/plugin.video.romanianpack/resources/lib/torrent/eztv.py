# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'eztv.io'

class eztv:

    thumb = os.path.join(media, 'eztv.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'EZTV'
    build_url = 'https://%s/api?url=/q.php?q=' % base_url
    tracker_list = 'https://%s/static/main.js' % base_url
    menu = [('Recente', "https://%s/page_0" % (base_url), 'recente', thumb),
            ('Lista Seriale', "https://%s/showlist/" % (base_url), 'showlist', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
    
    headers = {'Host': base_url,
               'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
               'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}

    def cauta(self, keyword):
        url = "https://%s/search/%s" % (base_url, keyword.replace(" ", "-"))
        #url = "https://%s/search/?q1=%s&q2=&search=Search" % (base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                regex_table = '''\<tr\sname="hover"\s+class="forum_header_border"(.+?)\</tr\>'''
                regex_details = '''epinfo"\>(.+?)\<.+?href="(magnet.+?)".+?post"\>(.+?)\<.+?post"\>(.+?)\<.+?end"\>(.+?)\<'''
                link = fetchData(url, headers=self.headers)
                if link:
                    tables = re.findall(regex_table, link, re.DOTALL)
                    if tables:
                        imagine = self.thumb
                        if info:
                            try:
                                info = eval(info)
                                imagine = info.get('Poster') or self.thumb
                            except: pass
                        for table in tables:
                            show = re.findall(regex_details, table, re.DOTALL)
                            if show:
                                nume, legatura, marime, adaugat, seeds = show[0]
                                nume = ensure_str(nume)
                                seeds = striphtml(seeds) if not seeds == '-' else '0'
                                leechs = '0'
                                size = marime
                                nume = '%s [COLOR green]%s[/COLOR] (%s) [S/L: %s/%s] ' % (nume, adaugat, size, seeds, leechs)
                                size = formatsize(marime)
                                info = {'Title': nume,
                                        'Plot': nume,
                                        'Size': size,
                                        'Poster': imagine}
                                lists.append((nume,legatura,imagine,'torrent_links', info))
                        new = re.findall('/page_(\d+)', unquote(url))
                        try: new = new[0]
                        except: new = ''
                        if new:
                            nexturl = re.sub('/page_(\d+)', '/page_%s' % (int(new) + 1), unquote(url))
                        else:
                            nexturl = ''
                        if nexturl:
                            lists.append(('Next', nexturl, self.nextimage, 'recente', {}))
        elif meniu == "showlist":
            regex = '''\<tr\s+name="hover"\>(.+?)\</tr'''
            regex_details = '''img\s+src="(.+?)".+?href="(.+?)".+?\>(.+?)\<.+?post"\>(.+?)\<.+?post".+?\>(.+?)\</td'''
            data = {'showlist_thumbs': "on",
                    'status': ""}
            link = fetchData(url, headers=self.headers, data=data)
            if link:
                tables = re.findall(regex, link, re.DOTALL)
                if tables:
                    for table in tables:
                        show = re.findall(regex_details, table, re.DOTALL)
                        if show:
                            imagine, legatura, nume, status, votes = show[0]
                            imagine = 'https://%s%s' % (base_url, imagine)
                            legatura = 'https://%s%s' % (base_url, legatura)
                            nume = ensure_str(nume)
                            status = striphtml(status).strip()
                            votes = " ".join(striphtml(votes).split())
                            nume += ' [COLOR lime]Status: [/COLOR][COLOR blue]%s[/COLOR] Rating: %s' % (status, votes.strip())
                            info = {'Title': nume,
                                    'Plot': nume,
                                    'Poster': imagine}
                            lists.append((nume,legatura,imagine,'get_torrent', info))
                            
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
              
