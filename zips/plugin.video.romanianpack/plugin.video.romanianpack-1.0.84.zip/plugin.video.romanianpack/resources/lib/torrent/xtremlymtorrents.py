# -*- coding: utf-8 -*-
from resources.functions import *
import tempfile
import cookielib
__settings__ = sys.modules["__main__"].__settings__
import ssl
import hashlib

base_url = 'extremlymtorrents.ws'

class xtremlymtorrents:
    
    thumb = os.path.join(media, 'extremlymtorrents.jpg')
    nextimage = next_icon
    searchimage = search_icon
    cookieJar = None
    name = 'ExtremlyMTorrents'
    username = __settings__.getSetting("ELTusername")
    password = __settings__.getSetting("ELTpassword")
    headers = [('Host', base_url),
               ('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1'),
               ('Referer', 'https://%s/torrents.php' % base_url)]
    
    categorii = [('1080p HD', '15'),
                 ('4K UHD', '40'),
                 ('720p HD', '22'),
                 ('Music Video 4k', '48'),
                 ('Anime-Japanese', '28'),
                 ('BluRay 3D', '16'),
                 ('Bluray HDR', '12'),
                 ('Bollywood', '44'),
                 ('BRRip', '35'),
                 ('CAMRip', '36'),
                 ('Documentaries', '31'),
                 ('DVD', '27'),
                 ('DVDRip', '5'),
                 ('HDTV', '13'),
                 ('Hentai-Manga', '43'),
                 ('Kids-Cartoons', '9'),
                 ('Pack', '21'),
                 ('PDTV-SDTV', '30'),
                 ('Porn-XXX', '11'),
                 ('Porn 4K-XXX', '47'),
                 ('Sport TV', '39'),
                 ('TS-Telesync-HDTS', '38'),
                 ('TV Episode-Season Complete', '10'),
                 ('TV 4K Episodes', '49'),
                 ('TVRip', '41'),
                 ('VideoClip', '24'),
                 ('WebRip-WebDL', '25'),
                 ('X Extern Only Magnet', '42')]
    menu = [('Recente', "https://%s/torrents.php?page=0" % base_url, 'recente', thumb)]
    menu.extend([(x[0], 'https://%s/torrents.php?cat=%s&page=0' % (base_url, x[1]), 'get_torrent', thumb) for x in categorii])
    menu.extend([('Căutare', base_url, 'cauta', searchimage)])
    base_url = base_url
    
    def getKey(self, item):
        return item[1]

    def cauta(self, keyword):
        url = 'https://%s/browse?search=%s&submit=' % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def load_cookie(self):
        cookie=os.path.join(dataPath, self.__class__.__name__+'.txt')
        #log(cookie)
        self.cookieJar = cookielib.MozillaCookieJar(cookie)
        try:
            if os.path.exists(cookie): self.cookieJar.load(ignore_discard=True)
        except:
            log('ExtremLymTorrents [load_cookie]: os.remove(cookie)')
            os.remove(cookie)
            self.cookieJar = cookielib.MozillaCookieJar(cookie)
            
    def clear_cookie(self):
        cookie=os.path.join(dataPath,self.__class__.__name__+'.txt')
        self.cookieJar = cookielib.MozillaCookieJar(cookie)
        if os.path.exists(cookie):
            os.remove(cookie)
            log('[clear_cookie]: cookie cleared')

    def makeRequest(self, url, data={}, headers={}):
        self.load_cookie()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cookieJar))
        # python ssl Context support - PEP 0466
        if 'https:' in url:
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            #log('urllib2.HTTPSHandler(context=ssl_context)')
            opener.add_handler(urllib2.HTTPSHandler(context=ssl_context))

        opener.addheaders = headers
        if 0 < len(data):
            encodedData = urllib.urlencode(data)
        else:
            encodedData = None
        try:
            response = opener.open(url, encodedData, timeout = 10)
        except urllib2.HTTPError as e:
            if e.code == 404:
                log('[makeRequest]: Not Found! HTTP Error, e.code=' + str(e.code))
                return
            elif e.code in [503]:
                log('[makeRequest]: Denied, HTTP Error, e.code=' + str(e.code))
                return
            else:
                log('[makeRequest]: HTTP Error, e.code=' + str(e.code))
                return
        #self.cookieJar.extract_cookies(response, urllib2)
        #log(response.info().get('Set-Cookie'))
        if response.info().get('Content-Encoding') == 'gzip':
            buf = StringIO(response.read())
            decomp = zlib.decompressobj(16 + zlib.MAX_WBITS)
            text = decomp.decompress(buf.getvalue())
        else:
            text = response.read()
        return text

    def login(self):
        headers = [('Host', base_url),
        ('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1'),
        ('Referer', 'https://' + base_url + '/account-login.php'), ('X-Requested-With', 'XMLHttpRequest'), ('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'), ('Content-Type', 'application/x-www-form-urlencoded'), ('Accept-Language', 'ro,en-US;q=0.7,en;q=0.3'), ('Origin', 'https://%s' % base_url)]
        content = self.makeRequest('https://%s/account-login.php' % base_url, headers=headers)
        data = {
            'password': self.password,
            'username': self.username
        }
        log('Log-in  attempt')
        e = ''
        for i in self.cookieJar:
            e += '%s=%s; ' % (i.name, i.value)
        headers.append(('Cookie', e))
        x = self.makeRequest('https://%s/account-login.php' % (self.base_url), data=data, headers=headers)
        if re.search('Access Denied', x):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('ExtremLymTorrents Login Error', 'Parola/Username incorecte')))
            self.clear_cookie()
        else:
            log('LOGGED ExtremLymTorrents')
        self.cookieJar.save(ignore_discard=True)
        for cookie in self.cookieJar:
            if cookie.name == 'pass' or cookie.name == 'uid':
                return cookie.name + '=' + cookie.value
        return False

    def check_login(self, response=None):
        if None != response and 0 < len(response):
            if re.compile('account-login.php').search(response):
                log('ExtremLymTorrents Not logged!')
                self.login()
                return False
            if re.search('Access Denied', response):
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('ExtremLymTorrents Login Error', 'Parola/Username incorecte')))
                self.clear_cookie()
                return False
        return True

    def tempdir(self):
        dirname = xbmc.translatePath('special://temp')
        for subdir in ('xbmcup', 'plugin.video.torrenter'):
            dirname = os.path.join(dirname, subdir)
            if not os.path.exists(dirname):
                os.mkdir(dirname)
        return dirname

    def saveTorrentFile(self, url, content):
        try:
            temp_dir = tempfile.gettempdir()
        except:
            temp_dir = self.tempdir()
        localFileName = temp_dir + os.path.sep + self.md5(url) + ".torrent"
        localFile = open(localFileName, 'wb+')
        localFile.write(content)
        localFile.close()

        return localFileName

    def getTorrentFile(self, url):
        content = self.makeRequest(url, headers=self.headers)
        if not self.check_login(content):
            content = self.makeRequest(url, headers=self.headers)
        return self.saveTorrentFile(url, content)
    
    def clear_title(self, s):
        return striphtml(self.unescape(s)).replace('   ', ' ').replace('  ', ' ').strip()

    def md5(self, string):
        hasher = hashlib.md5()
        hasher.update(string)
        return hasher.hexdigest()

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        yescat = ['15', '40', '22', '48', '28', '16', '12', '44', '35', '36', '31', '27', '5', '13', '43', '9', '21', '30', '11', '47', '39', '38', '10', '49', '41', '24', '25', '42']
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                response = self.makeRequest(url, headers=self.headers)
                if not self.check_login(response):
                    response = self.makeRequest(url, headers=self.headers)
                regex = '''<tr\s+class(.+?)</tr>'''
                if None != response and 0 < len(response):
                    #if re.compile('Not logged in').search(response):
                        #xbmc.executebuiltin((u'Notification(%s,%s)' % ('Extremlym', 'lipsa username si parola din setari')))
                    for block in re.findall(regex, response, re.DOTALL):
                        catname = ''
                        tables = re.findall('(?:<td.+?>(.+?)</td>)', block)
                        if tables and len(tables) == 8:
                            cat = re.findall('/?cat=(.+?)"', tables[0])[0].strip()
                            for n, c in self.categorii:
                                if c == cat:
                                    catname = n
                                    break
                            imagine, nume = re.findall('img\s+src=/(.+?)\s+.+?b>(.+?)</b', tables[1])[0]
                            genre =  re.findall('<br />(.+?)??<', tables[1])[0]
                            tip = ", ".join(re.split(',|\|', genre))
                            legatura = re.findall('href=(download.+?)\s+.+?\((.+?)\)', block)[0]
                            adaugat = striphtml(tables[7])
                            size = striphtml(tables[4]).strip()
                            seeds = striphtml(tables[5]).strip()
                            leechers = striphtml(tables[6]).strip()
                            nume = replaceHTMLCodes(nume)
                            if str(cat) in yescat:
                                #log(r[1] if str(cat)==r[1] else t[1])
                                if re.findall('vip-icon.png', tables[1]):
                                    nume = '[COLOR yellow]VIP[/COLOR] ' + nume
                                if re.findall('3d.png', tables[1]):
                                    nume += ' [COLOR green]3D[/COLOR]'
                                if re.findall('engsub.png', tables[1]):
                                    nume += ' [COLOR green]ENGSub[/COLOR]'
                                if re.findall('rosubbed.png', tables[1]):
                                    nume += ' [COLOR green]ROSub[/COLOR]'
                                if re.findall('sticky.png', tables[1]):
                                    nume += ' [COLOR green]Sticky[/COLOR]'
                                if re.findall('4you.png', tables[1]):
                                    nume += ' [COLOR green]Recommended[/COLOR]'
                                nume += ' [COLOR green]%s[/COLOR]' % catname
                                nume += ' [COLOR green]%s[/COLOR] ' % adaugat
                                nume = '%s (%s) [S/L: %s/%s] ' % (nume, size, seeds, leechers)
                                legatura = 'https://%s/%s' % (self.base_url, legatura[0])
                                imagine = 'https://%s/%s' % (base_url, imagine)
                                #tip = genre or ''
                                #tip = ''
                                size = formatsize(size)
                                info = {'Title': nume,
                                        'Plot': '%s \n%s \n%s' % (tip, catname, nume),
                                        'Genre': tip,
                                        'Size': size,
                                        'Poster': imagine}
                                lists.append((nume,legatura,imagine,'torrent_links', info))
                    match = re.compile('/?page=\d+', re.DOTALL).findall(response)
                    if len(match) > 0:
                        if 'page=' in url:
                            new = re.compile('page=(\d+)').findall(url)
                            nexturl = re.sub('page=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=1')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'torrent_links':
            turl = self.getTorrentFile(url)
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
              
