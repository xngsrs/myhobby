# -*- coding: utf-8 -*-
import re
import sys
import urllib
import urlparse
import xbmc
try: import HTMLParser as htmlparser
except: import html.parser as htmlparser
from resources.functions import *

base_url = 'https://pefilme.com'

class pefilme:
    
    media = sys.modules["__main__"].__media__
    thumb = media + "/pefilme.jpg"
    nextimage = media + "/next.png"
    searchimage = media + "/search.png"
    name = 'PeFilme.com'
    menu = [('Recente', base_url, 'recente', thumb), 
            ('Categorii', base_url, 'genuri', thumb),
            ('Cele mai accesate', base_url + '/cele-mai-accesate-filme/', 'recente', thumb),
            ('Cele mai apreciate', base_url + '/cele-mai-apreciate-filme/', 'recente', thumb),
            ('Top IMdb', base_url + '/top-imdb/', 'recente', thumb),
            ('Etichete', base_url + '/etichete/', 'tags', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
    nextimage = media + "/next.png"
    
    def cauta(self, keyword):
        return self.parse_menu(self.get_search_url(keyword), 'recente')
    
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + urllib.quote_plus(keyword)
        return url

    def parse_menu(self, url, meniu, info={}):
        lists = []
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                keyboard = xbmc.Keyboard('')
                keyboard.doModal()
                if (keyboard.isConfirmed() == False):
                    return
                search_string = keyboard.getText()
                if len(search_string) == 0:
                    return
                link = fetchData(self.get_search_url(search_string))
                meniu = 'recente'
            else: link = fetchData(url)
            regex_menu = '''post".+?href=['"](.+?)['"].+?imdb">(.+?)<.+?data-src=['"](.+?)['"].+?alt="(.+?)"'''
            if link:
                match = re.compile(regex_menu, re.DOTALL).findall(link)
                for legatura, imdb, imagine, nume in match:
                    nume = htmlparser.HTMLParser().unescape(nume.decode('utf-8')).encode('utf-8')
                    info = {'Title': nume,'Plot': nume,'Poster': imagine,'Rating':imdb}
                    lists.append((nume, legatura, imagine, 'get_tabs', info))
                match = re.compile('"current"', re.IGNORECASE).findall(link)
                if len(match) > 0 :
                    if '/page/' in url:
                        new = re.compile('/page/(\d+)').findall(url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        if '/?s=' in url:
                            nextpage = re.compile('\?s=(.+?)$').findall(url)
                            nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                        else: nexturl = url + "/page/2"
                    lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_tabs':
            link = fetchData(url)
            cats = []
            reg_info = '''"infos"(.+?)</div'''
            reg_cat = '''href.+?>(.+?)<'''
            reg_descriere = '''desfilm">(.+?)<(?:div|/div)'''
            descriere = htmlparser.HTMLParser().unescape(striphtml(re.findall(reg_descriere, link, re.IGNORECASE | re.DOTALL)[0]).decode('utf-8')).encode('utf-8').strip()
            for cat in re.findall(reg_info, link, re.IGNORECASE | re.DOTALL):
                cats = re.findall(reg_cat, cat, re.IGNORECASE | re.DOTALL)
            info = eval(str(info))
            info['Genre'] = ', '.join(cats)
            info['Plot'] = descriere
            id_reg = '''post_id[\s]=[\s](.+?);'''
            tabs_reg = '''li.+?id=['"]tab(\d+)["']'''
            get_links = '%s/getTabContent.php?tabNum=%s&id=%s'
            movie_id =  re.compile(id_reg, re.IGNORECASE | re.DOTALL).findall(link)
            movie_tab = re.compile(tabs_reg, re.IGNORECASE | re.DOTALL).findall(link)
            if len(movie_tab) > 0:
                for tab in movie_tab:
                    tab = str(tab)
                    nume = 'Server %s' % tab
                    serv_link = get_links % (base_url, tab, movie_id[0]) 
                    lists.append((nume,serv_link,'','get_links', info))
            else:
                reg_descriere = '''desfilm">(?:.+?script>)?(.+?)<(?:div|/div)'''
                descriere = htmlparser.HTMLParser().unescape(striphtml(re.findall(reg_descriere, link, re.IGNORECASE | re.DOTALL)[0]).decode('utf-8')).encode('utf-8').strip()
                info['Plot'] = descriere
                return self.parse_menu(url, 'get_links', info)
        elif meniu == 'get_links':
            link = fetchData(url)
            regex_lnk = '''iframe.+?src="((?:[htt]|[//]).+?)"'''
            match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
            for link1 in match_lnk:
                if len(re.findall('(//)', link1)) > 1:
                    link1 = re.findall('\?(http.+?)$', link1)[0]
                if 'goo.gl' in link1: link1 = get_redirect(link1)
                if link1.startswith("//"):
                    link1 = 'http:' + link1 #//ok.ru fix
                parsed_url1 = urlparse.urlparse(link1)
                if parsed_url1.scheme:
                    try: import urlresolver
                    except: pass
                    hmf = urlresolver.HostedMediaFile(url=link1, include_disabled=True, include_universal=True)
                    if hmf.valid_url() == True:
                        host = link1.split('/')[2].replace('www.', '').capitalize()
                        info = eval(str(info))
                        lists.append((host,link1,'','play', info))
        elif meniu == 'genuri':
            link = fetchData(url)
            regex_cats = '''navbar2(.+?)</ul'''
            regex_cat = '''href=["'](.*?)['"].+?>(.+?)<'''
            if link:
                for cat in re.compile(regex_cats, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                    match = re.compile(regex_cat, re.DOTALL).findall(cat)
                    for legatura, nume in match:
                        lists.append((nume,legatura.replace('"', ''),'','recente', info))
        elif meniu == 'tags':
            link = fetchData(url)
            regex_cats = '''etichete"(.+?)</ul'''
            regex_cat = '''href=["'](.*?)['"].+?ll>(.+?)</a> -(.+?)<'''
            if link:
                for cat in re.compile(regex_cats, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                    match = re.compile(regex_cat, re.DOTALL).findall(cat)
                    for legatura, nume, numar in match:
                        nume = nume + numar
                        lists.append((nume,legatura.replace('"', ''),'','recente', info))
        return lists
              
