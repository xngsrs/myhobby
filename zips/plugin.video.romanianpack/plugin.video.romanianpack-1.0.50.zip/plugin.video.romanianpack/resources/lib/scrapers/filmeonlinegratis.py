# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'https://filmeonlinegratis.org'

class filmeonlinegratis:
    
    thumb = os.path.join(media, 'filmeonlinegratis.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'FilmeOnlineGratis.org'
    menu = [('Recente', base_url, 'recente', thumb),
            ('Filme', '%s/movies/' % base_url, 'filme', thumb),
            ('Seriale', '%s/seriale/' % base_url, 'filme', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword):
        return self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')

    def parse_menu(self, url, meniu, info={}):
        lists = []
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta' or meniu == 'filme':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                regex_submenu = '''data-movie-id="(.+?)".+?href="(.+?)".+?(?:eps">(.+?)</span.+?)?(?:quality"(?:[a-zA-Z\n\s#=":]+)?>(.+?)<.+?)?data-original="(.+?)".+?info">(.+?)</span'''
                if link:
                    match = re.compile(regex_submenu, re.DOTALL).findall(link)
                    for mid, legatura, season, calitate, imagine, nume in match:
                        nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                        info = {'Title': nume,'Plot': nume,'Poster': imagine}
                        if '/seriale/' in legatura:
                            lists.append((nume, legatura, imagine, 'seriale', info))
                        else: lists.append((nume, legatura, imagine, 'get_links', info))
                match = re.compile('"pagination"', re.IGNORECASE).findall(link)
                if len(match) > 0:
                    if '/page/' in url:
                        new = re.compile('/page/(\d+)').findall(url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        if '/?s=' in url:
                            nextpage = re.compile('\?s=(.+?)$').findall(url)
                            nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                        else: nexturl = url + "/page/2"
                    lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'seriale':
            link = fetchData(url)
            regex_menu = '''class="tvseason"(.+?)</div>\s+</div>'''
            regex_season = '''i>.+?Season (\d+).+?</div'''
            regex_submenu = '''href="(.+?)">(?:\s+)?Episode (\d+)(?:\s+)?<'''
            blocks = re.findall(regex_menu, link, re.IGNORECASE | re.DOTALL)
            info = eval(info)
            if blocks:
                for block in blocks:
                    try: season = re.findall(regex_season, link, re.IGNORECASE | re.DOTALL)[0]
                    except: season = '1'
                    lists.append(('[COLOR lime]Sezon %s[/COLOR]' % season,'nolink',info['Poster'],'nimic', {}))
                    episodes = re.findall(regex_submenu, block, re.IGNORECASE | re.DOTALL)
                    if episodes:
                        infod = {}
                        for legatura, episod in episodes:
                            infod['Season'] = str(season)
                            infod['Episode'] = str(episod)
                            infod['TVshowtitle'] = info['Title']
                            infod['Title'] = '%s S%02dE%02d' % (info['Title'], int(season), int(episod))

                            infod['Plot'] = '%s S%02dE%02d - %s' % (info['Title'], int(season), int(episod), info['Plot'])
                            infod['Poster'] = info['Poster']
                            lists.append(('Episod %s' % str(episod), legatura, info['Poster'], 'get_links', str(infod)))
        elif meniu == 'get_links':
            link = fetchData(url)
            links = []
            regex_lnk = '''(?:text/javascript['"]>\s+str=["'](.+?)["']|<iframe.+?src=['"]((?:[htt]|[//]).+?)['"])'''
            match_lnk = re.findall(regex_lnk, link, re.IGNORECASE | re.DOTALL)
            for match1, match in match_lnk:
                if match1 and not match:
                    match1 = unquote(match1.replace('@','%'))
                    try:
                        match1 = re.findall('<iframe.+?src="((?:[htt]|[//]).+?)"', match1, re.IGNORECASE | re.DOTALL)[0]
                        links.append((match1))
                    except: pass
                if match:
                    links.append((match))
            for host, link1 in get_links(links):
                lists.append((host,link1,'','play', info, url))
        return lists
