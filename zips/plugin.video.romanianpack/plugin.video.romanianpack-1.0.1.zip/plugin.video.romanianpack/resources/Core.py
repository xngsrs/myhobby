# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from functions import *
from resources.lib.scrapers import __all__

class Core:
    __plugin__ = sys.modules["__main__"].__plugin__
    __settings__ = sys.modules["__main__"].__settings__
    ROOT = sys.modules["__main__"].__root__
    scrapers = os.path.join(ROOT, 'resources', 'lib', 'scrapers')
    if scrapers not in sys.path: sys.path.append(scrapers)
    media = sys.modules["__main__"].__media__

    def sectionMenu(self):
        
        for site in __all__:
            imp = getattr(__import__(site), site)
            name = imp().name
            params = {'site': site}
            self.drawItem(name, 'openMenu', params, image=imp().thumb)
        self.drawItem('Cautare', 'searchSites', params, image=self.media + '/search.png')

        ListString = 'XBMC.RunPlugin(%s)' % (sys.argv[0] + '?action=%s&action2=%s&%s=%s')
        contextMenu = []

        ##Media
        #CLcontextMenu=[]
        #CLcontextMenu.extend(contextMenu)
        #CLcontextMenu.append((self.localize('Reset All Cache DBs'),
                            #ListString % ('full_download', '', 'url', json.dumps({'action': 'delete'}))))
        #self.drawItem('< %s >' % self.localize('Content Lists'), 'openContent', image=self.ROOT + '/icons/media.png',
                      #contextMenu=CLcontextMenu, replaceMenu=False)

        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)

    def openMenu(self, params={}):
        get = params.get
        site = get('site')
        imp = getattr(__import__(site), site)
        menu = imp().menu
        if menu:
            for name, url, switch, image in menu:
                params = {'site': site, 'link': url, 'switch': switch }
                self.drawItem(name, 'OpenSite', params, image=image)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
        
    def OpenSite(self, params={}):
        get = params.get
        switch = get('switch')
        link = unquote(get('link'))
        nume = get('nume')
        site = get('site')
        info = unquote(get('info')) if get('info') else None
        if switch == 'play':
            liz = xbmcgui.ListItem(nume)
            if info: 
                info = json.loads(info)
                liz.setInfo(type="Video", infoLabels=info); liz.setArt({'thumb': info['Poster']})
            else: liz.setInfo(type="Video", infoLabels={'Title':unquote(nume)})
            import urlresolver
            try:
                hmf = urlresolver.HostedMediaFile(url=link, include_disabled=True, include_universal=False) 
                xbmc.Player().play(hmf.resolve(), liz, False)
            except Exception as e: 
                xbmc.executebuiltin('XBMC.Notification("Eroare", "%s")' % e)
        else:
            menu = getattr(__import__(site), site)().parse_menu(link, switch, info)
            if menu:
                for nume, url, imagine, switch, infoa in menu:
                    params = {'site': get('site'), 'link': url, 'switch': switch, 'nume': nume, 'info': infoa}
                    self.drawItem(nume, 'OpenSite', params, image=imagine)
            xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
            
    def searchSites(self, keyword=None):
        sites = {}
        if not keyword: keyword = 'ronin'
        else:
            keyboard = xbmc.Keyboard('')
            keyboard.doModal()
            if (keyboard.isConfirmed() == False):
                return
            keyword = keyboard.getText()
            if len(keyword) == 0:
                return
        for site in __all__:
            imp = getattr(__import__(site), site)
            #results = eval("%s.cauta(\"%s\")" % (site, keyword))
            site_name = imp().name
            results = imp().cauta(keyword)
            if results:
                for link in results:
                    nume = link[0]
                    url = link[1]
                    imagine = link[2]
                    switch = link[3]
                    infoa = link[4]
                    params = {'site': site, 'link': url, 'switch': switch, 'nume': nume, 'info': infoa}
                    if nume != 'Next' : self.drawItem('[COLOR red]%s[/COLOR] - %s' % (site_name, nume), 'OpenSite', params, image=imagine)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)

    def drawItem(self, title, action, link='', image='', isFolder=True, contextMenu=None, replaceMenu=True, action2='', fileSize=0L):
        #log('[drawItem]:'+str((title, action, image, isFolder, contextMenu, replaceMenu, action2, info)))
        """
        setArt(values) -- Sets the listitem's art
         values : dictionary - pairs of { label: value }.
            - Some default art values (any string possible):
                - thumb : string - image filename
                - poster : string - image filename
                - banner : string - image filename
                - fanart : string - image filename
                - clearart : string - image filename
                - clearlogo : string - image filename
                - landscape : string - image filename
                - icon : string - image filename
        example:
                - self.list.getSelectedItem().setArt({ 'poster': 'poster.png', 'banner' : 'banner.png' })
        """
        if isinstance(link, dict):
            link_url = ''
            for key in link.keys():
                if link.get(key):
                    if isinstance(link.get(key), dict):
                        link_url = '%s&%s=%s' % (link_url, key, urllib.quote_plus(json.dumps(link.get(key), ensure_ascii=False)))
                    else: 
                        link_url = '%s&%s=%s' % (link_url, key, urllib.quote_plus(link.get(key)))
            info = link.get('info')
            if info:
                if isinstance(info, str):
                    info  = eval(info)
                if isinstance(info, dict):
                    image = info.get('Poster')
            url = '%s?action=%s' % (sys.argv[0], action) + link_url
        else:
            info = {"Title": title, "plot": title}
            if not isFolder and fileSize:
                info['size'] = fileSize
            url = '%s?action=%s&url=%s' % (sys.argv[0], action, urllib.quote_plus(link))
        if action2:
            url = url + '&url2=%s' % urllib.quote_plus(ensure_str(action2))
        listitem = xbmcgui.ListItem(title)
        images = {'icon':image, 'thumb':image}
        images = {'icon': image, 'thumb': image,
                  'poster': image, 'banner': image,
                  #'fanart': image, 'landscape': image,
                  #'clearart': image, 'clearlogo': image,
                  }
        listitem.setArt(images)
        if isFolder:
            listitem.setProperty("Folder", "true")
            listitem.setInfo(type='Video', infoLabels=info)
        else:
            listitem.setInfo(type='Video', infoLabels=info)
            listitem.setArt({'thumb': image})
        if contextMenu:
            listitem.addContextMenuItems(contextMenu, replaceItems=replaceMenu)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=isFolder)

    def getParameters(self, parameterString):
        commands = {}
        splitCommands = parameterString[parameterString.find('?') + 1:].split('&')
        for command in splitCommands:
            if (len(command) > 0):
                splitCommand = command.split('=')
                if (len(splitCommand) > 1):
                    name = splitCommand[0]
                    value = splitCommand[1]
                    commands[name] = value
        return commands

    def executeAction(self, params={}):
        get = params.get
        if hasattr(self, get("action")):
            getattr(self, get("action"))(params)
        else:
            self.sectionMenu()

    def localize(self, string):
        #try:
            #return Localization.localize(string)
        #except:
        return string
