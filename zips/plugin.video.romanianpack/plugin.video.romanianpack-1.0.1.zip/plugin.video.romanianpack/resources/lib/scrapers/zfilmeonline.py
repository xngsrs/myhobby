# -*- coding: utf-8 -*-
import datetime
import os
import re
import urllib
import urllib2
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try: import HTMLParser as htmlparser
except: import html.parser as htmlparser
from resources.functions import *

base_url = 'https://www.zfilme-online.net'
    
class zfilmeonline:
    
    media = sys.modules["__main__"].__media__
    thumb = media + "/zfilmeonline.jpg"
    nextimage = media + "/next.png"
    searchimage = media + "/search.png"
    name = 'ZFilme-Online.net'
    menu = [('Recente', base_url, 'recente', thumb), 
            ('Genuri', base_url, 'genuri', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
                

    def cauta(self, keyword):
        return self.parse_menu(self.get_search_url(keyword), 'recente')
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + urllib.quote_plus(keyword)
        return url

    def parse_menu(self, url, meniu, info={}):
        lists = []
        link = fetchData(url)
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                keyboard = xbmc.Keyboard('')
                keyboard.doModal()
                if (keyboard.isConfirmed() == False):
                    return
                search_string = keyboard.getText()
                if len(search_string) == 0:
                    return
                link = fetchData(self.get_search_url(search_string))
                meniu = 'recente'
            else: link = fetchData(url)
            regex_menu = '''<article(.+?)</art'''
            regex_submenu = '''href=['"](.+?)['"].+?title=['"](.+?)['"].+?src=['"](.+?)['"]'''
            if link:
                for movie in re.compile(regex_menu, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                    match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                    for legatura, nume, imagine in match:
                        nume = htmlparser.HTMLParser().unescape(nume.decode('utf-8')).encode('utf-8')
                        info = {'Title': nume,'Plot': nume,'Poster': imagine}
                        lists.append((nume, legatura, imagine, 'get_links', info))
                match = re.compile('"pagination"', re.IGNORECASE).findall(link)
                match2 = re.compile('nav-previous', re.IGNORECASE).findall(link)
                if len(match) > 0 or len(match2) > 0:
                    if '/page/' in url:
                        new = re.compile('/page/(\d+)').findall(url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        if '/?s=' in url:
                            nextpage = re.compile('\?s=(.+?)$').findall(url)
                            nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                        else: nexturl = url + "/page/2"
                    lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_links':
            link = fetchData(url)
            nume = ''
            regex_base = '''var[\s*]s[\d\s=]+\'(.+?)\''''
            regex_lnk = r'''(?:<iframe|<script)[\s]src=['"]((?:[htt]|[//]).+?)["']'''
            regex_seriale = '''(?:<h3>.+?strong>(.+?)<.+?href=['"](.+?)['"].+?)'''
            regex_infos = '''detay-a.+?description">(.+?)</div'''
            match_base = re.findall(regex_base, link, re.IGNORECASE | re.DOTALL)
            match_lnk = re.findall(regex_lnk, link, re.IGNORECASE | re.DOTALL)
            match_srl = re.compile(regex_seriale, re.IGNORECASE | re.DOTALL).findall(link)
            match_nfo = re.compile(regex_infos, re.IGNORECASE | re.DOTALL).findall(link)
            import base64
            links = []
            for code in match_base:
                try:
                    match_lnk = re.findall(regex_lnk, base64.b64decode(code), re.IGNORECASE | re.DOTALL)
                    links.append(match_lnk[0])
                except: pass
            for hash_link in match_lnk:
                if "hqq.tv/player/hash" in hash_link:
                    try:
                        regex_code = '''unescape\(['"](.+?)['"]'''
                        code = re.findall(regex_code, fetchData(hash_link), re.IGNORECASE | re.DOTALL)[0]
                        vid_regex = '''vid = ['"]([0-9a-zA-Z]+)['"]'''
                        vid_id = re.findall(vid_regex, urllib.unquote(code), re.IGNORECASE | re.DOTALL)[0]
                        link_build = 'http://hqq.tv/player/embed_player.php?vid=%s' % vid_id
                        links.append(link_build)
                    except: pass
            links = links + match_lnk
            for link1 in links:
                if link1.startswith("//"):
                    link1 = 'http:' + link1 #//ok.ru fix
                if 'goo.gl' in link1:
                    try:
                        a = urllib2.urlopen(link1)
                        link1 = a.geturl()
                    except: pass
                parsed_url1 = urlparse.urlparse(link1)
                if parsed_url1.scheme:
                    try: import urlresolver
                    except: pass
                    hmf = urlresolver.HostedMediaFile(url=link1, include_disabled=True, include_universal=True)
                    if hmf.valid_url() == True:
                        host = link1.split('/')[2].replace('www.', '').capitalize()
                        info = eval(str(info))
                        if len(match_nfo) > 0:
                            info['Plot'] = (striphtml(match_nfo[0]).strip())
                        lists.append((host,link1,'','play', info))
        elif meniu == 'genuri':
            link = fetchData(url)
            regex_cat = '''class="cat-item.+?href=['"](.+?)['"\s]>(.+?)<'''
            if link:
                match = re.findall(regex_cat, link, re.IGNORECASE | re.DOTALL)
                if len(match) > 0:
                    for legatura, nume in match:
                        lists.append((nume,legatura.replace('"', ''),'','recente', info))
        return lists
              
