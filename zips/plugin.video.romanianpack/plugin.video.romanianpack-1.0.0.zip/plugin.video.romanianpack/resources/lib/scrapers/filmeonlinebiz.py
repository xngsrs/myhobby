# -*- coding: utf-8 -*-
import datetime
import os
import re
import sys
import urllib
import urllib2
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try: import HTMLParser as htmlparser
except: import html.parser as htmlparser
from resources.functions import *

base_url = 'http://www.filmeonline.biz'

class filmeonlinebiz:
    
    media = sys.modules["__main__"].__media__
    thumb = media + "/filmeonlinebiz.jpg"
    name = 'FilmeOnline.Biz'
    menu = [('Recente', base_url, 'recente'), 
            ('Genuri', base_url, 'genuri'),
            ('Ani', base_url, 'ani')]
    nextimage = media + "/next.png"
    
    def cauta(self, url):
        return None

    def parse_menu(self, url, meniu, info={}):
        lists = []
        link = fetchData(url)
        if meniu == 'recente':
            regex_menu = '''<div class="kutresim film-kutu-title">(.+?)</div>.?</div>'''
            regex_submenu = '''href="(.+?)".+?title="(.+?)".*img.*src="(.+?)"'''
            if link:
                for movie in re.compile(regex_menu, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                    match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                    for legatura, nume, imagine in match:
                        nume = htmlparser.HTMLParser().unescape(nume.decode('utf-8')).encode('utf-8')
                        info = {'Title': nume,'Plot': nume,'Poster': imagine}
                        lists.append((nume, legatura, imagine, 'get_links', info))
                match = re.compile('"pagination"', re.IGNORECASE).findall(link)
                if len(match) > 0:
                    if '/page/' in url:
                        new = re.compile('/page/(\d+)').findall(url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        nexturl = url + "/page/2"
                    lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_links':
            regex_lnk = '''iframe.+?src="((?:[htt]|[//]).+?)"'''
            regex_infos = '''"description">(.+?)</'''
            match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
            match_nfo = re.compile(regex_infos, re.IGNORECASE | re.DOTALL).findall(link)
            for link1 in match_lnk:
                if link1.startswith("//"):
                    link1 = 'http:' + link1 #//ok.ru fix
                parsed_url1 = urlparse.urlparse(link1)
                if parsed_url1.scheme:
                    try: import urlresolver
                    except: pass
                    hmf = urlresolver.HostedMediaFile(url=link1, include_disabled=True, include_universal=True)
                    if hmf.valid_url() == True:
                        host = link1.split('/')[2].replace('www.', '').capitalize()
                        info = eval(str(info))
                        info['Plot'] = (striphtml(match_nfo[0]).strip())
                        lists.append((host,link1,'','play', info))#addLink(host, link1, thumb, name, 10, striphtml(match_nfo[0]))
        elif meniu == 'genuri':
            regex_cats = '''<ul class="categories">(.+?)</ul'''
            regex_cat = '''href=["'](.*?)['"\s]>(.+?)<'''
            if link:
                for cat in re.compile(regex_cats, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                    match = re.compile(regex_cat, re.DOTALL).findall(cat)
                    for legatura, nume in match:
                        lists.append((nume,legatura.replace('"', ''),'','recente', info))#addDir(nume, legatura.replace('"', ''), 6, movies_thumb, 'recente')
        return lists
              
