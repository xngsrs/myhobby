# -*- coding: utf-8 -*-
import datetime
import os
import re
import urllib
import urllib2
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try: import HTMLParser as htmlparser
except: import html.parser as htmlparser
from resources.functions import *

base_url = 'https://filmeseriale.online'

class fsonline:
    
    media = sys.modules["__main__"].__media__
    thumb = media + "/fsonline.jpg"
    nextimage = media + "/next.png"
    searchimage = media + "/search.png"
    name = 'FilmeSeriale.online'
    menu = [('Recente', base_url, 'recente', thumb),
            ('Genuri', base_url, 'genuri', thumb),
            ('Filme', base_url + '/filme/', 'recente', thumb),
            ('Seriale', base_url + '/seriale/', 'recente', thumb),
            ('Ultimele aparute', base_url + '/ultimele-aparute', 'recente', thumb),
            ('Ultimele episoade', base_url + '/ultimele-episoade', 'recente', thumb),
            ('Top vizionate', base_url + '/top-vizionate', 'recente', thumb),
            ('Top votate', base_url + '/top-votate', 'recente', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + urllib.quote_plus(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword, result):
        result.append((self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')))

    def parse_menu(self, url, meniu, info={}):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else: 
                link = fetchData(url, base_url+ '/')
                regex = '''class="item".+?href="(.+?)".+?src="(.+?)".+?title="(.+?)">(.+?)<.+?genero">(.+?)<'''
                if link:
                    match = re.findall(regex, link, re.DOTALL)
                    for legatura, imagine, numeep, numarep, numes in match:
                        numeep = htmlparser.HTMLParser().unescape(numeep.decode('utf-8')).encode('utf-8').strip()
                        numarep = htmlparser.HTMLParser().unescape(numarep.decode('utf-8')).encode('utf-8').strip()
                        numes = htmlparser.HTMLParser().unescape(numes.decode('utf-8')).encode('utf-8').strip()
                        imagine = imagine.strip()
                        if numeep == numarep:
                            fullname = numeep
                            info = {'Title': numeep,'Plot': numeep, 'Genre': numes, 'Poster': imagine}
                            if re.search('/serial/', legatura):
                                lists.append((fullname + ' - Serial', legatura, imagine, 'seriale', info))
                            else:
                                lists.append((fullname, legatura, imagine, 'get_links', info))
                        else:
                            sez_ep = re.findall('(\d+)', numarep)
                            sezon = str('%02d' % int(sez_ep[0]))
                            episod = str('%02d' % int(sez_ep[1]))
                            info = {'Title': numeep,
                                    'TVshowtitle' : numes,
                                    'Season' : sezon,
                                    'Episode': episod,
                                    'Plot': numes + ' ' + numarep + ' ' + numeep,
                                    'Poster': imagine}
                            fullname = '%s - S%sE%s %s' % (numes, sezon, episod, numeep)
                            lists.append((fullname, legatura, imagine, 'get_links', info))
                    match = re.compile('"pagination', re.IGNORECASE).findall(link)
                    if len(match) > 0:
                        if '/page/' in url:
                            new = re.compile('/page/(\d+)').findall(url)
                            nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                        else:
                            if '/?s=' in url:
                                nextpage = re.compile('\?s=(.+?)$').findall(url)
                                nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                            else: nexturl = url + "/page/2"
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_links':
            link = ''
            servere = fetchData(url)
            servers = re.findall('''href="#embed\d.+?>server(.+?)<''', servere, re.DOTALL | re.IGNORECASE)
            s_id = re.findall('''data:\{id:(.+?),''', servere, re.DOTALL)
            import requests
            session = requests.Session()
            url="https://www.filmeseriale.online/wp-content/themes/playnow/masthemes/descargas/source.php"
            for server in servers:
                data= {'id': str(s_id[int(server.strip())-1].strip()), 'server': str(int(server.strip()) - 1)}
                headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0', 'Referer': base_url + '/'}
                link += session.post(url, data=data, headers=headers).text
            regex_lnk = '''<iframe.+?src="((?:[htt]|[//]).+?)"'''
            regex_infos = '''"description">(.+?)</'''
            match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
            match_nfo = re.compile(regex_infos, re.IGNORECASE | re.DOTALL).findall(link)
            for link1 in match_lnk:
                if link1.startswith("//"):
                    link1 = 'http:' + link1 #//ok.ru fix
                if 'goo.gl' in link1:
                    try:
                        a = urllib2.urlopen(link1)
                        link1 = a.geturl()
                    except: pass
                parsed_url1 = urlparse.urlparse(link1)
                if parsed_url1.scheme:
                    try: import urlresolver
                    except: pass
                    hmf = urlresolver.HostedMediaFile(url=link1, include_disabled=True, include_universal=True)
                    if hmf.valid_url() == True:
                        host = link1.split('/')[2].replace('www.', '').capitalize()
                        try:
                            info = eval(str(info))
                            info['Plot'] = (striphtml(match_nfo[0]).strip())
                        except: pass
                        lists.append((host,link1,'','play', info))#addLink(host, link1, thumb, name, 10, striphtml(match_nfo[0]))
        elif meniu == 'genuri':
            link = fetchData(url)
            regex = '''genuri.+?ul>(.+?)</ul'''
            regex_cats = '''href="(.+?)".+?i>(.+?)</i'''
            if link:
                for cats in re.findall(regex, link, re.DOTALL | re.IGNORECASE):
                    match = re.findall(regex_cats, cats, re.DOTALL)
                    if len(match) >= 0:
                        for legatura, nume in sorted(match, key=self.getKey):
                            lists.append((nume,legatura,'','recente', info))#addDir(nume, legatura.replace('"', ''), 6, movies_thumb, 'recente')
        elif meniu == 'seriale':
            link = fetchData(url)
            #log('link: ' + str(link))
            regex = '''class="episode-title.+?href="(.+?)".+?title="(.+?)"'''
            match = re.findall(regex, link, re.DOTALL | re.IGNORECASE)
            for link, nume in match:
                lists.append((nume,link,'','get_links', info))
        return lists
              
