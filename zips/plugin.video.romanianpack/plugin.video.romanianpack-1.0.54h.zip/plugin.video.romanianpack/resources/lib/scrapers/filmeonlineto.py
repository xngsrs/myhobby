# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'https://onmovies.se'

class filmeonlineto:
    
    thumb = os.path.join(media, 'filmeonlineto.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'Filme-Online.to'
    menu = [('Recente', base_url, 'recente', thumb),
            ('Genuri', '0', 'genuri', thumb),
            ('Țări', '0', 'tari', thumb),
            ('Filme', '%s/movie/filter/movie/all/all/all/all/latest/' % base_url, 'recente', thumb),
            ('Seriale', '%s/movie/filter/series/all/all/all/all/latest/' % base_url, 'recente', thumb),
            ('Căutare', base_url, 'cauta', searchimage)
            ]
        
    def get_search_url(self, keyword):
        keyword = re.sub('[^a-zA-Z0-9]', '-', keyword)
        url = 'https://api.ocloud.stream/cmovieshd//movie/search/%s-?link_web=%s' % (keyword, base_url)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword):
        return self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')

    def parse_menu(self, url, meniu, info={}):
        lists = []
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                regex_submenu = '''"ml-item".+?href="(.+?)".+?title="(.+?)">.+?(?:.+?(?:mli-quality">(.+?)<|mli-eps">(.+?)</span))?.+?data-original="(.+?)".+?</a>\s+</div>'''
                if link:
                    match = re.compile(regex_submenu, re.DOTALL).findall(link)
                    for legatura, nume, calitate, episoade, imagine in match:
                        nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                        legatura = '%s%s' % (base_url, legatura) if not legatura.startswith('http') else legatura
                        imagine = 'https:%s' % (imagine)
                        if episoade:
                            try: 
                                season = str(re.findall('season\s+(\d+)', nume, re.IGNORECASE)[0])
                                showtitle = re.findall('(.+?)[\s\-]+season', nume, re.IGNORECASE)[0]
                            except: 
                                season = '0'
                                showtitle = nume
                            info = {'Title': nume,'Plot': nume,'Poster': imagine, 'TvShowTitle': showtitle , 'Season': season}
                            lists.append((nume, legatura, imagine, 'seriale', info))
                        else:
                            nume = '%s [%s]' % (nume, calitate) if calitate else nume
                            info = {'Title': nume,'Plot': nume,'Poster': imagine}
                            lists.append((nume, legatura, imagine, 'get_links', info))
                    match = re.compile('class=\'pagination', re.IGNORECASE).findall(link)
                    if len(match) > 0:
                        if 'page=' in url:
                            new = re.compile('page=(\d+)').findall(url)
                            nexturl = re.sub('page=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, ('?page=2' if str(url).endswith('/') else '&page=2'))
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'seriale':
            link = fetchData(url)
            showsreg = '''ep-item(?:[\w\s]+)?"\s+id="(.+?)".+?href="(.+?)".+?title="(.+?)"'''
            if link:
                for epid, legatura, nume in re.findall(showsreg, link, re.DOTALL | re.IGNORECASE):
                    info = eval(str(info))
                    info['Episode'] = str(epid)
                    legatura = '%s%s' % (base_url, legatura)
                    nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                    lists.append((nume, legatura, imagine, 'get_links', info))
            
        elif meniu == 'get_links':
            link = fetchData(url)
            get_first = '''data-video="(.+?)"'''
            get_two = '''iframe.+?src="(/loadtv.+?)"'''
            stepone_one = 'https:%s' % (re.findall(get_first, link)[0])
            stepone = fetchData(stepone_one, url)
            steptwo_one = 'https://streame.club%s' % (re.findall(get_two, stepone, re.IGNORECASE)[0])
            steptwo = fetchData(steptwo_one, stepone_one)
            stepthree = re.findall(get_first, steptwo)
            for host, link1 in get_links(stepthree):
                lists.append((host,link1,'','play', info, url))
        elif meniu == 'genuri' or meniu == 'tari':
            link = fetchData(base_url)
            regex = '''"sub-menu"(.+?)</ul'''
            regex_cats = '''href="(.+?)">(.+?)<'''
            if link:
                sortmenu = re.findall(regex, link, re.DOTALL | re.IGNORECASE)
                if meniu == 'genuri':
                    match = re.findall(regex_cats, sortmenu[0], re.DOTALL)
                else:
                    match = re.findall(regex_cats, sortmenu[1], re.DOTALL)
                if len(match) >= 0:
                    for legatura, nume in match:
                        legatura = '%s%s' % (base_url, legatura) if not legatura.startswith('http') else legatura
                        lists.append((nume,legatura,'','recente', info))
        return lists
              
