# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'https://hindilover.biz'

class hindilover:
    
    thumb = os.path.join(media, 'hindilover.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'HindiLover.biz'
    menu = [('Recente', base_url, 'recente', thumb),
            ('Seriale Indiene în desfășurare', '%s/index/indiene-in-difuzare/0-64' % base_url, 'recente', thumb),
            ('Seriale Indiene terminate', '%s/index/seriale-indiene-terminate/0-69' % base_url, 'recente', thumb),
            ('Seriale Turcești în desfășurare', '%s/index/turcesti/0-65' % base_url, 'recente', thumb),
            ('Seriale Turcești terminate', '%s/index/seriale-turcesti-terminate/0-70' % base_url, 'recente', thumb),
            ('Seriale Coreene în desfășurare', '%s/index/0-71' % base_url, 'recente', thumb),
            ('Seriale Coreene terminate', '%s/index/0-73' % base_url, 'recente', thumb),
            ('Seriale Românești', '%s/index/0-74' % base_url, 'recente', thumb),
            ('Seriale Spaniole', '%s/index/0-76' % base_url, 'recente', thumb),
            ('Filme Indiene', '%s/hind/filme_indiene/1-0-31' % base_url, 'recente', thumb),
            ('Filme Turcești', '%s/turc/1/104' % base_url, 'recente', thumb),
            ('Filme Coreene', '%s/coreene/filme' % base_url, 'recente', thumb),
            ('Filme Românești', '%s/romanesti/filme' % base_url, 'recente', thumb),
            ('Filme Spaniole', '%s/spaniole/filme' % base_url, 'recente', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword):
        #return self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')
        return None

    def parse_menu(self, url, meniu, info={}):
        lists = []
        #log('link: ' + link)
        imagine = ''
        nexturl = None
        if meniu == 'recente' or meniu == 'cauta' or meniu == 'filme':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else: 
                link = fetchData(url)
                regex_menu = '''class="movie"(.+?)(?:</li>|</td>|</div></div>)'''
                regex_submenu = '''src=(?:"|)(.+?)(?:"|\s+).+?href="(.+?)"(?:.+?"movie_hd">(.+?)<)?.+?href.+?">(.+?)(?:</div|</a)'''
                if link:
                    if re.search('<iframe.+?src=(?:")?((?:[htt]|[//]).+?)"', link, re.IGNORECASE) and info:
                        meniu = 'get_links'
                        return self.parse_menu(url,'get_links',info)
                    for movie in re.compile(regex_menu, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                        infog = {}
                        match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                        for imagine, legatura, vizualizari, nume in match:
                            nume = htmlparser.HTMLParser().unescape(nume.decode('utf-8')).encode('utf-8').strip()
                            nume = striphtml(nume)
                            imagine = '%s/%s' % (base_url, imagine.strip().replace('../../', ''))
                            legatura = '%s%s' % (base_url, legatura) if legatura.startswith('/') else legatura
                            if info:
                                try:
                                    infog = eval(info)
                                    nume = infog['Title'] = '%s %s' % (infog.get('Title'), nume)
                                    infog['Plot'] = nume
                                except: pass
                            else:
                                infog = {'Title': '%s' % (nume),'Plot': '%s' % (nume),'Poster': imagine}
                            lists.append(('%s' % (nume), legatura, imagine, 'recente', infog))
                    match = re.compile('"catpages', re.IGNORECASE).findall(link)
                    match2 = re.compile('"pagesBlockuz.+?swchitem', re.IGNORECASE).findall(link)
                    if len(match) > 0:
                        if re.search('/\d+-\d+-\d+$', url):
                            new = re.compile('/(\d+)-\d+-\d+').findall(url)
                            nexturl = re.sub('/(\d+)-', '/' + str(int(new[0]) + 1) + '-', url)
                    elif len(match2) > 0:
                        if re.search('/\d+$', url):
                            new = re.compile('/(\d+)$').findall(url)
                            nexturl = re.sub('/(\d+)$', '/' + str(new[0]) + '-2', url)
                        elif re.search('/\d+-\d+$', url):
                            new = re.compile('/\d+-(\d+)$').findall(url)
                            nexturl = re.sub('-(\d+)$', '-' + str(int(new[0]) + 1), url)
                        elif re.search('/\d+-\d+-\d+-\d+-\d+$', url):
                            new = re.compile('/\d+-(\d+)-\d+-\d+-\d+$').findall(url)
                            nexturl = re.sub(r'/(\d+)-(\d+)', r'/\1-' + str(int(new[0]) + 1), url)
                    if nexturl:
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        
        elif meniu == "get_links":
            link = fetchData(url)
            regex_lnk = '''<iframe.+?src=(?:")?((?:[htt]|[//]).+?)"'''
            match = re.findall(regex_lnk, link, re.IGNORECASE | re.DOTALL)
            if match:
                for host, link1 in get_links(match):
                    lists.append((host,link1,'','play', info, url))
        elif meniu == 'serialeindiene' or meniu == 'serialeturcesti' or meniu == 'serialeterminate':
            link = fetchData(url)
            if meniu == 'serialeindiene':
                regex_block = '''"seriale indiene"(.+?)</div>\s+</div>'''
                #regex_serial = '''href="(.+?)".+?class="abcd[\w\s]+">(.+?)<!'''
            elif meniu == 'serialeturcesti':
                regex_block = '''"seriale turcesti"(.+?)</div>\s+</div>'''
            elif meniu == 'serialeterminate':
                regex_block = '''"seriale"(.+?)</div>\s+</div>'''
            regex_serial = '''href="(.+?)".+?class="abcd[\w\sÇ]+">(.+?)</di'''
            
            if link:
                for block in re.findall(regex_block, link, re.IGNORECASE | re.DOTALL):
                    match = re.findall(regex_serial, block, re.IGNORECASE | re.DOTALL)
                    for legatura, nume in match:
                        nume = htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')
                        legatura = legatura.strip()
                        lists.append((nume, legatura, self.thumb, 'recente', info))
        return lists
              
