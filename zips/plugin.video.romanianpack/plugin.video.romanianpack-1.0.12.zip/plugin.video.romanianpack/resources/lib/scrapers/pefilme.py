# -*- coding: utf-8 -*-
import re
try: import HTMLParser as htmlparser
except: import html.parser as htmlparser
from resources.functions import *

base_url = 'https://pefilme.com'

class pefilme:
    
    media = sys.modules["__main__"].__media__
    thumb = media + "/pefilme.jpg"
    nextimage = media + "/next.png"
    searchimage = media + "/search.png"
    name = 'PeFilme.com'
    menu = [('Recente', base_url, 'recente', thumb), 
            ('Categorii', base_url, 'genuri', thumb),
            ('Cele mai accesate', base_url + '/cele-mai-accesate-filme/', 'recente', thumb),
            ('Cele mai apreciate', base_url + '/cele-mai-apreciate-filme/', 'recente', thumb),
            ('Top IMdb', base_url + '/top-imdb/', 'recente', thumb),
            ('Etichete', base_url + '/etichete/', 'tags', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
    nextimage = media + "/next.png"
    
    def cauta(self, keyword, result):
        result.append((self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')))
    
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + quote(keyword)
        return url

    def parse_menu(self, url, meniu, info={}):
        lists = []
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else: 
                link = fetchData(url, base_url + '/')
                regex_menu = '''post".+?href=['"](.+?)['"].+?imdb">(.+?)<.+?data-src=['"](.+?)['"].+?alt="(.+?)"'''
                if link:
                    match = re.compile(regex_menu, re.DOTALL).findall(link)
                    for legatura, imdb, imagine, nume in match:
                        nume = htmlparser.HTMLParser().unescape(nume.decode('utf-8')).encode('utf-8')
                        info = {'Title': nume,'Plot': nume,'Poster': imagine,'Rating':imdb}
                        lists.append((nume, legatura, imagine, 'get_tabs', info))
                    match = re.compile('"current"', re.IGNORECASE).findall(link)
                    if len(match) > 0 :
                        if '/page/' in url:
                            new = re.compile('/page/(\d+)').findall(url)
                            nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                        else:
                            if '/?s=' in url:
                                nextpage = re.compile('\?s=(.+?)$').findall(url)
                                nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                            else: nexturl = url + "/page/2"
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_tabs':
            link = fetchData(url)
            cats = []
            reg_info = '''"infos"(.+?)</div'''
            reg_cat = '''href.+?>(.+?)<'''
            reg_descriere = '''desfilm">(?:.+?script>)?(.+?)<(?:div|/div)'''
            descriere = htmlparser.HTMLParser().unescape(striphtml(re.findall(reg_descriere, link, re.IGNORECASE | re.DOTALL)[0]).decode('utf-8')).encode('utf-8').strip()
            for cat in re.findall(reg_info, link, re.IGNORECASE | re.DOTALL):
                cats = re.findall(reg_cat, cat, re.IGNORECASE | re.DOTALL)
            info = eval(str(info))
            info['Genre'] = ', '.join(cats)
            info['Plot'] = descriere
            id_reg = '''post_id[\s]=[\s](.+?);'''
            tabs_reg = '''li.+?id=['"]tab(\d+)["']'''
            get_tabs = '%s/getTabContent.php?tabNum=%s&id=%s'
            movie_id =  re.compile(id_reg, re.IGNORECASE | re.DOTALL).findall(link)
            movie_tab = re.compile(tabs_reg, re.IGNORECASE | re.DOTALL).findall(link)
            if len(movie_tab) > 0:
                for tab in movie_tab:
                    tab = str(tab)
                    nume = 'Server %s' % tab
                    serv_link = get_tabs % (base_url, tab, movie_id[0]) 
                    lists.append((nume,serv_link,'','get_links', info))
            else:
                return self.parse_menu(url, 'get_links', info)
        elif meniu == 'get_links':
            link = fetchData(url)
            regex_lnk = '''(?:ng>(.+?)</.+?)?<iframe.+?src="((?:[htt]|[//]).+?)"'''
            match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
            for host, link1 in get_links(match_lnk):
                lists.append((host,link1,'','play', info, url))
        elif meniu == 'genuri':
            link = fetchData(url)
            regex_cats = '''navbar2(.+?)</ul'''
            regex_cat = '''href=["'](.*?)['"].+?>(.+?)<'''
            if link:
                for cat in re.compile(regex_cats, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                    match = re.compile(regex_cat, re.DOTALL).findall(cat)
                    for legatura, nume in match:
                        if not re.search('porno|xxx', nume, flags=re.IGNORECASE):
                            lists.append((nume,legatura.replace('"', ''),'','recente', info))
        elif meniu == 'tags':
            link = fetchData(url)
            regex_cats = '''etichete"(.+?)</ul'''
            regex_cat = '''href=["'](.*?)['"].+?ll>(.+?)</a> -(.+?)<'''
            if link:
                for cat in re.compile(regex_cats, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                    match = re.compile(regex_cat, re.DOTALL).findall(cat)
                    for legatura, nume, numar in match:
                        nume = nume + numar
                        lists.append((nume,legatura.replace('"', ''),'','recente', info))
        return lists
              
