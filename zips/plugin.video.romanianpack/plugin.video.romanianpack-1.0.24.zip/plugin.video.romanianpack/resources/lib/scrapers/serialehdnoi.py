# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'https://serialehdnoi.com'

class serialehdnoi:
    
    thumb = os.path.join(media, 'serialehdnoi.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'SerialeHDNoi.com'
    menu = [('Recente', base_url, 'recente', thumb),
            ('Filme', base_url + '/filme', 'filme', thumb),
            ('Seriale', base_url + '/seriale', 'seriale', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword, result):
        result.append((self.__class__.__name__, self.name, self.parse_menu('post', 'cauta', keyw=keyword)))

    def parse_menu(self, url, meniu, info={}, keyw=''):
        lists = []
        imagine = ''
        if meniu == 'filme' or meniu == 'cauta':
            regex_menu = '''<article(.+?)</arti'''
            if meniu == 'cauta':
                if url == 'post' and keyw:
                    regex_submenu = '''src="(.+?)".+?movies">(.+?)<.+?href="(.+?)">(.+?)<.+?year">(.+?)<.+?contenido">(.+?)</div'''
                    link = fetchData(self.get_search_url(keyw))
                else:
                    link = None
                    from resources.Core import Core
                    Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                regex_submenu = '''src="(.+?)".+?rating">(.+?)</div.+?quality">(.+?)<.+?h3.+?href="(.+?)">(.+?)</div'''
            if link:
                for movie in re.compile(regex_menu, re.DOTALL).findall(link):
                    match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                    if meniu == 'filme':
                        for imagine, rating, calitate, legatura, nume in match:
                            nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                            nume = re.sub(r'(\d{4})', r'(\1)', " ".join(re.split('((?:19|20)\d{2})', nume)))
                            info = {'Title': nume,'Plot': nume,'Poster': imagine}
                            lists.append((nume, legatura, imagine, 'get_links', info))
                    else:
                        for imagine, tip, legatura, nume, an, descriere in match:
                            nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                            nume = '%s (%s)' % (nume, an.strip())
                            descriere = (htmlparser.HTMLParser().unescape(striphtml(descriere).decode('utf-8')).encode('utf-8')).strip()
                            info = {'Title': nume,'Plot': nume,'Poster': imagine}
                            lists.append((nume, legatura, imagine, 'get_links', info))
                match = re.compile('"pagination"', re.IGNORECASE).findall(link)
                if len(match) > 0:
                    if '/page/' in url:
                        new = re.compile('/page/(\d+)').findall(url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        if '/?s=' in url:
                            nextpage = re.compile('\?s=(.+?)$').findall(url)
                            nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                        else: nexturl = url + "/page/2"
                    lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_links':
            link = fetchData(url)
            regex_lnk = '''<iframe.+?src="((?:[htt]|[//]).+?)"'''
            regex_infos = '''"description">(.+?)</'''
            match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
            match_nfo = re.compile(regex_infos, re.IGNORECASE | re.DOTALL).findall(link)
            try:
                info = eval(str(info))
                info['Plot'] = (striphtml(match_nfo[0]).strip())
            except: pass
            regex_sub_oload = '''captions["\s]+src="(.+?)"'''
            regex_sub_vidoza = '''tracks[:\s]+(.+?])'''
            for host, link1 in get_links(match_lnk):
                    sub = None
                    sub_code = fetchData(link1, url)
                    try: sub = re.findall(regex_sub_oload, sub_code, re.IGNORECASE | re.DOTALL)[0]
                    except:
                        try:
                            if not re.search('hqq', host, flags=re.I):
                                test = re.findall(regex_sub_vidoza, sub_code, re.IGNORECASE | re.DOTALL)[0]
                                test = (re.sub(r'([a-zA-Z]+):\s', r'"\1": ', test)).replace(', default:true', '')
                                test = eval(str(test))
                                for subs in test:
                                    if subs.get('label') and subs.get('label') == 'Romanian':
                                        sub = subs.get('file').replace('\\', '')
                                        if sub.startswith('/'):
                                            from urlparse import urlparse
                                            parsed = urlparse(link1)
                                            domain = '{uri.scheme}://{uri.netloc}'.format(uri=parsed)
                                            sub = domain + sub
                            else:
                                sub = None
                        except: pass
                    try:
                        subtitle = xbmc.translatePath('special://temp/')
                        if sub and not re.search('youtube', host, flags=re.I):
                            subtitle = os.path.join(subtitle, '%s.ro.srt' % host)
                            with open(subtitle, 'w') as f: f.write(fetchData(sub, url))
                            info['subtitrare'] = subtitle
                        else: del info['subtitrare']
                    except: pass
                    if info.get('subtitrare'): host = host + ' Subtitrat' 
                    lists.append((host,link1,'','play', info, url))
        elif meniu == 'recente':
            regex_menu = '''<article(.+?)</arti'''
            regex_submenu = '''(?:(?:"item se episodes".+?src="(.+?)".+?href="(.+?)">.+?quality">(.+?)<.+?serie">(.+?)<.+?"></div>(.+?)</div)|(?:"item".+?src="(.+?)".+?href="(.+?)".+?title">(.+?)</div))'''
            link = fetchData(url)
            for movie in re.compile(regex_menu, re.DOTALL).findall(link):
                match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                for res in match:
                    if res[0]: imagine = res[0]
                    elif res[5]: imagine = res[5]
                    if res[1]: legatura = res[1]
                    elif res[6]: legatura = res[6]
                    if res[3]: nume = res[3]
                    elif res[7]: nume = res[7]
                    numeepisod = res[4]
                    #nume2 = res[5] = res[10]
                    calitate = res[2]
                    
                    nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                    try: nume = re.sub(r'(\d{4})', r'(\1)', " ".join(re.split('((?:19|20)\d{2})', nume)))
                    except: pass
                    info = {'Title': nume,'Plot': nume,'Poster': imagine}
                    if re.search('/sezoane|episoade/', legatura):
                        lists.append((nume + ' - Serial', legatura, imagine, 'episoade', info))
                    else:
                        lists.append((nume, legatura, imagine, 'get_links', info))
        elif meniu == 'episoade':
            import codecs
            import unicodedata
            link = fetchData(url)
            regex_menu = '''serie_contenido"(.+?)jQuery'''
            regex_submenu = '''src="(.+?)".+?numerando">(.+?)<.+?href="(.+?)">(.+?)<.+?date">(.+?)<'''
            info = json.loads(info)
            title = info.get('Title')
            for serial in re.compile(regex_menu, re.DOTALL | re.IGNORECASE).findall(link):
                match = re.compile(regex_submenu, re.DOTALL).findall(serial)
                infos = info
                for imagine, numerotare, legatura, numeepisod, data in match:
                    numeepisod = (htmlparser.HTMLParser().unescape(striphtml(numeepisod).decode('utf-8')).encode('utf-8')).strip()
                    numeepisod = unicode(numeepisod.strip(codecs.BOM_UTF8), 'utf-8')
                    numeepisod = ''.join(c for c in unicodedata.normalize('NFKD', numeepisod)
                                   if unicodedata.category(c) != 'Mn')
                    nume = '%s - %s - %s - %s' % (title, numerotare.strip(), numeepisod, data.strip())
                    infos['Title'] = nume
                    lists.append((nume, legatura, imagine, 'get_links', infos))
        elif meniu == 'seriale':
            link = fetchData(url)
            regex_menu = '''<article(.+?)</arti'''
            regex_submenu = '''src="(.+?)".+?href="(.+?)".+?title">(.+?)</div.+?imdb">(.+?)<.+?(\d{4}).+?texto">(.+?)</div'''
            if link:
                for movie in re.compile(regex_menu, re.DOTALL).findall(link):
                    match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                    for imagine, legatura, nume, rating, an, descriere in match:
                        nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                        descriere = (htmlparser.HTMLParser().unescape(striphtml(descriere).decode('utf-8')).encode('utf-8')).strip()
                        info = {'Title': nume,'Plot': descriere,'Poster': imagine,'Year': str(an)}
                        lists.append((nume, legatura, imagine, 'episoade', info))
                match = re.compile('"pagination"', re.IGNORECASE).findall(link)
                if len(match) > 0:
                    if '/page/' in url:
                        new = re.compile('/page/(\d+)').findall(url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        if '/?s=' in url:
                            nextpage = re.compile('\?s=(.+?)$').findall(url)
                            nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                        else: nexturl = url + "/page/2"
                    lists.append(('Next', nexturl, self.nextimage, meniu, {}))

        return lists
              
