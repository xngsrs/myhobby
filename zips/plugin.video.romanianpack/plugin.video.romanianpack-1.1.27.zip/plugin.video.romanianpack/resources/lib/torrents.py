# -*- coding: utf-8 -*-
from resources.functions import *
import tempfile
import ssl
import hashlib
import pickle
__settings__ = xbmcaddon.Addon()
zeroseed = __settings__.getSetting("zeroseed") == 'true'

torrentsites = ['datascene',
             'ettv',
             'extratorrent',
             'eztv',
             'filelist',
             'fluxzone',
             'ieet',
             'kickass',
             'kickass2',
             'lime',
             'magnetdl',
             'piratebay',
             'rarbg',
             'speedapp',
             'seedfilero',
             'skytorrents',
             'torrentgalaxy',
             'xtremlymtorrents',
             'yify',
             'yourbittorrent',
             'zooqle']

torrnames = {'datascene': {'nume' : 'DataScene', 'thumb': os.path.join(media, 'datascene.png')},
             'ettv': {'nume': 'ETTV', 'thumb': os.path.join(media, 'ettv.jpg')},
             'extratorrent': {'nume': 'ExtraTorrents', 'thumb': os.path.join(media, 'extratorrent.jpg')},
             'eztv': {'nume': 'EZTV', 'thumb': os.path.join(media, 'eztv.png')},
             'filelist': {'nume': 'FileList', 'thumb': os.path.join(media, 'filelist.png')},
             'fluxzone': {'nume': 'FluxZone', 'thumb': os.path.join(media, 'fluxzone.png')},
             'ieet': {'nume': '1337x', 'thumb': os.path.join(media, 'ieetx.png')},
             'kickass': {'nume': 'Kickass', 'thumb': os.path.join(media, 'kickass.png')},
             'kickass2': {'nume': 'Kickass2', 'thumb': os.path.join(media, 'kickass2.png')},
             'lime': {'nume': 'LimeTorrents', 'thumb': os.path.join(media, 'limetorrents.jpg')},
             'magnetdl': {'nume': 'MagnetDL', 'thumb': os.path.join(media, 'magnetdl.png')},
             'piratebay': {'nume': 'ThePirateBay', 'thumb': os.path.join(media, 'piratebay.png')},
             'rarbg': {'nume': 'Rarbg', 'thumb': os.path.join(media, 'rarbg.png')},
             'seedfilero': {'nume': 'SeedFile', 'thumb': os.path.join(media, 'seedfilero.jpg')},
             'speedapp': {'nume': 'SpeedApp', 'thumb': os.path.join(media, 'speedapp.png')},
             'skytorrents': {'nume': 'SkyTorrents', 'thumb': os.path.join(media, 'skytorrents.jpg')},
             'torrentgalaxy': {'nume': 'TorrentGalaxy', 'thumb': os.path.join(media, 'torrentgalaxy.jpg')},
             'xtremlymtorrents': {'nume': 'ExtremLymTorrents', 'thumb': os.path.join(media, 'extremlymtorrents.jpg')},
             'yify': {'nume': 'Yify', 'thumb': os.path.join(media, 'yify.jpg')},
             'yourbittorrent': {'nume': 'YourBittorrent', 'thumb': os.path.join(media, 'yourbittorrent.jpg')},
             'zooqle': {'nume': 'Zooqle', 'thumb': os.path.join(media, 'zooqle.png')}}
    

def getKey(item):
        return item[1]

def save_cookie(name, session):
    cookie=os.path.join(dataPath, name + '.txt')
    with open(cookie, 'wb') as f:
        pickle.dump(session.cookies, f)
    

def load_cookie(name, session):
    cookie=os.path.join(dataPath, name + '.txt')
    if os.path.exists(cookie):
        try:
            with open(cookie, 'rb') as f:
                session.cookies.update(pickle.load(f))
        except: pass
    return session
    
def clear_cookie(name):
    cookie=os.path.join(dataPath, name + '.txt')
    if os.path.exists(cookie):
        os.remove(cookie)
        log('%s [clear_cookie]: cookie cleared' % (torrnames.get(name)))
            
def makeRequest(url, data={}, headers={}, name='', timeout=None, referer=None, rtype=None, savecookie=None, raw=None):
    from resources.lib.requests.packages.urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
    s = requests.Session()
    if name:
        s = load_cookie(name, s)
    timeout = timeout if timeout else int(__settings__.getSetting('timeout'))
    if not headers:
        headers['User-Agent'] = USERAGENT
    if referer != None:
        headers['Referer'] = referer
    try:
        if data: get = s.post(url, headers=headers, data=data, verify=False, timeout=timeout)
        else: get = s.get(url, headers=headers, verify=False, timeout=timeout)
        if rtype: 
            if rtype == 'json': result = get.json()
            else: 
                try: result = get.text.decode('utf-8')
                except: result = get.text.decode('latin-1')
        else:
            if raw:
                result = get.content
            else:
                try: result = get.content.decode('utf-8')
                except: result = get.content.decode('latin-1')
        if savecookie:
            return (result, s)
        else:
            return (result)
    except BaseException as e:
        log(' %s makeRequest(%s) exception: %s' % (name, url, str(e)))
        return
    
def tempdir():
        if py3: dirname = xbmcvfs.translatePath('special://temp')
        else: dirname = xbmc.translatePath('special://temp')
        for subdir in ('xbmcup', 'plugin.video.torrenter'):
            dirname = os.path.join(dirname, subdir)
            if not os.path.exists(dirname):
                os.mkdir(dirname)
        return dirname

def md5(string):
        hasher = hashlib.md5()
        hasher.update(string)
        return hasher.hexdigest()

def saveTorrentFile(url, content):
    try:
        temp_dir = tempfile.gettempdir()
    except:
        temp_dir = tempdir()
    localFileName = os.path.join(temp_dir,md5(url)+".torrent")
    localFile = open(localFileName, 'wb+')
    localFile.write(content)
    localFile.close()
    return localFileName

def clear_title(s):
        return striphtml(unescape(s)).replace('   ', ' ').replace('  ', ' ').strip()

class datascene:
    
    base_url = 'datascene.net'
    thumb = os.path.join(media, 'datascene.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'DataScene'
    username = __settings__.getSetting("DSusername")
    password = __settings__.getSetting("DSpassword")
    headers = {'Host': base_url,
               'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
               'Referer': 'https://' + base_url + '/',
               'X-Requested-With': 'XMLHttpRequest'}

    sortare = [('După dată', ''),
               ('După mărime', '&sort=5&type=desc'),
               ('După downloads', '&sort=6&type=desc'),
               ('După seederi', '&sort=7&type=desc'),
               ('După leecheri', '&sort=8&type=desc')]
    
    categorii = [('Anime/Cartoons', '&cat=3'),
             ('Movies/Pack', '&cat=27'),
             ('Movies/Pack-Ro', '&cat=63'),
             ('Movies 3D', '&cat=46'),
             ('Movies/Cam', '&cat=26'),
             ('Movies/Documentary', '&cat=25'),
             ('Movies/DVD-R', '&cat=24'),
             ('Movies/DVD-RO', '&cat=32'),
             ('Movies/HD', '&cat=23'),
             ('Movies/HD-RO', '&cat=31'),
             ('Movies/Blu-ray', '&cat=50'),
             ('Movies/Blu-Ray Ro', 'cat=51'),
             ('Movies/4k', '&cat=55'),
             ('Movies/4k-Ro', '&cat=59'),
             ('Movies/Hindi', '&cat=34'),
             ('Movies/SD', '&cat=30'),
             ('Movies/SD-Ro', '&cat=36'),
             ('Music/Video', '&cat=21'),
             ('Sport', '&cat=14'),
             ('TV/SD-Ro', '&cat=58'),
             ('TV/HD-Ro', '&cat=57'),
             ('TV/SD', '&cat=28'),
             ('TV/HD', '&cat=47'),
             ('TV/Pack-Ro', '&cat=61'),
             ('TV/Pack', '&cat=54')]
    menu = [('Recente', "https://%s/browse.php?page=0" % base_url, 'recente', thumb)]
    l = []
    for x in categorii:
        l.append((x[0], 'https://%s/browse.php?search=&blah=0%s&incldead=1' % (base_url, x[1]), 'sortare', thumb))
    menu.extend(l)
    menu.extend([('XXX', 'https://%s/browsex.php?search=&blah=0%s&incldead=1' % (base_url, '&cat=12'), 'sortare', thumb)])
    menu.extend([('Căutare', base_url, 'cauta', searchimage)])
    base_url = base_url

    def cauta(self, keyword):
        url = 'https://%s/browse.php?search=%s&blah=0&cat=0&incldead=1&sort=7&type=desc' % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def login(self):
        data = {
            'password': self.password,
            'username': self.username,
            'submit': 'SIGN+IN+NOW'
        }
        log('Log-in  attempt')
        headers = {'Host': self.base_url,
                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Referer': 'https://' + self.base_url + '/connect.php',
                   'X-Requested-With': 'XMLHttpRequest',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Content-Type': 'application/x-www-form-urlencoded',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3'}
        x, session = makeRequest('https://%s/connect.php' % (self.base_url), name=self.__class__.__name__, data=data, headers=headers, savecookie=True)
        if re.search('logout.php', x):
            log('LOGGED DataScene')
        if re.search('incorrect.+?try again', x, re.IGNORECASE):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('DataScene Login Error', 'Parola/Username incorecte')))
            clear_cookie(self.__class__.__name__)
        save_cookie(self.__class__.__name__, session)
        try: cookiesitems = session.cookies.iteritems()
        except: cookiesitems = session.cookies.items()
        for cookie, value in cookiesitems:
            if cookie == 'pass' or cookie == 'uid' or cookie == 'username':
                return cookie + '=' + value
        return False

    def check_login(self, response=None):
        if None != response and 0 < len(response):
            if re.compile('<input.+?type="password"').search(response):
                log('DataScene Not logged!')
                self.login()
                return False
            if re.search('incorrect.+?try again', response, re.IGNORECASE):
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('DataScene Login Error', 'Parola/Username incorecte')))
                clear_cookie(self.__class__.__name__)
        return True


    def getTorrentFile(self, url):
        content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        if not self.check_login(content):
            content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        if re.search("<html", content):
            msg = re.search('Username or password incorrect', content)
            if msg:
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('DataScene Login Error', 'Parola/Username incorecte')))
            xbmc.sleep(4000)
            sys.exit(1)
        return saveTorrentFile(url, content)

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                if not self.check_login(response):
                    response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                regex = '''<tr\s+class="(?:browse|sticky)?"(.+?)</td>\n</tr>'''
                regex_tr = '''(?:.+?href="browse\.php\?(.+?)")?(?:.+?title="(.+?)")?(?:.+?img[src\=\s]+(ht.+?)\s+width=.+?;)?.+?"\s+>(.+?)<.+?href="(/download.+?)".+?align=center>(.+?)</td.+?(?:toseeder)?.+?>(\d+)<.+?<td.+?>(\d+)<'''
                if None != response and 0 < len(response):
                    if re.compile('<input.+?type="password"').search(response):
                        xbmc.executebuiltin((u'Notification(%s,%s)' % ('DataScene', 'Eroare la login')))
                    for block in re.compile(regex, re.DOTALL).findall(response):
                        result = re.compile(regex_tr, re.DOTALL).findall(block)
                        if result:
                            for cat, tip, imagine, nume, legatura, size, seeds, leechers in result:
                                nume = htmlparser.HTMLParser().unescape(nume.decode('iso-8859-1'))
                                nume = '%s %s' % (('[COLOR lime]FREE[/COLOR] ' if re.findall('id=free-btn', block) else ''), nume)
                                legatura = 'https://%s%s' % (self.base_url, legatura)
                                size = striphtml(size)
                                seeds = ''.join(str(seeds).split()) if seeds else '-1'
                                nume = '%s  (%s) [S/L: %s/%s] ' % (nume, size, seeds, leechers)
                                size = formatsize(size)
                                tip = tip if tip else 'nespecificat'
                                imagine = imagine or self.thumb
                                plot = '%s %s' % (tip, nume.encode('utf-8'))
                                info = {'Title': nume,
                                        'Plot': plot,
                                        'Genre': tip,
                                        'Size': size,
                                        'Poster': imagine}
                                if not (seeds == '0' and not zeroseed):
                                    for r,t in self.categorii:
                                        if (re.search(cat, t) and not (cat == 'cat=2' or cat == 'cat=6')) or not cat:
                                            try:
                                                imdb = re.search('imdb.com/title/(.+?)(?:/|\s+)', block).group(1)
                                                trailerlink = 'https://www.imdb.com/title/%s/' % imdb
                                                info['Trailer'] = '%s?action=GetTrailerimdb&link=%s&nume=%s&poster=%s&plot=%s' % (sys.argv[0], quote(trailerlink), quote(nume), quote(imagine), quote(plot))
                                                info['imdb'] = imdb
                                            except: pass
                                            lists.append((nume,legatura,imagine,'torrent_links', info))
                                            break
                    match = re.compile('ncls".+?page\=', re.IGNORECASE | re.DOTALL).findall(response)
                    if len(match) > 0:
                        if 'page=' in url:
                            new = re.compile('page=(\d+)').findall(url)
                            nexturl = re.sub('page=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=1')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            turl = self.getTorrentFile(url)
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
    
class eztv:
    
    base_url = 'eztv.re'
    thumb = os.path.join(media, 'eztv.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'EZTV'
    build_url = 'https://%s/api?url=/q.php?q=' % base_url
    tracker_list = 'https://%s/static/main.js' % base_url
    menu = [('Recente', "https://%s/page_0" % (base_url), 'recente', thumb),
            ('Lista Seriale', "https://%s/showlist/" % (base_url), 'showlist', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
    
    headers = {'Host': base_url,
               'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
               'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}

    def cauta(self, keyword):
        url = "https://%s/search/%s" % (self.base_url, keyword.replace(" ", "-"))
        #url = "https://%s/search/?q1=%s&q2=&search=Search" % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                regex_table = '''\<tr\sname="hover"\s+class="forum_header_border"(.+?)\</tr\>'''
                regex_details = '''epinfo"\>(.+?)\<.+?href="(magnet.+?)".+?post"\>(.+?)\<.+?post"\>(.+?)\<.+?end"\>(.+?)\<'''
                link = fetchData(url, headers=self.headers)
                if link:
                    tables = re.findall(regex_table, link, re.DOTALL)
                    if tables:
                        imagine = self.thumb
                        if info:
                            try:
                                info = eval(info)
                                imagine = info.get('Poster') or self.thumb
                            except: pass
                        for table in tables:
                            show = re.findall(regex_details, table, re.DOTALL)
                            if show:
                                nume, legatura, marime, adaugat, seeds = show[0]
                                nume = ensure_str(nume)
                                seeds = ''.join(str(seeds).split()) if seeds else '-1'
                                seeds = striphtml(seeds) if not seeds == '-' else '0'
                                leechs = '0'
                                size = striphtml(marime).strip()
                                nume = '%s [COLOR green]%s[/COLOR] (%s) [S/L: %s/%s] ' % (nume, adaugat, size, seeds, leechs)
                                size = formatsize(marime)
                                info = {'Title': nume,
                                        'Plot': nume,
                                        'Size': size,
                                        'Poster': imagine}
                                if not (seeds == '0' and not zeroseed):
                                    lists.append((nume,legatura,imagine,'torrent_links', info))
                        new = re.findall('/page_(\d+)', unquote(url))
                        try: new = new[0]
                        except: new = ''
                        if new:
                            nexturl = re.sub('/page_(\d+)', '/page_%s' % (int(new) + 1), unquote(url))
                        else:
                            nexturl = ''
                        if nexturl:
                            lists.append(('Next', nexturl, self.nextimage, 'recente', {}))
        elif meniu == "showlist":
            regex = '''\<tr\s+name="hover"\>(.+?)\</tr'''
            regex_details = '''img\s+src="(.+?)".+?href="(.+?)".+?\>(.+?)\<.+?post"\>(.+?)\<.+?post".+?\>(.+?)\</td'''
            data = {'showlist_thumbs': "on",
                    'status': ""}
            link = fetchData(url, headers=self.headers, data=data)
            if link:
                tables = re.findall(regex, link, re.DOTALL)
                if tables:
                    for table in tables:
                        show = re.findall(regex_details, table, re.DOTALL)
                        if show:
                            imagine, legatura, nume, status, votes = show[0]
                            imagine = 'https://%s%s' % (self.base_url, imagine)
                            legatura = 'https://%s%s' % (self.base_url, legatura)
                            nume = ensure_str(nume)
                            status = striphtml(status).strip()
                            votes = " ".join(striphtml(votes).split())
                            nume += ' [COLOR lime]Status: [/COLOR][COLOR blue]%s[/COLOR] Rating: %s' % (status, votes.strip())
                            info = {'Title': nume,
                                    'Plot': nume,
                                    'Poster': imagine}
                            lists.append((nume,legatura,imagine,'get_torrent', info))
                            
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists

class filelist:
    
    base_url = 'filelist.io'
    thumb = os.path.join(media, 'filelist.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'FileList'
    headers = {'Origin': 'https://' + base_url,
               'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
               'Referer': 'https://' + base_url + '/',
               'X-Requested-With': 'XMLHttpRequest',
               'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
               'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3',
               'Host': base_url}

    sortare = [('Hibrid', '&sort=0'),
               ('Relevanță', '&sort=1'),
               ('După dată', '&sort=2'),
               ('După mărime', '&sort=3'),
               ('După downloads', '&sort=4'),
               ('După peers', '&sort=5')]
    
    token = '&usetoken=1'
    
    categorii = [('Anime', 'cat=24'),
             ('Desene', 'cat=15'),
             ('Filme 3D', 'cat=25'),
             ('Filme 4k', 'cat=6'),
             ('Filme 4k Blu-Ray', 'cat=26'),
             ('Filme Blu-Ray', 'cat=20'),
             ('Filme DVD', 'cat=2'),
             ('Filme DVD-RO', 'cat=3'),
             ('Filme HD', 'cat=4'),
             ('Filme HD-RO', 'cat=19'),
             ('Filme SD', 'cat=1'),
             ('Seriale 4k', 'cat=27'),
             ('Seriale HD', 'cat=21'),
             ('Seriale SD', 'cat=23'),
             ('Sport', 'cat=13'),
             ('Videoclip', 'cat=12'),
             ('XXX', 'cat=7')]
    menu = [('Recente', "https://%s/browse.php?cats[]=24&cats[]=15&cats[]=25&cats[]=6&cats[]=26&cats[]=20&cats[]=2&cats[]=3&cats[]=4&cats[]=19&cats[]=1&cats[]=27&cats[]=21&cats[]=23&cats[]=13&cats[]=12&incldead=0" % base_url, 'recente', thumb)]
    l = []
    for x in categorii:
        l.append((x[0], 'https://%s/browse.php?%s' % (base_url, x[1]), 'get_torrent', thumb))
    menu.extend(l)
    menu.extend([('Căutare', base_url, 'cauta', searchimage)])

    def cauta(self, keyword):
        url = "https://%s/browse.php?search=%s&cat=0&searchin=1&sort=5" % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def login(self):
        username = __settings__.getSetting("FLusername")
        password = __settings__.getSetting("FLpassword")
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3',
                   'Host': self.base_url}
        w, session = makeRequest('https://%s/login.php' % (self.base_url), name=self.__class__.__name__, headers=headers, savecookie=True)
        save_cookie(self.__class__.__name__, session)
        validator = re.findall("validator.*value='(.+?)'", w)[0]
        if not (password or username):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', 'lipsa username si parola din setari')))
            return False
        data = {
            'validator': validator,
            'password': password,
            'username': username,
            'unlock': '1',
            'returnto': '/'
        }
        headers = {'Origin': 'https://' + self.base_url,
                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Referer': 'https://' + self.base_url + '/',
                   'X-Requested-With': 'XMLHttpRequest',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3',
                   'Host': self.base_url}
        xbmc.sleep(1000)
        x, session = makeRequest('https://%s/takelogin.php' % (self.base_url), name=self.__class__.__name__, data=data, headers=headers, savecookie=True)
        if re.search('logout.php', x):
            log('LOGGED FileListRO')
        elif re.search('Numarul maxim permis de actiuni a fost depasit', x):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', u'Site in protectie, reincearca peste o ora')))
            clear_cookie(self.__class__.__name__)
        elif re.search('User sau parola gresite\.', x):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', u'Parola/User gresite, verifica-le')))
            clear_cookie(self.__class__.__name__)
        else:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', u'Probleme la logare')))
            clear_cookie(self.__class__.__name__)
        xbmc.sleep(1000)
        save_cookie(self.__class__.__name__, session)
        try: cookiesitems = session.cookies.iteritems()
        except: cookiesitems = session.cookies.items()
        for cookie, value in cookiesitems:
            if cookie == 'pass':
                return cookie + '=' + value
        return False

    def check_login(self, response=None):
        if None != response and 0 < len(response):
            if re.compile('<input type=\'password\'').search(response) or \
                re.compile('<title> FileList :: Login </title>').search(response):
                log('FileList Not logged!')
                clear_cookie(self.__class__.__name__)
                self.login()
                return False
        return True

    def getTorrentFile(self, url):
        content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        if not self.check_login(content):
            content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        if re.search("<html", content):
            msg = re.search('User sau parola gresite', content)
            if msg:
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList Login Error', 'Parola/Username incorecte')))
            xbmc.sleep(4000)
            sys.exit(1)
        return saveTorrentFile(url, content)

    def parse_menu(self, url, meniu, info={}, torraction=None):
        yescat = ['24', '15', '25', '6', '26', '20', '2', '3', '4', '19', '1', '27', '21', '23', '13', '12']
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            import unicodedata
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                if not self.check_login(response):
                    response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                regex = '''<div class='torrentrow'>(.+?)</div></div>'''
                regex_tr = '''php\?cat\=(\d+)'.+?alt\='(.+?)'.+?(?:.+?img src\='(.+?)')?.+?details.+?title\='(.+?)'.+?(?:.small'\>(.+?)\<.+?)?:.+?\<a href\="(download\.php\?id\=.+?)".+?small'\>(\d+\.\d+.+?)\<.+?(?:.+?(?:#[\d\w]+|table-cell;')\>([\d\.,]+)\<)?.+?(?:\<b\>|;'\>)([\d,\.]+)\<'''
                if None != response and 0 < len(response):
                    for block in re.compile(regex, re.DOTALL).findall(response):
                        result = re.compile(regex_tr, re.DOTALL).findall(block)
                        if result:
                            for cat, catnume, imagine, nume, genre, legatura, size, seeds, leechers in result:
                                #nume = ''.join(c for c in unicodedata.normalize('NFKD', u'%s' % nume.decode('utf-8'))
                                        #if unicodedata.category(c) != 'Mn')
                                nume = replaceHTMLCodes(nume)
                                nume = ('[COLOR blue]2XUPLOAD[/COLOR] ' if re.findall('doubleup.png', block) else '') + nume
                                nume = ('[COLOR royalblue]INTERNAL[/COLOR] ' if re.findall('internal.png', block) else '') + nume
                                nume = ('[COLOR lime]FREELEECH[/COLOR] ' if re.findall('freeleech.png', block) else '') + nume
                                legatura = 'https://%s/%s' % (self.base_url, legatura)
                                size = striphtml(size)
                                seeds = ''.join(str(seeds).split()) if seeds else '-1'
                                nume = '%s  [COLOR green]%s[/COLOR] (%s) [S/L: %s/%s] ' % (nume, catnume, size, seeds, leechers)
                                imagine = imagine or self.thumb
                                try: genre = ensure_str(genre)
                                except: pass
                                size = formatsize(size)
                                info = {'Title': nume,
                                        'Plot': nume,
                                        'Genre': genre,
                                        'Size': size,
                                        'Label2': self.name,
                                        'Poster': imagine}
                                if not (seeds == '0' and not zeroseed):
                                    if '?search=' in url:
                                        if str(cat) in yescat :
                                            lists.append((nume,legatura,imagine,'torrent_links', info))
                                    else: lists.append((nume,legatura,imagine,'torrent_links', info))
                    match = re.compile("'pager'.+?\&page=", re.IGNORECASE | re.DOTALL).findall(response)
                    if len(match) > 0:
                        if '&page=' in url:
                            new = re.compile('\&page\=(\d+)').findall(url)
                            nexturl = re.sub('\&page\=(\d+)', '&page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=1')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            turl = self.getTorrentFile(url)
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
    
class fluxzone:
    
    base_url = 'fluxzone.org'
    thumb = os.path.join(media, 'fluxzone.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'FluxZone'
    username = __settings__.getSetting("FZusername")
    password = __settings__.getSetting("FZpassword")
    headers = {'Host': base_url,
               'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
               'Referer': 'http://' + base_url + '/',
               'Host': base_url}

    sortare = [('După dată', '&sort=4&type=desc'),
               ('După mărime', '&sort=5&type=desc'),
               ('După downloads', '&sort=6&type=desc'),
               ('După seederi', '&sort=7&type=desc'),
               ('După leecheri', '&sort=8&type=desc')]
    
    categorii = [('Anime', 'cat=1'),
             ('Anime-RO', 'cat=42'),
             ('Filme Pack', 'cat=18'),
             ('Filme 3D', 'cat=39'),
             ('Filme DVD', 'cat=9'),
             ('Filme DVD-RO', 'cat=10'),
             ('Filme HD', 'cat=11'),
             ('Filme HD-RO', 'cat=12'),
             ('Filme Blu-ray', 'cat=5'),
             ('Filme Blu-Ray-RO', 'cat=5'),
             ('Filme 4k', 'cat=8'),
             ('Filme SD', 'cat=24'),
             ('Filme SD-RO', 'cat=25'),
             ('Muzica/Videoclip', 'cat=28'),
             ('Sport', 'cat=32'),
             ('Seriale SD', 'cat=21'),
             ('Seriale HD', 'cat=81'),
             ('Seriale 4k', 'cat=79'),
             ('XXX', 'cat=27')]
    menu = [('Recente', "http://%s/browse.php?all=1" % base_url, 'recente', thumb)]
    l = []
    for x in categorii:
        l.append((x[0], 'http://%s/browse.php?search=&blah=0&%s&incldead=1' % (base_url, x[1]), 'sortare', thumb))
    menu.extend(l)
    menu.extend([('Căutare', base_url, 'cauta', searchimage)])
    base_url = base_url

    def cauta(self, keyword):
        url = 'http://%s/browse.php?search=%s&blah=0&cat=0&incldead=1&sort=7&type=desc' % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def login(self):
        data = {
            'password': self.password,
            'username': self.username,
            'takelogin': '1',
            'returnto': '/'
        }
        log('Log-in  attempt')
        headers = {'Host': self.base_url,
                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Referer': 'http://' + self.base_url + '/login.php',
                   'X-Requested-With': 'XMLHttpRequest',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Content-Type': 'application/x-www-form-urlencoded',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3'}
        x, session = makeRequest('http://%s/takelogin.php' % (self.base_url), name=self.__class__.__name__, data=data, headers=headers, savecookie=True)
        if re.search('logout.php', x):
            log('LOGGED FluxZone')
        if re.search('Username or password incorrect', x):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FluxZone Login Error', 'Parola/Username incorecte')))
            clear_cookie(self.__class__.__name__)
        save_cookie(self.__class__.__name__, session)
        try: cookiesitems = session.cookies.iteritems()
        except: cookiesitems = session.cookies.items()
        for cookie, value in cookiesitems:
            if cookie == 'pass' or cookie == 'uid':
                return cookie + '=' + value
        return False

    def check_login(self, response=None):
        if None != response and 0 < len(response):
            if re.compile('<input type="password"').search(response) or \
                re.compile('Not logged in').search(response):
                log('FluxZone Not logged!')
                self.login()
                return False
            if re.search('Username or password incorrect', response):
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('FluxZone Login Error', 'Parola/Username incorecte')))
                clear_cookie(self.__class__.__name__)
        return True

    def getTorrentFile(self, url):
        content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        if not self.check_login(content):
            content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        if re.search("<html", content):
            msg = re.search('Username or password incorrect', content)
            if msg:
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('FluxZone Login Error', 'Parola/Username incorecte')))
            xbmc.sleep(4000)
            sys.exit(1)
        return saveTorrentFile(url, content)

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                if not self.check_login(response):
                    response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                regex = '''<tr class="browse"(.+?)</td>\n</tr>'''
                regex_tr = '''\?(cat=\d+).+?<b>(.+?)</b>.+?(?:(\[.+?\]).+?)?href="(download\.php.+?)".+?align=center>.+?>([0-9.]+<br>.+?)</f.+?>([0-9]+)</font>.+?([0-9]+)</font>'''
                if None != response and 0 < len(response):
                    if re.compile('Not logged in').search(response):
                        xbmc.executebuiltin((u'Notification(%s,%s)' % ('FluxZone', 'lipsa username si parola din setari')))
                    for block in re.compile(regex, re.DOTALL).findall(response):
                        result = re.compile(regex_tr, re.DOTALL).findall(block)
                        if result:
                            for cat, nume, genre, legatura, size, seeds, leechers in result:
                                for r,t in self.categorii:
                                    if re.search(cat, t):
                                        size = striphtml(size)
                                        nume = ('[COLOR lime]FREE[/COLOR] ' if re.findall('freetorrent.png', block) else '') + replaceHTMLCodes(nume)
                                        seeds = ''.join(str(seeds).split()) if seeds else '-1'
                                        nume = '%s  [COLOR green]%s[/COLOR] (%s) [S/L: %s/%s] ' % (nume, r, size, seeds, leechers)
                                        legatura = 'http://%s/%s' % (self.base_url, legatura)
                                        imagine = self.thumb
                                        tip = genre or ''
                                        size = formatsize(size)
                                        info = {'Title': nume,
                                                'Plot': '%s %s' % (tip, nume),
                                                'Genre': tip,
                                                'Size': size,
                                                'Poster': imagine}
                                        if not (seeds == '0' and not zeroseed):
                                            lists.append((nume,legatura,imagine,'torrent_links', info))
                                        break
                    match = re.compile('pager".+?page=', re.IGNORECASE | re.DOTALL).findall(response)
                    if len(match) > 0:
                        if 'page=' in url:
                            new = re.compile('page=(\d+)').findall(url)
                            nexturl = re.sub('page=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=1')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            turl = self.getTorrentFile(url)
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists

class ieet:
    
    base_url = 'www.1337x.to'
    thumb = os.path.join(media, 'ieetx.png')
    nextimage = next_icon
    searchimage = search_icon
    name = '1337x'
    menu = [('Recente', "https://%s/cat/Movies/1/" % base_url, 'recente', thumb),
            ('Seriale Recente', "https://%s/cat/TV/1/" % base_url, 'get_torrent', thumb),
            #('Categorii Filme', "https://%s/movie-lib-sort/%s/%s/desc/%s/1/", 'categorii', thumb),
            ('Filme', "https://%s/%s/Movies/%s/", 'sortare', thumb),
            ('Seriale', "https://%s/%s/TV/%s/", 'sortare', thumb),
            ('Documentare', "https://%s/%s/Documentaries/%s/", 'sortare', thumb),
            ('Anime', "https://%s/%s/Anime/%s/", 'sortare', thumb),
            ('Adulți', "https://%s/%s/XXX/%s/", 'sortare', thumb),
            ('Librarie Filme', "https://%s/movie-library/1/" % base_url, 'librarie', thumb),
            ('Filme populare in ultimele 24 ore', "https://%s/popular-movies" % base_url, 'get_torrent', thumb),
            ('Filme populare saptamana asta', "https://%s/popular-movies-week" % base_url, 'get_torrent', thumb),
            ('Top 100 Documentare', "https://%s/top-100-documentaries" % base_url, 'get_torrent', thumb),
            ('Top 100 Filme ', "https://%s/top-100-movies" % base_url, 'get_torrent', thumb),
            ('Top 100 TV ', "https://%s/top-100-television" % base_url, 'get_torrent', thumb),
            ('Top 100 Filme în engleză ', "https://%s/top-100-eng-movies" % base_url, 'get_torrent', thumb),
            ('Top 100 Filme în alte limbi ', "https://%s/top-100-non-eng-movies" % base_url, 'get_torrent', thumb),
            ('Top 100 Anime', "https://%s/top-100-anime" % base_url, 'get_torrent', thumb),
            ('Top 100 Adulți', "https://%s/top-100-xxx" % base_url, 'get_torrent', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]

    def cauta(self, keyword):
        url = "https://%s/sort-search/%s/seeders/desc/1/" % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def get_cat(self):
        cats = []
        link = fetchData('https://%s/movie-library/1/' % self.base_url)
        regex = '''select name="genre"(.+?)</select'''
        sub_regex = '''value="(.+?)">(.+?)<'''
        match = re.findall(regex, link, re.IGNORECASE | re.DOTALL)
        if match:
            for result in match:
                match2 = re.findall(sub_regex, result, re.IGNORECASE | re.DOTALL)
                if match2:
                    for legatura, nume in match2:
                        cats.append((legatura.replace(" ", "+").replace("-", "+"), nume))
        return cats
    
    def get_ani(self):
        ani = []
        link = fetchData('https://%s/movie-library/1/' % self.base_url)
        regex = '''select name="year"(.+?)</select'''
        sub_regex = '''value="(.+?)">(.+?)<'''
        match = re.findall(regex, link, re.IGNORECASE | re.DOTALL)
        if match:
            for result in match:
                match2 = re.findall(sub_regex, result, re.IGNORECASE | re.DOTALL)
                if match2:
                    for legatura, nume in match2:
                        ani.append((legatura.replace(" ", "+").replace("-", "+"), nume))
        return ani
    
    def get_lang(self):
        lang = []
        link = fetchData('https://%s/movie-library/1/' % self.base_url)
        regex = '''select name="lang"(.+?)</select'''
        sub_regex = '''value="(.+?)">(.+?)<'''
        match = re.findall(regex, link, re.IGNORECASE | re.DOTALL)
        if match:
            for result in match:
                match2 = re.findall(sub_regex, result, re.IGNORECASE | re.DOTALL)
                if match2:
                    for legatura, nume in match2:
                        lang.append((legatura.replace(" ", "+").replace("-", "+"), nume))
        return lang
    
    def get_score(self):
        score = [('score', 'Movie Score'),
                 ('popularity', 'Popularity'),
                 ('release', 'Release Date'),
                 ('latest', 'Latest Submited')]
        return score
    
    def get_sort(self): #sort-cat/Movies/time/desc/1/
        score = [('1', 'Default'),
                 ('time/desc/1', 'Time'),
                 ('size/desc/1', 'Size'),
                 ('seeders/desc/1', 'Seeders'),
                 ('leechers/desc/1', 'Leechers')]
        return score
    
    def get_ascend(self):
        ascend = [('desc', 'Descending'),
                  ('asc', 'Ascending')]
        return ascend
    
    def parse_menu(self, url, meniu, info={}, torraction=None):
        #log(self.get_cat())
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'librarie':
            link = fetchData(url)
            regex = '''data-target.+?original="(.+?)".+?header">(.+?)<div.+?category">(.+?)</div.+?"content.+?">(.+?)</div.+?download".+?href="(.+?)"'''
            if re.search("/1/", url):
                lists.append(('[COLOR lime]Categorii[/COLOR]',"https://%s/movie-lib-sort/%s/all/score/desc/all/1/",self.thumb,'categorii', {}))
                lists.append(('[COLOR lime]Ani[/COLOR]',"https://%s/movie-lib-sort/all/all/score/desc/%s/1/",self.thumb,'ani', {}))
                lists.append(('[COLOR lime]Limba[/COLOR]',"https://%s/movie-lib-sort/all/%s/score/desc/all/1/",self.thumb,'lang', {}))
            if link:
                match = re.findall(regex, link, re.DOTALL)
                for imagine, nume, categorie, descriere, legatura in match:
                    imagine = 'http:%s' % (imagine) if imagine.startswith('//') else imagine
                    #log(imagine)
                    legatura = 'https://%s%s' % (self.base_url, legatura)
                    descriere = ensure_str(replaceHTMLCodes(striphtml(descriere))).strip()
                    nume = ensure_str(replaceHTMLCodes(striphtml(nume))).strip()
                    info = {'Title': nume,
                        'Plot': descriere,
                        'Poster': imagine}
                    lists.append((nume,legatura,imagine,'get_torrent', info))
                match = re.findall('("pagination")', link, re.IGNORECASE)
                if len(match) > 0:
                    if re.search("/(\d+)/", url):
                        new = re.compile('/(\d+)/').findall(url)
                        nexturl = re.sub('/(\d+)/', '/' + str(int(new[0]) + 1) + '/', url)
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                if link:
                    infos = {}
                    regex = '''<tr>(.+?)</tr>'''
                    regex_tr = '''a><a href="(.+?)">(.+?)<.+?seeds">(.+?)<.+?leeches">(.+?)<.+?size.+?>(.+?)<'''
                    tables = re.findall(regex, link, re.IGNORECASE | re.DOTALL)
                    if tables:
                        for table in tables:
                            match = re.findall(regex_tr, table, re.IGNORECASE | re.DOTALL)
                            if match:
                                for legatura, nume, seeds, leechers, size in match:
                                    size = size.replace('&nbsp;', ' ')
                                    seeds = ''.join(str(seeds).split()) if seeds else '-1'
                                    legatura = 'https://%s%s' % (self.base_url, legatura) if legatura.startswith('/') else legatura
                                    nume = '%s  (%s) [S/L: %s/%s] ' % (striphtml(nume), size, seeds, leechers)
                                    size = formatsize(size)
                                    if not info:
                                        infos = {'Title': nume,
                                                'Plot': nume,
                                                'Size': size,
                                                'Poster': self.thumb}
                                    else:
                                        infos = info
                                        try:

                                            infos = eval(str(infos))
                                            infos['Size'] = size
                                            infos['Plot'] = '%s - %s' % (nume, infos['Plot'])
                                        except: pass
                                        #infos.update({'Plot': '%s - %s' % (nume, infos['Plot'])})
                                    if not (seeds == '0' and not zeroseed):
                                        lists.append((nume,legatura,self.thumb,'torrent_links', infos))
                    match = re.compile('"pagination"', re.IGNORECASE).findall(link)
                    if len(match) > 0:
                        if re.search("/(\d+)/", url):
                            new = re.compile('/(\d+)/').findall(url)
                            nexturl = re.sub('/(\d+)/', '/' + str(int(new[0]) + 1) + '/', url)
                            lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'categorii' or meniu == 'ani' or meniu == 'lang':
            if meniu == 'categorii': categorii = self.get_cat()
            elif meniu == 'ani': categorii = self.get_ani()
            elif meniu == 'lang': categorii = self.get_lang()
            if categorii:
                for legatura, nume in categorii:
                    legatura = url % (self.base_url, legatura)
                    lists.append((nume,legatura,imagine,'librarie', info))
        elif meniu == 'sortare':
            sort = self.get_sort()
            if sort:
                for legatura, nume in sort:
                    if nume == 'Default':
                        legatura = url % (self.base_url, 'cat', legatura)
                    else:
                        legatura = url % (self.base_url, 'sort-cat' ,legatura)
                    lists.append((nume,legatura,imagine,'get_torrent', info))
        elif meniu == 'torrent_links':
            link = fetchData(url)
            try: surl = re.compile('href="(magnet:.+?)"', re.DOTALL).findall(link)[0]
            except: surl = None
            action = torraction if torraction else ''
            if surl: openTorrent({'Tmode':torraction, 'Turl': surl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
    
class kickass:
    
    base_url = 'katcr.to'
    thumb = os.path.join(media, 'kickass.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'Kickass'
    menu = [('Recente', "https://%s/new/" % base_url, 'recente', thumb),
            ('Filme', "https://%s/movies/" % base_url, 'sortare', thumb),
            ('Seriale', "https://%s/tv/" % base_url, 'sortare', thumb),
            ('Documentare', "https://%s/documentaries/" % base_url, 'sortare', thumb),
            ('Anime', "https://%s/anime/" % base_url, 'sortare', thumb),
            ('XXX', "https://%s/xxx/" % base_url, 'sortare', thumb),
            ('Filme populare', "https://%s/popular-movies" % base_url, 'sortare', thumb),
            ('Seriale populare', "https://%s/popular-tv" % base_url, 'sortare', thumb),
            ('Anime populare', "https://%s/popular-anime/" % base_url, 'sortare', thumb),
            ('XXX populare', "https://%s/popular-xxx/" % base_url, 'sortare', thumb),
            ('Filme Top 100', "https://%s/top-100-movies" % base_url, 'get_torrent', thumb),
            ('Seriale Top 100', "https://%s/top-100-television" % base_url, 'get_torrent', thumb),
            ('Anime Top 100', "https://%s/top-100-anime" % base_url, 'get_torrent', thumb),
            ('XXX Top 100', "https://%s/top-100-xxx" % base_url, 'get_torrent', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]

    sortare = [('Recent adăugate', '?sortby=time&sort=desc'),
               ('După seederi', '?sortby=seeders&sort=desc'),
               ('După Mărime', '?sortby=size&sort=desc'),
               ('După leecheri', '?sortby=leechers&sort=desc')]

    def cauta(self, keyword):
        url = "https://%s/usearch/%s/?sortby=seeders&sort=desc" % (self.base_url, keyword)
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            accepted = ['Movies', 'TV', 'XXX',  'Documentaries', 'Anime']
            acceptcats = ['VideoType']
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                headers = {'Host': self.base_url, 'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1', 'Referer':'https://%s/' % self.base_url}
                link = fetchData(url, headers=headers)
                #log(link)
                if link:
                    infos = {}
                    regex = '''\<tr class=".+?"(.+?)\</tr\>'''
                    regex_tr = r'''href=".+?href="(.+?)"(?:.+?class="torType(.+?)".+?)?.+?\<a href=".+?html"\s+class=.+?k"\>(.+?)\</a\>.+?(?:.+?in\s+\<span.+?"\>(.+?)\</a\>.+?)?.+?\<td class="nobr center"\>(.+?)\</.+?\<td class="green center"\>([\dN\/A\s]+)\</td\>.+?\<td class="red lasttd center"\>([\dN\/A\s]+)\</td\>'''
                    for trr in re.findall(regex, link, re.IGNORECASE | re.DOTALL):
                        match = re.findall(regex_tr, trr, re.IGNORECASE | re.DOTALL)
                        if match:
                            for legatura, forum1, nume, forum, size, seeds, leechers in match:
                                forum = ''.join(forum.split()) if forum else ''
                                forum1 = ''.join(forum1.split()) if forum1 else ''
                                if forum in accepted or forum1 in acceptcats:
                                    legatura = unquote(re.sub(r'[htps://].+?/.+?\?url=', '', legatura))
                                    legatura = 'https://%s%s' % (self.base_url, legatura)
                                    nume = unescape(striphtml(nume)).decode('utf-8').strip()
                                    seeds = ''.join(str(seeds).split()) if seeds else '-1'
                                    leechers = leechers.strip()
                                    size = striphtml(size).strip()
                                    if seeds == 'N/A' : seeds = '0'
                                    if leechers == 'N/A': leechers = '0'
                                    nume = '%s  [COLOR green]%s[/COLOR] (%s) [S/L: %s/%s] ' % (striphtml(nume), forum, size, seeds, leechers)
                                    size = formatsize(size)
                                    if not info:
                                        infos = {'Title': nume,
                                                'Plot': nume,
                                                'Size': size,
                                                'Poster': self.thumb}
                                    else:
                                        infos = info
                                        try:
                                            infos = eval(str(infos))
                                            infos['Size'] = size
                                            infos['Plot'] = '%s - %s' % (nume, infos['Plot'])
                                        except: pass
                                        #infos.update({'Plot': '%s - %s' % (nume, infos['Plot'])})
                                    if not (seeds == '0' and not zeroseed):
                                        lists.append((nume,legatura,self.thumb,'torrent_links', infos))
                    match = re.findall('(class="pages)', link, re.IGNORECASE)
                    if len(match) > 0:
                        if re.search("/(\d+)/", url): 
                            new = re.findall("/(\d+)/", url)
                            nexturl = re.sub('/(\d+)/', '/%s/' % (str(int(new[0]) + 1)), url)
                        else:
                            try:
                                newn = re.search(r'(.*)/\?(.*)',url)
                                nexturl = '%s/2/?%s' % (newn.group(1), newn.group(2))
                            except: 
                                nexturl = ('%s2/' % url) if url.endswith('/') else ''
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            headers = {'Host': self.base_url, 
                       'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                       'Referer':'https://%s/' % self.base_url}
            link = fetchData(url, headers=headers)
            turl = ''
            if link:
                torrent = re.findall('href="(magnet.+?)"', link)
                if torrent:
                    turl = torrent[0]
            action = torraction if torraction else ''
            if turl:
                openTorrent({'Tmode':torraction, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
    
class kickass2:
    
    base_url = 'thekat.app'
    thumb = os.path.join(media, 'kickass2.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'Kickass2'
    menu = [('Recente', "https://%s/new/" % base_url, 'recente', thumb),
            ('Filme', "https://%s/movies/" % base_url, 'recente', thumb),
            ('Seriale', "https://%s/tv/" % base_url, 'recente', thumb),
            ('XXX', "https://%s/xxx/" % base_url, 'recente', thumb),
            ('Toate', "https://%s/full/" % base_url, 'recente', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]

    sortare = [('Recent adăugate', '?field=time_add&sorder=desc'),
               ('După seederi', '?field=seeders&sorder=desc'),
               ('După Mărime', '?field=size&sorder=desc'),
               ('După leecheri', '?field=leechers&sorder=desc')]

    def cauta(self, keyword):
        #https://%s/usearch/%s/?field=seeders&sorder=desc" % (self.baseurl, self.query(keyword)[:1], self.query(keyword), sort
        url = "https://%s/usearch/%s/?field=seeders&sorder=desc" % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            accepted = ['Movies', 'TV', 'XXX']
            acceptcats = ['VideoType']
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                headers = {'User-Agent': randomagent(), 'Referer':'https://%s/' % self.base_url}
                link = fetchData(url, headers=headers)
                #log(link)
                if link:
                    infos = {}
                    regex = '''<tr class=".+?" id=(.+?)</tr>'''
                    regex_tr = r'''title="Download torrent file" href="(.+?)".+?(?:.+?class="torType(.+?)".+?)?<a href=".+?html" class=.+?k">(.+?)</a>.+?(?:.+?in <span.+?"><strong>.+?">(.+?)</a>.+?)?.+?<td class="nobr center">(.+?)</.+?<td class="green center">(\d+?|N/A)</td>.+?<td class="red lasttd center">(?:\s+)?(\d+?|N/A)</td>'''
                    for trr in re.findall(regex, link, re.IGNORECASE | re.DOTALL):
                        match = re.findall(regex_tr, trr, re.IGNORECASE | re.DOTALL)
                        if match:
                            for legatura, forum1, nume, forum, size, seeds, leechers in match:
                                forum = ''.join(forum.split()) if forum else ''
                                forum1 = ''.join(forum1.split()) if forum1 else ''
                                if forum in accepted or forum1 in acceptcats:
                                    legatura = unquote(re.sub(r'[htps://].+?/.+?\?url=', '', legatura))
                                    nume = unescape(striphtml(nume)).decode('utf-8').strip()
                                    size = striphtml(size)
                                    seeds = ''.join(str(seeds).split()) if seeds else '-1'
                                    if seeds == 'N/A' : seeds = '0'
                                    if leechers == 'N/A': leechers = '0'
                                    nume = '%s  [COLOR green]%s[/COLOR] (%s) [S/L: %s/%s] ' % (striphtml(nume), forum, size, seeds, leechers)
                                    size = formatsize(size)
                                    if not info:
                                        infos = {'Title': nume,
                                                'Plot': nume,
                                                'Size': size,
                                                'Poster': self.thumb}
                                    else:
                                        infos = info
                                        try:
                                            infos = eval(str(infos))
                                            infos['Size'] = size
                                            infos['Plot'] = '%s - %s' % (nume, infos['Plot'])
                                        except: pass
                                        #infos.update({'Plot': '%s - %s' % (nume, infos['Plot'])})
                                    if not (seeds == '0' and not zeroseed):
                                        lists.append((nume,legatura,self.thumb,'torrent_links', infos))
                    match = re.findall('(class="pages)', link, re.IGNORECASE)
                    if len(match) > 0:
                        if re.search("/(\d+)(?:$|\?)?", url): 
                            new = re.findall("/(\d+)(?:$|\?)?", url)
                            nexturl = re.sub('/(\d+)', '/' + str(int(new[0]) + 1), url)
                        else:
                            try:
                                newn = re.search(r'(.*)/(.*)',url)
                                nexturl = '%s/2%s' % (newn.group(1), newn.group(2))
                            except: 
                                nexturl = '%s2' % url
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
    
class lime:
    
    base_url = 'www.limetorrents.info'
    thumb = os.path.join(media, 'limetorrents.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'LimeTorrents'
    menu = [('Recente', "https://%s/latest100" % base_url, 'recente', thumb),
            ('Filme', "https://%s/browse-torrents/Movies/" % base_url, 'sortare', thumb),
            ('Seriale', "https://%s/browse-torrents/TV-shows/" % base_url, 'sortare', thumb),
            ('Seriale Clasice', "https://%s/browse-torrents/TV-shows-Classics/" % base_url, 'sortare', thumb),
            ('Anime', "https://%s/browse-torrents/Anime/" % base_url, 'sortare', thumb),
            ('Altele', "https://%s/browse-torrents/Other-Other/", 'sortare', thumb),
            ('Top 100', "https://%s/cat_top/16/Movies/" % base_url, 'get_torrent', thumb),
            ('Top 100 Filme', "https://%s/top100" % base_url, 'get_torrent', thumb),
            ('Top 100 TV', "https://%s/cat_top/20/TV-shows/" % base_url, 'get_torrent', thumb),
            ('Top 100 Anime', "https://%s/cat_top/1/Anime/" % base_url, 'get_torrent', thumb),
            ('Top 100 Altele', "https://%s/cat_top/27/Other-Other/" % base_url, 'get_torrent', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]

    def cauta(self, keyword):
        url = "https://%s/search/all/%s/seeds/1/" % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')
    
    def get_sort(self):
        score = [('Fara sortare', ''),
                 ('Dupa data adaugarii', 'date/1/'),
                 ('Dupa seeders', 'seeds/1/'),
                 ('Dupa leechers', 'leechs/1/'),
                 ('Dupa marime', 'size/1/')]
        return score

    def parse_menu(self, url, meniu, info={}, torraction=None):
        #log(self.get_cat())
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                if link:
                    infos = {}
                    regex = '''<tr(.+?)</tr'''
                    regex_tr = '''(?:href="(.+?)".+?)?href="(.+?)">(.+?)<.+?normal">(.+?)<.+?(?:normal">(.+?)<.+?.+?)?tdseed">(.+?)<.+?tdleech">(.+?)<'''
                    tables = re.findall(regex, link)
                    if tables:
                        for table in tables:
                            match = re.findall(regex_tr, table)
                            if match:
                                for legatura, legaturadetalii, nume, time, size, seeds, leechers in match:
                                    seeds = ''.join(str(seeds).split()) if seeds else '-1'
                                    size = size.replace('&nbsp;', ' ').strip()
                                    time = time.replace('&nbsp;', ' ').strip()
                                    legaturadetalii = 'https://%s%s' % (self.base_url, legaturadetalii)
                                    legatura  = legaturadetalii # if not legatura else legatura
                                    nume = '%s [COLOR green]%s[/COLOR] (%s) [S/L: %s/%s] ' % (striphtml(nume), time, size, seeds, leechers)
                                    size = formatsize(size)
                                    if not info:
                                        infos = {'Title': nume,
                                                'Plot': nume,
                                                'Size': size,
                                                'Poster': self.thumb}
                                    else:
                                        infos = info
                                        try:
                                            infos = eval(str(infos))
                                            infos['Size'] = size
                                            infos['Plot'] = '%s - %s' % (nume, infos['Plot'])
                                        except: pass
                                        #infos.update({'Plot': '%s - %s' % (nume, infos['Plot'])})
                                    if not (seeds == '0' and not zeroseed):
                                        lists.append((nume,legatura,self.thumb,'torrent_links', infos))
                    match = re.compile('next page', re.IGNORECASE).findall(link)
                    if len(match) > 0:
                        if re.search("/(\d+)/", url):
                            new = re.compile('/(\d+)/').findall(url)
                            nexturl = re.sub('/(\d+)/', '/' + str(int(new[0]) + 1) + '/', url)
                        else:
                            nexturl = '%s%s2/' % (url, '/' if url.endswith('/') else '//')
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'sortare':
            sort = self.get_sort()
            if sort:
                for nume, legatura in sort:
                    legatura = '%s%s' % (url, legatura)
                    lists.append((nume,legatura,imagine,'get_torrent', info))
        elif meniu == 'torrent_links':
            if url.endswith('.html'):
                link = fetchData(url)
                try: surl = re.search('href="(magnet:.+?)"', link).group(1)
                except: surl = None
            else:
                surl = url
            action = torraction if torraction else ''
            if surl: openTorrent({'Tmode':torraction, 'Turl': surl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists

class piratebay:
    
    base_url = 'openpirate.org'
    thumb = os.path.join(media, 'piratebay.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'ThePirateBay'
    build_url = 'https://%s/api?url=/q.php?q=' % base_url
    tracker_list = 'https://%s/static/main.js' % base_url
    menu = [('Recente', "%s%s" % (build_url, quote('category:200')), 'recente', thumb),
            ('Populare', "https://%s/api?url=/precompiled/data_top100_200.json" % (base_url), 'get_torrent', thumb),
            ('Filme', "%s%s" % (build_url, quote('category:201')), 'recente', thumb),
            ('Filme DVDR', "%s%s" % (build_url, quote('category:202')), 'recente', thumb),
            ('Filme HD', "%s%s" % (build_url, quote('category:207')), 'recente', thumb),
            ('Filme 3D', "%s%s" % (build_url, quote('category:209')), 'recente', thumb),
            ('Filme altele', "%s%s" % (build_url, quote('category:299')), 'recente', thumb),
            ('Seriale', "%s%s" % (build_url, quote('category:205')), 'recente', thumb),
            ('Seriale HD', "%s%s" % (build_url, quote('category:208')), 'recente', thumb),
            ('Videoclipuri', "%s%s" % (build_url, quote('category:203')), 'recente', thumb),
            ('Clipuri', "%s%s" % (build_url, quote('category:204')), 'recente', thumb),
            ('Handheld', "%s%s" % (build_url, quote('category:206')), 'recente', thumb),
            ('Porn', "%s%s" % (build_url, quote('category:500')), 'recente', thumb),
            ('Porn Movies', "%s%s" % (build_url, quote('category:501')), 'recente', thumb),
            ('Porn Movies DVDR', "%s%s" % (build_url, quote('category:502')), 'recente', thumb),
            ('Porn HD Movies', "%s%s" % (build_url, quote('category:505')), 'recente', thumb),
            ('Porn Clipuri', "%s%s" % (build_url, quote('category:506')), 'recente', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]

    categories = [('Filme', '201'),
               ('Filme DVDR', '202'),
               ('Filme HD', '207'),
               ('Filme 3D', '209'),
               ('Filme Others', '299'),
               ('Seriale', '205'),
               ('Seriale HD', '208'),
               ('Videoclipuri', '203'),
               ('Clipuri', '204'),
               ('Handheld', '206'),
               ('Porn', '500'),
               ('Porn Movies', '501'),
               ('Porn Movies DVDR', '502'),
               ('Porn HD Movies', '505'),
               ('Porn Clipuri', '506')]
    
    headers = {'Host': base_url,
               'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
               'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}

    def cauta(self, keyword):
        url = "%s%s" % (self.build_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')
    
    def format_bytes(self, size):
        B = float(size)
        KB = float(1024)
        MB = float(KB ** 2) # 1,048,576
        GB = float(KB ** 3) # 1,073,741,824
        TB = float(KB ** 4) # 1,099,511,627,776

        if B < KB:
            return '{0} {1}'.format(B,'Bytes' if 0 == B > 1 else 'Byte')
        elif KB <= B < MB:
            return '{0:.2f} KB'.format(B/KB)
        elif MB <= B < GB:
            return '{0:.2f} MB'.format(B/MB)
        elif GB <= B < TB:
            return '{0:.2f} GB'.format(B/GB)
        elif TB <= B:
            return '{0:.2f} TB'.format(B/TB)

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                null = ''
                link = fetchData(url, headers=self.headers, rtype='json')
                if link:
                    try:
                        trackers = fetchData(self.tracker_list, headers=self.headers)
                        trackers = re.findall('encodeURIComponent\(\'(.+?)\'', trackers)
                        trackers = ''.join([('&tr=%s' % quote(track)) for track in trackers])
                    except: trackers = ''
                    for torrent in link:
                        proceed = False
                        numecategorie = ''
                        category = torrent.get('category')
                        for catname, catnumber in self.categories:
                            if str(catnumber) == str(torrent.get('category')):
                                proceed = True
                                numecategorie = catname
                                break
                        if proceed:
                            name = torrent.get('name')
                            seeds = torrent.get('seeders')
                            seeds = ''.join(str(seeds).split()) if seeds else '-1'
                            leechs = torrent.get('leechers')
                            size = torrent.get('size')
                            status = torrent.get('status')
                            nume = '%s [COLOR lime]%s[/COLOR]%s (%s) [S/L: %s/%s] ' % (name, status, ((' [COLOR green]%s[/COLOR]' % numecategorie) if numecategorie else ''), self.format_bytes(size), seeds, leechs)
                            info = {'Title': nume,
                                    'Plot': nume,
                                    'Size': size,
                                    'Poster': self.thumb}
                            legatura = 'magnet:?xt=urn:btih:'
                            legatura += torrent.get('info_hash')
                            legatura += '&dn=%s' % (quote(name))
                            if trackers: legatura += trackers
                            else:
                                legatura += '&tr=udp%3A%2F%2Ftracker.coppersurfer.tk%3A6969%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2F9.rarbg.to%3A2920%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337'
                                legatura += '&tr=udp%3A%2F%2Ftracker.internetwarriors.net%3A1337%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2Ftracker.coppersurfer.tk%3A6969%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2Ftracker.pirateparty.gr%3A6969%2Fannounce'
                                legatura += '&tr=udp%3A%2F%2Ftracker.cyberia.is%3A6969%2Fannounce'
                            if not (seeds == '0' and not zeroseed):
                                lists.append((nume,legatura,self.thumb,'torrent_links', info))
                    new = re.findall('\d+\:(\d+)', unquote(url))
                    try: new = new[0]
                    except: new = ''
                    if new:
                        nexturl = re.sub('(\d+)\:(\d+)', r"\1:%s" % (int(new) + 1), unquote(url))
                    else:
                        nexturl = '%s:1' % unquote(url)
                    lists.append(('Next', nexturl, self.nextimage, 'recente', {}))
        
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
    
class rarbg:
    
    base_url = 'http://torrentapi.org/pubapi_v2.php'
    appid = 'plugin.video.romanianpack'
    thumb = os.path.join(media, 'rarbg.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'Rarbg'
    catfilme = [('Recente', '%s%s14;48;17;44;45;47;50;51;52;42;46%s%s%s'),
                ('Toate', '%s%s14;48;17;44;45;47;50;51;52;42;46%s%s%s'),
                ('4k/x265/HDR', '%s%s52%s%s%s'),
                ('4k/x265', '%s%s51%s%s%s'),
                ('1080p/x264', '%s%s44%s%s%s'),
                ('720p/x264', '%s%s45%s%s%s'),
                ('x264', '%s%s17%s%s%s'),
                ('720p/xvid', '%s%s48%s%s%s'),
                ('xvid', '%s%s14%s%s%s'),
                ('BD Remux', '%s%s46%s%s%s')]
    catseriale = [('Recente', '%s%s2;18;41;49%s%s%s'),
                  ('Toate', '%s%s2;18;41;49%s%s%s'),
                  ('Episoade', '%s%s18%s%s%s'),
                  ('Episoade HD', '%s%s41%s%s%s'),
                  ('Episoade UHD', '%s%s49%s%s%s')]
    sortare = [('Recent adăugate', 'last'),
               ('După seederi', 'seeders'),
               ('După leecheri', 'leechers')]
    menu = [('Recente', 
             "%s?mode=list&category=2;14;15;16;17;21;22;42;18;19;41;29;30;31;24;26;34;43;44;45;46;47;48;49;50;51;52&app_id=%s&format=json_extended&ranked=0&sort=last&limit=100" % 
             (base_url, appid), 'recente', thumb),
            ('Filme', "", 'filme', thumb),
            ('Seriale ', "", 'seriale', thumb),
            ('Adulti', "%s?mode=list&category=4&app_id=%s&ranked=0&format=json_extended&limit=100" % (base_url, appid), 'sortare', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]

    def get_token(self):
        try: 
            token = fetchData('%s?get_token=get_token&app_id=plugin.video.romanianpack' % self.base_url, rtype='json')["token"]
            return token
        except: pass

    def cauta(self, keyword):
        url = '%s?mode=search&search_string=%s&app_id=plugin.video.romanianpack&format=json_extended&ranked=0%s&limit=50' % (self.base_url, quote(keyword), '&sort=seeders')
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def get_size(self, bytess):
        alternative = [
            (1024 ** 5, ' PB'),
            (1024 ** 4, ' TB'), 
            (1024 ** 3, ' GB'), 
            (1024 ** 2, ' MB'), 
            (1024 ** 1, ' KB'),
            (1024 ** 0, (' byte', ' bytes')),
            ]
        for factor, suffix in alternative:
            if bytess >= factor:
                break
        amount = int(bytess / factor)
        if isinstance(suffix, tuple):
            singular, multiple = suffix
            if amount == 1:
                suffix = singular
            else:
                suffix = multiple
        return str(amount) + suffix
    
    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                token = self.get_token()
                time.sleep(2)
                try: url = '%s&token=%s' % (url, token)# url % (self.base_url, appid, 'format=json_extended', '&limit=100', token)
                except: pass
                link = fetchData(url, rtype='json')
                if link:
                    if not "error" in link:
                        for detail in link["torrent_results"]:
                            magnet = detail["download"]
                            title = detail["title"]
                            seeds = detail["seeders"]
                            leechers = detail["leechers"]
                            size = self.get_size(detail["size"])
                            category = detail["category"]
                            if detail["episode_info"]: imdb = detail["episode_info"]["imdb"]
                            else: imdb = ''
                            seeds = ''.join(str(seeds).split()) if seeds else '-1'
                            nume = '%s (%s) [S/L: %s/%s]' % (title, size, seeds, leechers)
                            #nume = htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8').strip()
                            #re.compile('pager".+?page=', re.IGNORECASE | re.DOTALL).findall(response)
                            size = formatsize(size)
                            info = {'Title': nume,
                                'Plot': nume,
                                'Poster': self.thumb,
                                'Size': size,
                                'Genre': category}
                            if imdb:
                                trailerlink = 'https://www.imdb.com/title/%s/' % imdb
                                info['Trailer'] = '%s?action=GetTrailerimdb&link=%s&nume=%s&poster=%s&plot=%s' % (sys.argv[0], quote(trailerlink), quote(nume), quote(self.thumb), quote(nume))
                                info['imdb'] = imdb
                            if not (seeds == '0' and not zeroseed):
                                lists.append((nume,magnet,self.thumb,'torrent_links', info))
                    else: log(link)
        elif meniu == "filme" or meniu == 'seriale':
            if meniu == 'filme': itter = self.catfilme
            else: itter = self.catseriale
            for name, cat in itter:
                nume = '%s %s' % ('Filme ', name) if meniu == 'filme' else name
                legatura = cat % (self.base_url, '?mode=list&category=', '&app_id=', self.appid, '&ranked=0&format=json_extended&limit=100')
                if name == 'Recente':
                    legatura = '%s%s' % (legatura, '&sort=last')
                    next_menu = 'get_torrent'
                else: next_menu = 'sortare'
                lists.append((nume,legatura,self.thumb,next_menu, info))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s&sort=%s' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
        
        return lists
    
class speedapp:
    
    base_url = 'speedapp.io'
    thumb = os.path.join(media, 'speedapp.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'SpeedApp'
    username = __settings__.getSetting("SPAusername")
    if not username:
        username = __settings__.getSetting("SFZusername")
    if not username:
        username = __settings__.getSetting("XZusername")
    password = __settings__.getSetting("SPApassword")
    if not password:
        password = __settings__.getSetting("SFZpassword")
    if not password:
        password = __settings__.getSetting("XZpassword")
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
               'Referer': 'https://' + base_url + '/',
               'Host': '%s' % base_url}

    sortare = [('După dată', ''),
               ('După mărime', 'sort=torrent.size&direction=desc'),
               ('După downloads', 'sort=torrent.timesCompleted&direction=desc'),
               ('După seederi', 'sort=torrent.seeders&direction=desc'),
               ('După leecheri', 'sort=torrent.leechers&direction=desc')]
    
    categorii = [('Anime/Hentai', '3'),
             ('Seriale HDTV', '43'),
             ('Seriale HDTV-Ro', '44'),
             ('Filme 3D', '61'),
             ('Filme 3d Ro', '62'),
             ('Filme BluRay', '17'),
             ('Filme BluRay-Ro', '24'),
             ('Filme DVD', '7'),
             ('Filme DVD-Ro', '2'),
             ('Filme HD', '8'),
             ('Filme HD-Ro', '29'),
             ('Filme Românești', '59'),
             ('Filme 4K(2160p)', '61'),
             ('Filme 4K-RO(2160p)', '57'),
             ('Movies Packs', '38'),
             ('Videoclipuri', '64'),
             ('Filme SD', '10'),
             ('Filme SD-Ro', '35'),
             ('Sport', '22'),
             ('Sport-Ro', '58'),
             ('Seriale TV', '45'),
             ('Seriale TV-Ro', '46'),
             ('TV Packs', '41'),
             ('TV Packs-Ro', '66'),
             ('Seriale Românești', '60'),
             ('Desene Animate', '62'),
             ('Documentare', '9'),
             ('Documentare-Ro', '63')]
    adult = [('XXX-Packs', '50'),
             ('XXX', '15'),
             ('XXX DVD', '47'),
             ('XXX HD', '48'),
             ('XXX-SD', '51')]
    menu = [('Recente', "https://%s/browse?page=1" % base_url, 'recente', thumb)]
    l = []
    for x in categorii:
        l.append((x[0], 'https://%s/browse?categories[0]=%s' % (base_url, x[1]), 'sortare', thumb))
    menu.extend(l)
    m = []
    for x in adult:
        m.append((x[0], 'https://%s/adult?categories[0]=%s' % (base_url, x[1]), 'sortare', thumb))
    menu.extend(m)
    menu.extend([('Toate(fără XXX)', 'https://%s/browse?categories[0]=38&categories[1]=10&categories[2]=35&categories[3]=8&categories[4]=29&categories[5]=7&categories[6]=2&categories[7]=17&categories[8]=24&categories[9]=59&categories[10]=57&categories[11]=61&categories[12]=41&categories[13]=66&categories[14]=45&categories[15]=46&categories[16]=43&categories[17]=44&categories[18]=60&categories[19]=62&categories[20]=3&categories[21]=64&categories[22]=22&categories[23]=58&categories[24]=9&categories[25]=63' % base_url, 'sortare', thumb)])
    menu.extend([('Căutare', base_url, 'cauta', searchimage)])
    base_url = base_url

    def cauta(self, keyword):
        url = 'https://%s/browse?search=%s&submit=&sort=torrent.seeders&direction=desc&page=1' % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def login(self):
        headers = {'Host': self.base_url,
                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3'}
        y, session = makeRequest('https://%s/login' % (self.base_url), name=self.__class__.__name__, headers=headers, savecookie=True)
        save_cookie(self.__class__.__name__, session)
        token = re.search('_csrf_token.+?value="(.+?)"', y).group(1)
        data = {
            'password': self.password,
            'username': self.username,
            '_remember_me': 'on',
            '_csrf_token': token
        }
        log('Log-in  attempt')
        e = []
        try: cookiesitems = session.cookies.iteritems()
        except: cookiesitems = session.cookies.items()
        for i, j in cookiesitems:
            e.append('%s=%s' % (i, j))
        headers['Cookie'] = "; ".join(e)
        headers['Origin'] = 'https://' + self.base_url
        headers['Referer'] = 'https://' + self.base_url + '/login'
        xbmc.sleep(1000)
        x, session1 = makeRequest('https://%s/login' % (self.base_url), name=self.__class__.__name__, data=data, headers=headers, savecookie=True)
        if re.search('logout', x):
            log('LOGGED SpeedApp')
        if re.search('Invalid credentials', x):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('SpeedApp Login Error', 'Parola/Username incorecte')))
            clear_cookie(self.__class__.__name__)
        save_cookie(self.__class__.__name__, session1)
        try: cookiesitems = session1.cookies.iteritems()
        except: cookiesitems = session1.cookies.items()
        for cookie, value in cookiesitems:
            return cookie + '=' + value
        return False

    def check_login(self, response=None):
        if None != response and 0 < len(response):
            if re.compile('<input type="password"').search(response) or \
                re.compile('Not logged in').search(response):
                log('SpeedApp Not logged!')
                self.login()
                return False
            if re.search('Date de autentificare invalide', response):
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('SpeedApp Login Error', 'Parola/Username incorecte')))
                clear_cookie(self.__class__.__name__)
            if re.search('Numele de utilizator nu a fost', response):
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('SpeedApp Wrong User', 'Nume utilizator nu a fost gasit')))
                clear_cookie(self.__class__.__name__)
        return True

    def getTorrentFile(self, url):
        content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        if not self.check_login(content):
            content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        if re.search("<html", content):
            msg = re.search('Username or password incorrect', content)
            if msg:
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('SpeedApp Login Error', 'Parola/Username incorecte')))
            xbmc.sleep(4000)
            sys.exit(1)
        return saveTorrentFile(url, content)

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        yescat = ['38', '10', '35', '8', '29', '7', '2', '17', '24', '59', '57', '61', '41', '66', '45', '46', '43', '44', '60', '62', '3', '64', '22', '58', '9', '63', '50', '51', '15', '47', '48']
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                if not self.check_login(response):
                    response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                regex = '''<div\s+class="float-lef.+?(href=.+?href="/bookm.+?)</div>\s+</div>\s+</div>'''
                if None != response and 0 < len(response):
                    if re.compile('Not logged in').search(response):
                        xbmc.executebuiltin((u'Notification(%s,%s)' % ('SpeedApp', 'lipsa username si parola din setari')))
                    blocks = re.findall(regex, response, re.DOTALL)
                    if blocks:
                        for block in blocks:
                            try: cat = str(re.findall('categories.+?=(\d+)"', block)[0])
                            except: cat = ''
                            promovat = True if re.search('Acest torrent este promovat', block) else False
                            imagine = self.thumb
                            try: 
                                nume = re.findall(':?left.+?href=.+?"(?:\s+)?>(.+?)<', block, re.DOTALL)[0]
                                nume = ensure_str(nume)
                            except: nume = ''
                            try: added = re.findall('\d+:\d+:\d+">(.+?)<', block)[0]
                            except: added = ''
                            try: free = re.findall('>\s+(free)\s+<', block)[0]
                            except: free = ''
                            try: downloaded = re.findall('>(\d+\s+ori)<', block)[0]
                            except: downloaded = ''
                            try: size = re.findall('>(\s+[\d\.,]+\s+[a-zA-Z]+\s+)<', block)[0].strip()
                            except: size = ''
                            try: seeds = str(re.findall('text-success">\s+(\d+)\s+<.+?seed', block)[0])
                            except: seeds = '0'
                            try: leechers = str(re.findall('text-danger">\s+(\d+)\s+<.+?leec', block)[0])
                            except: leechers = '0'
                            try: half = 'Half' if re.findall('(Doar jumatate din dimensiunea acestui torrent)', block) else ''
                            except: half = ''
                            try: double = 'Double' if re.findall('(se va contoriza dublu)', block) else ''
                            except: double = ''
                            genre = re.findall('genre=2">(.+?)<', block)
                            try: legatura = re.findall('href="(/torrent.+?)"', block)[0]
                            except: legatura = ''
                            if re.findall('\s+new\s+', block): new = '1'
                            else: new = ''
                            seeds = ''.join(str(seeds).split()) if seeds else '-1'
                            if not (seeds == '0' and not zeroseed):
                                if str(cat) in yescat:
                                    plot = ''
                                    size = striphtml(size)
                                    nume = ('[COLOR lime]FREE[/COLOR] ' if free else '') + nume
                                    nume = ('[COLOR lime]PROMOVAT[/COLOR] ' if promovat else '') + nume
                                    nume = '%s  [COLOR green]%s%s%s[/COLOR] (%s) [S/L: %s/%s] ' % (nume, half, double, ' New' if new else '', size, seeds, leechers)
                                    legatura = 'https://%s%s' % (self.base_url, legatura)
                                    tip = ', '.join(genre)
                                    tip = ', '.join(tip.split('|'))
                                    tip = ensure_str(tip)
                                    size = formatsize(size)
                                    plot += '%s %s' % (tip, nume)
                                    plot += (' Adăugat %s' % added) if added else ''
                                    plot += (' Descărcat de: %s' % downloaded) if downloaded else ''
                                    info = {'Title': nume,
                                            'Plot': plot,
                                            'Genre': tip,
                                            'Size': size,
                                            'Poster': imagine}
                                    lists.append((nume,legatura,imagine,'torrent_links', info))
                        if 'page=' in url:
                            new = re.compile('page=(\d+)').findall(url)
                            nexturl = re.sub('page=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=1')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s&page=1' % (url, (('&%s' % sortare) if sortare else ''))
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            turl = self.getTorrentFile(url)
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists

class seedfilero:
    
    base_url = 'seedfile.io'
    thumb = os.path.join(media, 'seedfilero.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'SeedFile'
    username = __settings__.getSetting("seedfilerousername")
    password = __settings__.getSetting("seedfileropassword")
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
               'Referer': 'https://' + base_url + '/',
               'Host': base_url,
               'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
               'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3',
               'TE': 'Trailers'}
    
    categorii = [('Desene SD', 'cat=2'),
             ('Filme Blu-Ray', 'cat=5'),
             ('Filme DVD', 'cat=6'),
             ('Filme DVD-RO', 'cat=7'),
             ('Filme HD', 'cat=8'),
             ('Filme HD-RO', 'cat=9'),
             ('Filme SD', 'cat=10'),
             ('Filme SD-RO', 'cat=11'),
             ('Seriale HD', 'cat=18'),
             ('Seriale HD-RO', 'cat=19'),
             ('Seriale TV', 'cat=20'),
             ('Seriale TV-RO', 'cat=21'),
             ('Sport', 'cat=22'),
             ('Videoclip', 'cat=23'),
             ('XXX 18+', 'cat=24'),
             ('Video 3D', 'cat=36'),
             ('Desene HD-RO', 'cat=39'),
             ('Desene SD-RO', 'cat=40')]
    menu = [('Recente', "https://%s/download-torrents?page=0" % base_url, 'recente', thumb)]
    menu.extend([('Dublate în Română', "https://%s/rodubbeds.php?page=0" % base_url, 'get_torrent', searchimage)])
    l = []
    for x in categorii:
        l.append((x[0], 'https://%s/torrents.php?search=&%s&page=0' % (base_url, x[1]), 'get_torrent', thumb))
    menu.extend(l)
    menu.extend([('Căutare', base_url, 'cauta', searchimage)])
    base_url = base_url

    def cauta(self, keyword):
        url = 'https://%s/torrents.php?search=%s&page=0' % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def login(self):
        data = {
            'password': self.password,
            'username': self.username
        }
        log('Log-in  attempt')
        headers = {'Host': self.base_url,
                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Referer': 'http://' + self.base_url + '/',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Content-Type': 'application/x-www-form-urlencoded',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3'}
        x, session = makeRequest('http://%s/takelogin.php' % (self.base_url), name=self.__class__.__name__, data=data, headers=headers, savecookie=True)
        if re.search('Logout', x):
            log('LOGGED SeedFile')
        if re.search('Username or password are incorrect', x):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('SeedFile Login Error', 'Parola/Username incorecte')))
            clear_cookie(self.__class__.__name__)
        save_cookie(self.__class__.__name__, session)
        try: cookiesitems = session.cookies.iteritems()
        except: cookiesitems = session.cookies.items()
        for cookie, value in cookiesitems:
            if cookie == 'pass' or cookie == 'uid' or cookie == 'username':
                return cookie + '=' + value
        return False

    def check_login(self, response=None):
        if None != response and 0 < len(response):
            if re.compile('/register">Sign up now').search(response) or \
                re.compile('Not logged in').search(response):
                log('SeedFile Not logged!')
                self.login()
                return False
            if re.search('Username or password are incorrect', response):
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('SeedFile Login Error', 'Parola/Username incorecte')))
                clear_cookie(self.__class__.__name__)
        return True

    def getTorrentFile(self, url):
        content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        if not self.check_login(content):
            content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        if re.search("<html", content):
            msg = re.search('Username or password are incorrect', content)
            if msg:
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('SeedFile Login Error', 'Parola/Username incorecte')))
            xbmc.sleep(4000)
            sys.exit(1)
        return saveTorrentFile(url, content)

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                if not self.check_login(response):
                    response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                regex = '''<tr class="browse">(.+?)</tr>\s+(?:<tr>|</table)'''
                if None != response and 0 < len(response):
                    if re.compile('Not logged in').search(response):
                        xbmc.executebuiltin((u'Notification(%s,%s)' % ('SeedFile', 'lipsa username si parola din setari')))
                    for block in re.compile(regex, re.DOTALL | re.IGNORECASE).findall(response):
                        result = re.compile('(<td.+?</td>)', re.DOTALL).findall(block)
                        if result:
                            cat = re.findall('torrents.+?(cat=\d+)"', result[0])
                            try: cat = cat[0]
                            except: cat = ''
                            verificat = ' Verificat' if re.search('title="(verified)"', result[1], re.IGNORECASE) else ''
                            imagine = re.findall("src='(.+?)'", result[1])
                            try: imagine = imagine[0]
                            except: imagine = self.thumb
                            gold = ' Aur' if re.search('title="(torent de aur)"', result[1], re.IGNORECASE) else ''
                            free = '[COLOR lime]FreeLeech[/COLOR] ' if re.search('(freeleech\.png)', result[1]) else ''
                            sticky = ' Sticky' if re.search('(sticky\.png)', result[1]) else ''
                            rosubbed = ' ROSubbed' if re.search('(rosubbed\.png)', result[1]) else ''
                            rodubbed = ' Dublat' if re.search('(rodubbed\.png)', result[1]) else ''
                            
                            try: nume = re.findall(";'>(.+?)<", result[1])[0]
                            except: nume = ''
                            genre = re.findall("genre.+?\:.+?>(.+?)<", result[1], re.IGNORECASE)
                            try: genre = genre[0]
                            except: genre = ''
                            tip = '%s' % (' '.join(striphtml(genre).replace('&nbsp;', '').replace('|', '').split()) if genre else '')
                            legatura = re.findall('href="(.+?)"', result[1])[0]
                            legatura = 'https://%s/%s' % (self.base_url, replaceHTMLCodes(legatura))
                            recomandat = ' Recomandat' if re.search('(recomand.+?recomand)', result[1], re.IGNORECASE) else ''
                            size = striphtml(result[4])
                            seeds = striphtml(result[5])
                            seeds = ''.join(str(seeds).split()) if seeds else '-1'
                            leechers = striphtml(result[6])
                            added = ' %s' % striphtml(result[3])
                            nume = free + replaceHTMLCodes(nume).replace('|', '-')
                            nume = '%s  [COLOR green]%s%s%s%s%s%s%s[/COLOR] (%s) [S/L: %s/%s] ' % (ensure_str(nume), gold, recomandat, verificat, added, sticky, rosubbed, rodubbed ,size, seeds.strip(), leechers.strip())
                            size = formatsize(size)
                            info = {'Title': nume,
                                    'Plot': '%s %s' % (tip, nume),
                                    'Genre': tip,
                                    'Size': size,
                                    'Poster': imagine}
                            if not (seeds == '0' and not zeroseed):
                                for r,t in self.categorii:
                                    if cat == t or not cat:
                                        lists.append((nume,legatura,imagine,'torrent_links', info))
                                        break
                    match = re.compile('page=', re.IGNORECASE | re.DOTALL).findall(response)
                    if len(match) > 0:
                        if 'page=' in url:
                            new = re.compile('page=(\d+)').findall(url)
                            nexturl = re.sub('page=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=0')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'torrent_links':
            response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
            url = 'https://%s/%s' % (self.base_url, re.compile('href="(download\.php.+?\.torrent)"', re.DOTALL).findall(response)[0])
            turl = self.getTorrentFile(url)
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists

class skytorrents:
    
    base_url = 'www.skytorrents.lol'
    thumb = os.path.join(media, 'skytorrents.jpg')
    nextimage = next_icon
    searchimage = search_icon
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1', 'Referer':'https://%s/' % base_url, 'Host': base_url, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
    name = 'SkyTorrents'
    menu = [('Recente', "https://%s/top100?type=video&sort=created" % base_url, 'recente', thumb),
            ('Filme', "https://%s/top100?category=movie" % base_url, 'sortare', thumb),
            ('Seriale', "https://%s/top100?category=show" % base_url, 'sortare', thumb),
            ('Video', "https://%s/top100?type=video" % base_url, 'sortare', thumb),
            ('1080p', "https://%s/top100?tag=1080" % base_url, 'sortare', thumb),
            ('720p', "https://%s/top100?tag=720" % base_url, 'sortare', thumb),
            ('HD', "https://%s/top100?tag=hd" % base_url, 'sortare', thumb),
            ('SD', "https://%s/top100?tag=sd" % base_url, 'sortare', thumb),
            ('BDRip', "https://%s/top100?tag=bdrip" % base_url, 'sortare', thumb),
            ('DVDRip', "https://%s/top100?tag=dvdrip" % base_url, 'sortare', thumb),
            ('Yify', "https://%s/top100?tag=yify" % base_url, 'sortare', thumb),
            ('XXX', "https://%s/top100?tag=xxx" % base_url, 'get_torrent', thumb),
            ('Audio', "https://%s/top100?type=audio" % base_url, 'sortare', thumb),
            ('Audio Albums', "https://%s/top100?category=album" % base_url, 'sortare', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]

    sortare = [('Implicit', ''),
               ('După data adăugării', '&sort=created'),
               ('După seederi', '&sort=seeders'),
               ('După peers', '&sort=leechers')]

    def cauta(self, keyword):
        url = "https://%s/?query=%s&type=video" % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url, headers=self.headers)
                if link:
                    infos = {}
                    regex = '''<tbody.+?<div(.+?)</div'''
                    regex_piece = '''<tr(.+?)</tr'''
                    regex_tr = '''href.+?>(.+?)<.+?href="(magnet.+?)".+?type=(.+?)"(?:.+?category=(.+?)")?(?:.+?tag=(.+?)")?(?:.+?tag=(.+?)")?(?:.+?tag=(.+?)")?.+?a>.+?<.+?">(.+?)<.+?">(.+?)<.+?">(.+?)<.+?">(.+?)<.+?">(.+?)<'''
                    blocks = re.compile(regex_piece, re.DOTALL).findall(link)
                    if blocks:
                        for torrent in blocks:
                            match=re.compile(regex_tr, re.DOTALL).findall(torrent)
                            if match:
                                for nume,legatura,tip,categorie,tag,tagtwo,tagthree,size,files,up,seeds,leechers in match:
                                    tip = striphtml(tip).strip()
                                    if tip in ['audio', 'video']:
                                        thumbup = re.findall('\&nbsp;([\d\s]+)<img src="/files/thumb_upm', torrent)
                                        if thumbup: 
                                            thumbup = '%sUP' % thumbup[0].strip()
                                        else: thumbup = ''
                                        thumbdown = re.findall('\&nbsp;([\d\s-]+)<img src="/files/thumb_downm', torrent)
                                        if thumbdown: 
                                            thumbdown = '%sDown' % thumbdown[0].strip()
                                        else: thumbdown = ''
                                        ups = '%s&%s' % (thumbup,thumbdown) if thumbup and thumbdown else '%s' % thumbup or thumbdown
                                        if re.findall('img alt="Verified" title="Verified and marked"', torrent):
                                            verified = 'Verificat'
                                        else: verified = ''
                                        nume = unescape(striphtml(nume)).decode('utf-8').strip().replace('\n','')
                                        size = striphtml(size).strip()
                                        seeds = striphtml(seeds).strip()
                                        seeds = ''.join(str(seeds).split()) if seeds else '-1'
                                        leechers = striphtml(leechers).strip()
                                        up = striphtml(up).strip()
                                        tag = tag or ''
                                        nume = '%s  [COLOR green]%s%s%s[/COLOR] (%s) [S/L: %s/%s] ' % (nume, '%s ' % ups if ups else '' , up, ' - %s' % verified if verified else '', size, seeds, leechers)
                                        imagine = self.thumb
                                        size = formatsize(size)
                                        info = {'Title': nume,
                                                'Plot': '%s (%s, %s)' % (nume, categorie, tag),
                                                'Poster': imagine,
                                                'Size': size,
                                                'Genre': tag}
                                        if not (seeds == '0' and not zeroseed):
                                            lists.append((nume,legatura,imagine,'torrent_links', info))
                    match = re.findall('page=', link)
                    if len(match) > 0:
                        if 'page=' in url:
                            new = re.compile('page=(\d+)').findall(url)
                            nexturl = re.sub('page=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        else:
                            if '?' in url:
                                nexturl = '%s&page=2' % (url)
                            else: 
                                nexturl = '%s%s' % (url, '?page=2')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists

class xtremlymtorrents:
    
    base_url = 'extremlymtorrents.ws'
    thumb = os.path.join(media, 'extremlymtorrents.jpg')
    nextimage = next_icon
    searchimage = search_icon
    cookieJar = None
    name = 'ExtremlyMTorrents'
    username = __settings__.getSetting("ELTusername")
    password = __settings__.getSetting("ELTpassword")
    headers = {'Host': base_url,
               'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
               'Referer': 'https://%s/torrents.php' % base_url}
    
    categorii = [('1080p HD', '15'),
                 ('4K UHD', '40'),
                 ('720p HD', '22'),
                 ('Music Video 4k', '48'),
                 ('Anime-Japanese', '28'),
                 ('BluRay 3D', '16'),
                 ('Bluray HDR', '12'),
                 ('Bollywood', '44'),
                 ('BRRip', '35'),
                 ('CAMRip', '36'),
                 ('Documentaries', '31'),
                 ('DVD', '27'),
                 ('DVDRip', '5'),
                 ('HDTV', '13'),
                 ('Hentai-Manga', '43'),
                 ('Kids-Cartoons', '9'),
                 ('Pack', '21'),
                 ('PDTV-SDTV', '30'),
                 ('Porn-XXX', '11'),
                 ('Porn 4K-XXX', '47'),
                 ('Sport TV', '39'),
                 ('TS-Telesync-HDTS', '38'),
                 ('TV Episode-Season Complete', '10'),
                 ('TV 4K Episodes', '49'),
                 ('TVRip', '41'),
                 ('VideoClip', '24'),
                 ('WebRip-WebDL', '25'),
                 ('X Extern Only Magnet', '42')]
    menu = [('Recente', "https://%s/torrents.php?page=0" % base_url, 'recente', thumb)]
    l = []
    for x in categorii:
        l.append((x[0], 'https://%s/torrents.php?cat=%s&page=0' % (base_url, x[1]), 'get_torrent', thumb))
    menu.extend(l)
    menu.extend([('Căutare', base_url, 'cauta', searchimage)])
    base_url = base_url

    def cauta(self, keyword):
        url = 'https://%s/torrents-search.php?search=%s' % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def login(self):
        headers = {'Host': self.base_url,
                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Referer': 'https://' + self.base_url + '/account-login.php',
                   'X-Requested-With': 'XMLHttpRequest',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Content-Type': 'application/x-www-form-urlencoded',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3',
                   'Origin': 'https://%s' % self.base_url}
        content, session = makeRequest('https://%s/account-login.php' % self.base_url, name=self.__class__.__name__, headers=headers, savecookie=True)
        data = {
            'password': self.password,
            'username': self.username
        }
        log('Log-in  attempt')
        e = ''
        try: cookiesitems = session.cookies.iteritems()
        except: cookiesitems = session.cookies.items()
        for i, j in cookiesitems:
            e += '%s=%s; ' % (i, j)
        headers['Cookie'] = e
        x, session = makeRequest('https://%s/account-login.php' % (self.base_url), name=self.__class__.__name__, data=data, headers=headers, savecookie=True)
        if re.search('Access Denied', x):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('ExtremLymTorrents Login Error', 'Parola/Username incorecte')))
            clear_cookie(self.__class__.__name__)
        else:
            log('LOGGED ExtremLymTorrents')
        save_cookie(self.__class__.__name__, session)
        try: cookiesitems = session.cookies.iteritems()
        except: cookiesitems = session.cookies.items()
        for cookie, value in cookiesitems:
            if cookie == 'pass' or cookie == 'uid':
                return cookie + '=' + value
        return False

    def check_login(self, response=None):
        if None != response and 0 < len(response):
            if re.compile('account-login.php').search(response):
                log('ExtremLymTorrents Not logged!')
                xbmc.sleep(1000)
                self.login()
                return False
            if re.search('Access Denied', response):
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('ExtremLymTorrents Login Error', 'Parola/Username incorecte')))
                clear_cookie(self.__class__.__name__)
                return False
        return True

    def getTorrentFile(self, url):
        content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        if not self.check_login(content):
            content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        return saveTorrentFile(url, content)

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        yescat = ['15', '40', '22', '48', '28', '16', '12', '44', '35', '36', '31', '27', '5', '13', '43', '9', '21', '30', '11', '47', '39', '38', '10', '49', '41', '24', '25', '42']
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                if not self.check_login(response):
                    response = makeRequest(url, name=self.__class__.__name__, headers=self.headers)
                regex = '''<tr\s+class(.+?)</tr>'''
                if None != response and 0 < len(response):
                    #if re.compile('Not logged in').search(response):
                        #xbmc.executebuiltin((u'Notification(%s,%s)' % ('Extremlym', 'lipsa username si parola din setari')))
                    for block in re.findall(regex, response, re.DOTALL):
                        catname = ''
                        tables = re.findall('(?:<td.+?>(.+?)</td>)', block)
                        if tables and len(tables) == 8:
                            cat = re.findall('/?cat=(.+?)"', tables[0])[0].strip()
                            for n, c in self.categorii:
                                if c == cat:
                                    catname = n
                                    break
                            imagine, nume = re.findall('img\s+src=/(.+?)\s+.+?b>(.+?)</b', tables[1])[0]
                            genre =  re.findall('<br />(.+?)??<', tables[1])[0]
                            tip = ", ".join(re.split(',|\|', genre))
                            legatura = re.findall('href=(download.+?)\s+.+?\((.+?)\)', block)[0]
                            adaugat = striphtml(tables[7])
                            size = striphtml(tables[4]).strip()
                            seeds = striphtml(tables[5]).strip()
                            seeds = (''.join(str(seeds).split())).replace(',', '') if seeds else '-1'
                            leechers = striphtml(tables[6]).strip()
                            nume = replaceHTMLCodes(nume)
                            if str(cat) in yescat:
                                #log(r[1] if str(cat)==r[1] else t[1])
                                if re.findall('vip-icon.png', tables[1]):
                                    nume = '[COLOR yellow]VIP[/COLOR] ' + nume
                                if re.findall('3d.png', tables[1]):
                                    nume += ' [COLOR green]3D[/COLOR]'
                                if re.findall('engsub.png', tables[1]):
                                    nume += ' [COLOR green]ENGSub[/COLOR]'
                                if re.findall('rosubbed.png', tables[1]):
                                    nume += ' [COLOR green]ROSub[/COLOR]'
                                if re.findall('sticky.png', tables[1]):
                                    nume += ' [COLOR green]Sticky[/COLOR]'
                                if re.findall('4you.png', tables[1]):
                                    nume += ' [COLOR green]Recommended[/COLOR]'
                                nume += ' [COLOR green]%s[/COLOR]' % catname
                                nume += ' [COLOR green]%s[/COLOR] ' % adaugat
                                nume = '%s (%s) [S/L: %s/%s] ' % (nume, size, seeds, leechers)
                                legatura = 'https://%s/%s' % (self.base_url, legatura[0])
                                imagine = 'https://%s/%s' % (self.base_url, imagine)
                                #tip = genre or ''
                                #tip = ''
                                size = formatsize(size)
                                info = {'Title': nume,
                                        'Plot': '%s \n%s \n%s' % (tip, catname, nume),
                                        'Genre': tip,
                                        'Size': size,
                                        'Poster': imagine}
                                if not (seeds == '0' and not zeroseed):
                                    lists.append((nume,legatura,imagine,'torrent_links', info))
                    match = re.compile('/?page=\d+', re.DOTALL).findall(response)
                    if len(match) > 0:
                        if 'page=' in url:
                            new = re.compile('page=(\d+)').findall(url)
                            nexturl = re.sub('page=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=1')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'torrent_links':
            turl = self.getTorrentFile(url)
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists

class yify:
    
    base_url = 'yts.am'
    thumb = os.path.join(media, 'yify.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'Yify'
    menu = [('Recente', "https://%s/browse-movies" % base_url, 'recente', thumb),
            ('Filme', "https://%s/browse-movies/0/all/all/0/" % base_url, 'sortare', thumb),
            ('Genuri', "https://%s/browse-movies/0/all/%s/0/", 'genre', thumb),
            ('Calitate', "https://%s/browse-movies/0/%s/all/0/", 'calitate', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]

    sortare = [('Ultimele', 'latest'),
               ('Cele mai vechi', 'oldest'),
               ('Populare', 'featured'),
               ('După seederi', 'seeds'),
               ('După peers', 'peers'),
               ('După ani', 'year'),
               ('După aprecieri', 'likes'),
               ('După rating', 'rating'),
               ('Alfabetic', 'alphabetical'),
               ('După descărcări', 'downloads')]
    
    calitate = [('Toate', 'all'),
               ('720p', '720p'),
               ('1080p', '1080p'),
               ('4K', '2160p'),
               ('3D', '3D')]
    
    genre = ['Action',
             'Adventure',
             'Animation',
             'Biography',
             'Comedy',
             'Crime',
             'Documentary',
             'Drama',
             'Family',
             'Fantasy',
             'Film-Noir',
             'Game-Show',
             'History',
             'Horror',
             'Music',
             'Musical',
             'Mystery',
             'News',
             'Reality-TV',
             'Romance',
             'Sci-Fi',
             'Sport',
             'Talk-Show',
             'Thriller',
             'War',
             'Western']

    def cauta(self, keyword):
        url = "https://%s/ajax/search?query=%s" % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'cautare')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente' or meniu == 'cautare':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            elif meniu == 'cautare':
                link = fetchData(url, rtype='json')
                if link:
                    data = link.get('data')
                    if data:
                        for movie in data:
                            nume = ensure_str(movie.get('title'))
                            an = movie.get('year') or ''
                            nume = '%s (%s)' % (nume, an)
                            imagine = movie.get('img') or self.thumb
                            legatura = movie.get('url')
                            info = {'Title': movie.get('title'),
                                    'Plot': '%s (%s)' % (nume, an),
                                    'Poster': imagine,
                                    'Year': an}
                            lists.append((nume,legatura,imagine,'get_torrent_links', info))
            else:
                link = fetchData(url)
                if link:
                    infos = {}
                    regex = '''class="browse-movie-wrap(.+?)</div'''
                    regex_tr = '''href="(.+?)".+?src="(.+?)".+?rating">(.+?)</.+?h4>(.+?)<.+?title">(.+?)</a.+?year">(.+?)$'''
                    blocks = re.compile(regex, re.DOTALL).findall(link)
                    if blocks:
                        for block in blocks:
                            match=re.compile(regex_tr, re.DOTALL).findall(block)
                            if match:
                                for legatura, imagine, rating, genre, nume, an in match:
                                    nume = unescape(striphtml(nume)).decode('utf-8').strip()
                                    nume = '%s (%s)' % (nume, an)
                                    info = {'Title': nume,
                                            'Plot': '%s (%s) - %s  Rating: %s' % (nume, an, genre, rating),
                                            'Poster': imagine,
                                            'Genre': genre,
                                            'Rating': rating,
                                            'Label2': genre,
                                            'Year': an}
                                    lists.append((nume,legatura,imagine,'get_torrent_links', info))
                    match = re.compile('"tsc_pagination.+?\?page=', re.IGNORECASE | re.DOTALL).findall(link)
                    if len(match) > 0:
                        if '?page=' in url:
                            new = re.compile('\?page\=(\d+)').findall(url)
                            nexturl = re.sub('\?page\=(\d+)', '?page=' + str(int(new[0]) + 1), url)
                        else:
                            if '/?s=' in url:
                                nextpage = re.compile('\?s=(.+?)$').findall(url)
                                nexturl = '%s/page/2/?s=%s' % (self.base_url, nextpage[0])
                            else: 
                                nexturl = '%s%s' % (url, '?page=2')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'get_torrent_links':
            link = fetchData(url)
            regex = '''modal-torrent".+?quality.+?<span>(.+?)</span.+?-size">(.+?)<.+?-size">(.+?)<.+?"(magnet.+?)"'''
            try:
                info = eval(str(info))
                name = info.get('Title')
            except: 
                name = ''
            for calitate, calitate2, size, legatura in re.compile(regex, re.DOTALL).findall(link):
                nume = '%s %s (%s) %s' % (calitate, calitate2, size, name)
                lists.append((nume,legatura,'','torrent_links', info))
        elif meniu == 'calitate':
            for nume, calitate in self.calitate:
                legatura = url % (self.base_url, calitate)
                lists.append((nume,legatura,self.thumb,'sortare', info))
        elif meniu == 'genre':
            for gen in self.genre:
                legatura = url % (self.base_url, gen.lower())
                lists.append((gen,legatura,self.thumb,'sortare', info))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s/0/all' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists

class zooqle:
    
    base_url = 'zooqle.com'
    thumb = os.path.join(media, 'zooqle.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'Zooqle'
    menu = [('Recente', "https://%s/mov/?pg=1&v=t" % base_url, 'recente', thumb),
            ('Filme', "https://%s/mov/" % base_url, 'sort_film', thumb),
            ('Seriale', "https://%s/browse/tv/" % base_url, 'sort_tv', thumb),
            ('Anime', "https://%s/browse/" % base_url, 'sort_anime', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
    
    calitate = [('All', '&tg=0'),
                ('Med', '&tg=2'),
                ('Std', '&tg=3'),
                ('720p', '&tg=5'),
               ('1080p', '&tg=7'),
               ('4k', '&tg=9'),
               ('3D', '&tg=11')]
    
    sortare = [('Dupa data adaugarii', '&s=dt&sd=d'),
               ('Dupa numar torrenti', '&s=nt&sd=d'),
               ('Dupa nume', '&s=nm&sd=a'),
               ('Dupa rating - numai seriale', '&s=rt&sd=d')]
    
    sortarelinks = [('Dupa data adaugarii', 's=dt&sd=d'),
               ('Dupa seederi', 's=ns&sd=d'),
               ('Dupa nume', 's=nm&sd=a'),
               ('Dupa marime', 's=sz&sd=d')]
    
    filmgenre = ['All',
                 'Action',
                'Adventure',
                'Animation',
                'Comedy',
                'Crime',
                'Documentary',
                'Drama',
                'Family',
                'Fantasy',
                'Foreign',
                'History',
                'Horror',
                'Music',
                'Mystery',
                'Romance',
                'Science-Fiction',
                'Tv-Movie',
                'Thriller',
                'War',
                'Western']
    tvgenre = ['All',
               'Action',
               'Action-Adventure',
               'Adventure',
               'Animation',
               'Comedy',
               'Crime',
               'Documentary',
               'Drama',
               'Family',
               'Fantasy',
               'Horror',
               'Kids',
               'Mystery',
               'News',
               'Reality',
               'Sci-Fi-Fanatsy',
               'Science-Fiction',
               'Soap',
               'Talk',
               'War-Politics',
               'Western']
    
    animegenre = ['Anime',
                  'Anime-Raw',
                  'Anime-Music',
                  'Anime-3x']
    
    timeframe = [('Toate', '&age=any'),
                 ('In ultima saptamana', '&age=wk'),
                 ('In ultima luna', '&age=mon'),
                 ('In ultimele 3 luni', '&age=3m'),
                 ('In ultimul an', '&age=yr'),
                 ('In ultimii 3 ani', '&age=3yr')]

    def cauta(self, keyword):
        url = "https://%s/search?pg=1&q=%s+%s&v=t&s=ns&sd=d" % (self.base_url, quote(keyword), quote('category:Movies,TV,Anime,Other'))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrents_link')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                if link:
                    infos = {}
                    regex = '''<t(?:body|able)(\s+class.+?)</t(?:body|able)'''
                    regex_tr = '''src="(.+?)"(?:.+?tornum">(.+?)</div></div)?.+?href="(.+?)">(.+?)<(?:.+?">\((.+?)\)<)?.+?info">(.+?)(<a.+?</div>|</div>).+?descr">(.+?)<(?:.+?badge.+?">(.+?)<.+?">(.+?)<)?'''
                    blocks = re.compile(regex, re.DOTALL).findall(link)
                    if blocks:
                        for block in blocks:
                            info = {}
                            match=re.compile(regex_tr, re.DOTALL).findall(block)
                            if match:
                                for imagine, sezsitorr, legatura, nume, an, released, genre, descriere, calitate, torrente in match:
                                    legatura = 'https://%s%s?v=t' % (self.base_url, legatura)
                                    imagine = 'https://%s%s' % (self.base_url, imagine)
                                    nume = unescape(striphtml(nume)).decode('utf-8').strip().replace('&#039;', "'").replace('|', '-')
                                    try: genre = ', '. join(re.findall('>([a-zA-Z\s-]+)<', genre))
                                    except: genre = ''
                                    released = released.replace('&bull;', '')
                                    if calitate:
                                        nume = '%s [rezolutie: %s, %s torrents]' % (nume, calitate, torrente)
                                    else: 
                                        seztor = re.split('(season(?:s)?)', striphtml(sezsitorr))
                                        nume = '%s %s [%s %s %s]' % (nume, an.strip() if an else '', seztor[0], seztor[1], seztor[2])
                                    try: an = str(re.findall('\((\d+)\)', nume)[0])
                                    except: an = ''
                                    plot = '%s - %s' % (released, descriere)
                                    info = {'Title': nume,
                                            'Plot': plot,
                                            'Poster': imagine,
                                            'Genre': genre,
                                            'Year': an}
                                    if calitate:
                                        lists.append((nume,legatura,imagine,'get_torrents_link', info))
                                    else: 
                                        lists.append((nume,legatura,imagine,'get_show_links', info))
                    match = re.compile('"pagination.+?\?pg=', re.IGNORECASE | re.DOTALL).findall(link)
                    if len(match) > 0:
                        if '?pg=' in url:
                            new = re.compile('\?pg\=(\d+)').findall(url)
                            nexturl = re.sub('\?pg\=(\d+)', '?pg=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&pg=2')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'get_torrents_link':
            if not 'search?' in url:
                for nume, sortare in self.sortarelinks:
                    legatura = '%s%s%s' % (url, '?' if not '?' in url else '&', sortare)
                    lists.append((nume,legatura,self.thumb,'get_torrents_link', info))
            link = fetchData(url)
            if link:
                regex = '''<table(.+?)</table'''
                regex_tr = '''<td class.+?href="(.+?)">(.+?)</a.+?(<div.+?/div>).+?progress-bar.+?">(.+?)<.+?">(.+?)<.+?title="(.+?)"'''
                blocks = re.compile(regex, re.DOTALL).findall(link)
                if blocks:
                    for block in blocks:
                        infos = {}
                        match=re.compile(regex_tr, re.DOTALL).findall(block)
                        if match:
                            for legatura, nume, calitate, marime, vechime, peers in match:
                                peers = re.findall('(\d+).*\s+(\d+)', peers)
                                if not peers: peers = [('0', '0')]
                                legatura = 'https://%s%s' % (self.base_url, legatura)
                                nume = unescape(striphtml(nume)).decode('utf-8').strip().replace('|', '-')
                                calitate = striphtml(u'%s' % calitate.replace('&nbsp;' , '').replace('\t', ''))
                                nume = u'%s (%s) [S/L: %s/%s] [COLOR green]%s[/COLOR] [COLOR red]%s[/COLOR]' % (nume, marime, str(peers[0][0]), str(peers[0][1]), calitate, vechime)
                                marime = formatsize(marime)
                                if not info : 
                                    infos = {'Title': nume, 'Plot': nume, 'Poster': self.thumb, 'Size': marime}
                                else:
                                    infos = info
                                    try:
                                        infos = eval(str(infos))
                                        infos['Size'] = marime
                                    except: pass
                                lists.append((nume,legatura,self.thumb,'torrent_links', str(infos)))
                    regex_more = '''smaller">.+?muted.+?>(\+.+?)<.+?href="(.+?)"'''
                    more = re.findall(regex_more, link)
                    if len(more) > 0:
                        more_link = 'https://%s%s' % (self.base_url, more[0][1])
                        try: from urlparse import urlparse
                        except: from urllib.parse import urlparse
                        more_link = urlparse(more_link)
                        more_link = more_link.scheme + "://" + more_link.netloc + more_link.path + '?pg=1&v=t&tg=0'
                        lists.append(('Mai multe', more_link, self.nextimage, 'get_torrents_link', info))
                    match = re.compile('"pagination.+?\?pg=', re.IGNORECASE | re.DOTALL).findall(link)
                    if len(match) > 0:
                        if '?pg=' in url:
                            new = re.compile('\?pg\=(\d+)').findall(url)
                            nexturl = re.sub('\?pg\=(\d+)', '?pg=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&pg=2')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrents_link', {}))
        elif meniu == 'get_show_links':
            link = fetchData(url)
            regex = '''"panel panel-default eplist"(.+?)</div></div></div>'''
            regex_tr = '''class="".+?href="(.+?)".+?epnum">(.+?)<.+?href="#ep.+?">(.+?)</a.+?-href="(.+?)"'''
            regex_season = '''(season.+?<.+?">.+?)<'''
            blocks = re.compile(regex, re.DOTALL).findall(link)
            if blocks:
                tvname = re.sub('\[[^)]*\]', '', eval(str(info)).get('Title'))
                for block in blocks:
                    season = re.findall(regex_season, block, re.IGNORECASE | re.DOTALL)
                    if len(season) > 0:
                        lists.append(('[COLOR lime]%s[/COLOR]' % ' '.join(striphtml(season[0]).split()),'nolink','','nimic', {}))
                    match=re.compile(regex_tr, re.DOTALL).findall(block)
                    for legatura, epnumber, nume, legatura2 in match:
                        epnumber = striphtml(epnumber)
                        nume = striphtml(nume).replace('&amp;', 'and').replace('|', '-')
                        nume = '%s [COLOR silver]%s: %s[/COLOR]' % (tvname, 'Episod %s' % epnumber if not epnumber == '*' else epnumber, nume)
                        legatura = 'https://%s%s?pg=1&v=t&s=ns&sd=d' % (self.base_url, legatura)
                        if not legatura.startswith('/'): legatura = 'https://%s%s' % (self.base_url, legatura2)
                        lists.append((nume,legatura,self.thumb,'get_torrents_link', info))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'timeframe', info))
        elif meniu == 'timeframe':
            for nume, timeframe in self.timeframe:
                legatura = '%s%s' % (url, timeframe)
                lists.append((nume,legatura,self.thumb,'%s' % ('get_torrent' if not '/browse/anime' in url else 'get_torrents_link'), info))
        elif meniu == 'calitate':
            for nume, calitate in self.calitate:
                legatura = '%s%s' % (url, calitate)
                lists.append((nume,legatura,self.thumb,'sortare', info))
        elif meniu == 'sort_tv':
            for gen in self.tvgenre:
                legatura = '%s%s/?pg=1&v=t' % (url, gen.lower())
                lists.append((gen,legatura,self.thumb,'calitate', info))
        elif meniu == 'sort_film':
            for nume in self.filmgenre:
                legatura = '%s%s/?pg=1&v=t' % (url, nume.lower())
                lists.append((nume,legatura,self.thumb,'calitate', info))
        elif meniu == 'sort_anime':
            for nume in self.animegenre:
                legatura = '%s%s/?pg=1&v=t' % (url, nume.lower())
                lists.append((nume,legatura,self.thumb,'calitate', info))
        elif meniu == 'torrent_links':
            if not url.startswith('magnet'):
                link = fetchData(url)
                url = re.findall('href="(magnet.+?)"', link)[0]
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists

class ettv:
    
    base_url = 'ettvdl.com'
    thumb = os.path.join(media, 'ettv.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'ETTV'
    cats = {'81': 'Adult Movies',
            '82': 'Adult HD Movies',
            '83': 'Adult Hentai',
            '74': 'Anime Dubbed/Subbed',
            '73': 'Anime Movies',
            '49': 'Movies 3D',
            '66': 'Movies Bluray',
            '91': 'Movies Bollywood',
            '65': 'Movies CAM/TS',
            '80': 'Movies Documentary',
            '51': 'Movies Dubs/Dual Audio',
            '67': 'Movies DVDR',
            '1': 'Movies HD 1080p',
            '2': 'Movies HD 720p',
            '76': 'Movies HEVC/x265',
            '47': 'Movies SD X264/H264',
            '3': 'Movies UltraHD/4K',
            '42': 'Movies XviD',
            '61': 'Music Videos',
            '79': 'TV Documentary',
            '41': 'TV HD/X264/H264',
            '77': 'TV HEVC/x265',
            '5': 'TV SD/X264/H264',
            '50': 'TV SD/XVID',
            '72': 'TV Sport',
            '7': 'TV Packs',
            '89': 'TV UltraHD/4K'}
    menu = [('Recente', "https://www.%s/torrents.php?page=1" % base_url, 'recente', thumb),
            ('Filme', "https://www.%s/torrents.php?parent_cat=Movies" % base_url, 'sortare', thumb),
            ('Seriale', "https://www.%s/torrents.php?parent_cat=TV" % base_url, 'sortare', thumb),
            ('Anime', "https://www.%s/torrents.php?parent_cat=Anime" % base_url, 'sortare', thumb),
            ('Adult', "https://www.%s/torrents.php?parent_cat=Adult" % base_url, 'sortare', thumb)]
    l = []
    for x in cats:
        l.append((cats.get(x), 'https://www.%s/torrents.php?cat=%s&page=1' % (base_url, x), 'sortare', thumb))
    menu.extend(l)
    menu.extend([('Căutare', base_url, 'cauta', searchimage)])

    sortare = [('Ultimele', '&sort=id&order=desc'),
               ('După nume', '&sort=name&order=desc'),
               ('După comments', '&sort=comments&order=desc'),
               ('După mărime', '&sort=size&order=desc'),
               ('După descărcări', '&sort=times_completed&order=desc'),
               ('După seederi', '&sort=seeders&order=desc'),
               ('După leecheri', '&sort=leechers&order=desc')]
    

    def cauta(self, keyword):
        url = "https://www.%s/torrents-search.php?search=%s&page=1" % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = self.thumb
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                if link:
                    regex = '''(\<td\s+class\=.+?)\</tr'''
                    regex_tr = '''<td.+?['"]>(.+?)</td'''
                    regex_name = '''href="(.+?)">(.+?)</a'''
                    blocks = re.compile(regex, re.DOTALL).findall(link)
                    if blocks:
                        for block in blocks:
                            match=re.compile(regex_tr, re.DOTALL).findall(block)
                            if match:
                                uploader = striphtml(match[-1])
                                leeches = striphtml(match[-2])
                                seeds = striphtml(match[-3])
                                comments = striphtml(match[-4])
                                size = striphtml(match[-5])
                                added = striphtml(match[-6])
                                if not (seeds == '0' and not zeroseed):
                                    try:
                                        cat = re.findall('cat=(.+?)"', match[0])[0]
                                    except:
                                        cat = ''
                                    if self.cats.get(cat):
                                        legatura, nume = re.findall(regex_name, match[-7])[0]
                                        nume = htmlparser.HTMLParser().unescape(striphtml(nume)).strip()
                                        legatura = "https://www.%s%s" % (self.base_url, legatura)
                                        nume = '%s (%s) [S/L: %s/%s] ' % (nume, size, seeds, leeches)
                                        nume = '%s [COLOR green]%s %s %s[/COLOR]' % (nume, self.cats.get(cat), uploader, added)
                                        size = formatsize(size)
                                        info = {'Title': nume,
                                                'Plot': '%s (%s comments)' % (nume, comments),
                                                'Size': size,
                                                'Poster': imagine}
                                        lists.append((nume,legatura,imagine,'torrent_links', info))
                    match = re.compile('page\=').findall(link)
                    if len(match) > 0:
                        if 'page=' in url:
                            new = re.compile('page\=(\d+)').findall(url)
                            nexturl = re.sub('page\=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=2')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s&page=1' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            if not url.startswith('magnet'):
                link = fetchData(url)
                url = re.findall('href="(magnet.+?)"', link)[0]
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
    
class magnetdl:
    
    base_url = 'magnetdl.com'
    thumb = os.path.join(media, 'magnetdl.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'MagnetDL'
    cats = ['Movie', 'Music', 'Other', 'TV']
    menu = [('Recente', "https://www.%s/download/others/1/" % base_url, 'recente', thumb),
            ('Filme', "https://www.%s/download/movies/" % base_url, 'sortare', thumb),
            ('Seriale', "https://www.%s/download/tv/" % base_url, 'sortare', thumb),
            ('Music', "https://www.%s/download/music/" % base_url, 'sortare', thumb),
            ('Altele', "https://www.%s/download/other/" % base_url, 'sortare', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]

    sortare = [('Implicit', '1/'),
               ('Ultimele', 'age/desc/1/'),
               ('După mărime', 'size/desc/1/'),
               ('După seederi', 'se/desc/1/'),
               ('După leecheri', 'le/desc/1/')]
    
    headers = {'Host': 'www.%s' % base_url,
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                'Referer': 'https://www.%s' % base_url,
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3'}

    def cauta(self, keyword):
        import random
        url = "https://www.%s/search/?q=%s&m=1&x=%s&y=%s" % (self.base_url, quote(keyword), str(random.randint(1, 79)), str(random.randint(1, 30)))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = self.thumb
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url, headers=self.headers)
                if link:
                    regex = '''<tr><td class="m">(.+?)</tr>'''
                    regex_tr = '''href="(magnet.+?)".+?title=".+?" rel="nofollow">.+?<a href=".+?" title="(.+?)">.+?</td><td>(.+?)</td><td class=".+?">(.+?)</td><td>.+?</td><td>(.+?)</td><td class="s">(\d+)</td><td class="l">(\d+)</td>'''
                    blocks = re.compile(regex).findall(link)
                    if blocks:
                        for block in blocks:
                            match=re.compile(regex_tr).findall(block)
                            if match:
                                for legatura, nume, added, tip, size, seeds, leeches in match:
                                    if not (seeds == '0' and not zeroseed) and tip in self.cats:
                                        nume = '%s (%s) [S/L: %s/%s] ' % (nume, size, seeds, leeches)
                                        nume = '%s [COLOR green]%s %s[/COLOR]' % (nume, tip, added)
                                        size = formatsize(size)
                                        info = {'Title': nume,
                                                'Plot': nume,
                                                'Size': size,
                                                'Poster': imagine}
                                        lists.append((nume,legatura,imagine,'torrent_links', info))
                    match = re.compile('Next Page &gt;').findall(link)
                    if len(match) > 0:
                        new = re.compile('/(\d+)/').findall(url)
                        if new:
                            nexturl = re.sub('/(\d+)/', '/%s/' % str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s/2/' % (url)
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists

class extratorrent:
    
    base_url = 'extratorrents.it'
    thumb = os.path.join(media, 'extratorrent.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'MagnetDL'
    cats = ['Lossless', 'MP3', 'Windows', 'Ebooks', 'Audio books', 'Mac', 'Software for Android', 'Tutorials']
    menu = [('Recente', "https://%s/home" % base_url, 'recente', thumb),
            ('Filme', "https://%s/category/4/Movies+Torrents.html?srt=added&order=desc&page=1" % base_url, 'recente', thumb),
            ('Seriale', "https://%s/category/8/TV+Torrents.html?srt=added&order=desc&page=1" % base_url, 'recente', thumb),
            ('Music', "https://%s/category/5/Music+Torrents.html?srt=added&order=desc&page=1" % base_url, 'recente', thumb),
            ('Anime', "https://%s/category/1/Anime+Torrents.html?srt=added&order=desc&page=1" % base_url, 'recente', thumb),
            ('Adult', "https://%s/category/533/Adult+/+Porn+Torrents.html?srt=added&order=desc&page=1" % base_url, 'recente', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
    
    headers = {'Host': '%s' % base_url,
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                'Referer': 'https://%s/' % base_url,
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3'}

    def cauta(self, keyword):
        import random
        url = "https://%s/search/?new=1&search=%s&x=0&y=0&page=1" % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = self.thumb
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url, headers=self.headers)
                if link:
                    regex = '''<tr\s+class="tl(?:r|z)"(.+?)</tr'''
                    regex_tr = '''href="(.+?)".+?(?:.+?</div)?.+?href=.+?/torrent/.+?title.+?>(.+?)</a.+?title.+?>(.+?)<.+?<td(?:\s+class.+?)?>(.+?)</td.+?<td(?:\s+class.+?)?>(.+?)</td.+?<td(?:\s+class.+?)?>(.+?)</td.+?<td(?:\s+class.+?)?>(.+?)</td'''
                    blocks = re.findall(regex, link, re.DOTALL)
                    if blocks:
                        for block in blocks:
                            match=re.findall(regex_tr, block, re.DOTALL)
                            if match:
                                for legatura, nume, tip, added, size, seeds, leeches in match:
                                    seeds = '0' if seeds == '---' else seeds
                                    leeches = '0' if leeches == '---' else leeches
                                    if not(seeds == '0' and not zeroseed) and (not tip in self.cats):
                                        nume = '%s (%s) [S/L: %s/%s] ' % (striphtml(nume), size, seeds, leeches)
                                        nume = '%s [COLOR green]%s added %s ago[/COLOR]' % (nume, tip, added)
                                        size = formatsize(size)
                                        info = {'Title': nume,
                                                'Plot': nume,
                                                'Size': size,
                                                'Poster': imagine}
                                        lists.append((nume,legatura,imagine,'torrent_links', info))
                    match = re.compile('pager_link"').findall(link)
                    if len(match) > 0:
                        if 'page=' in url:
                            new = re.compile('page=(\d+)').findall(url)
                            nexturl = re.sub('page=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=1')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
    
class torrentgalaxy:
    
    base_url = 'torrentgalaxy.to'
    thumb = os.path.join(media, 'torrentgalaxy.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'TorrentGalaxy'
    cats = {'28': 'Anime',
            '9': 'Documentaries',
            '3': 'Movies 4K UHD',
            '46': 'Movies Bollywood',
            '45': 'Movies CAM/TS',
            '42': 'Movies HD',
            '4': 'Movies Packs',
            '1': 'Movies SD',
            '25': 'Music Video',
            '41': 'TV HD',
            '5': 'TV SD',
            '6': 'TV Packs',
            '7': 'TV Sports',
            '35': 'XXX HD',
            '34': 'XXX SD'}
    
    sortare = [('Ultimele', '&sort=id&order=desc'),
               ('După seederi', '&sort=seeders&order=desc'),
               ('După nume', '&sort=name&order=desc'),
               ('După mărime', '&sort=size&order=desc')]
    
    menu = [('Recente', "https://%s/torrents.php?parent_cat=&nox=1&sort=id&order=desc&page=0" % base_url, 'recente', thumb),
            ('Movies', "https://%s/torrents.php?parent_cat=Movies" % base_url, 'sortare', thumb),
            ('TV', "https://%s/torrents.php?parent_cat=TV" % base_url, 'sortare', thumb),
            ('Documentaries', "https://%s/torrents.php?parent_cat=Documentaries" % base_url, 'sortare', thumb),
            ('Anime', "https://%s/torrents.php?parent_cat=Anime" % base_url, 'sortare', thumb),
            ('XXX', "https://%s/torrents.php?parent_cat=XXX" % base_url, 'sortare', thumb)]
    l = []
    for x in cats:
        l.append((cats.get(x), 'https://%s/torrents.php?cat=%s' % (base_url, x), 'sortare', thumb))
    menu.extend(l)
    menu.extend([('Căutare', base_url, 'cauta', searchimage)])
    
    headers = {'Host': '%s' % base_url,
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                'Referer': 'https://%s/' % base_url,
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3'}

    def cauta(self, keyword):
        url = "https://%s/torrents.php?search=%s&lang=0&nox=1&sort=seeders&order=desc&page=0" % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = self.thumb
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url, headers=self.headers)
                if link:
                    regex = '''onmouseover.+?hovercoverimg\s+src=(.+?)\s+.+?cat=(\d+).+?title="(.+?)".+?href="(magnet.+?)"(?:.+?<span.+?>(.+?)</span){2}(?:.+?<span.+?>(\[.+?.])</span)'''
                    blocks = re.findall(regex, link, re.DOTALL)
                    if blocks:
                        for image, cat, nume, legatura, size, peers in blocks:
                            legatura = unquote(legatura)
                            imagine = image if image else imagine
                            seeds, leeches = striphtml(peers).replace('[', '').replace(']', '').split('/')
                            if not (seeds == '0' and not zeroseed):
                                if self.cats.get(str(cat)):
                                    nume = '%s (%s) [S/L: %s/%s] ' % (nume, size, seeds, leeches)
                                    nume = '%s [COLOR green]%s[/COLOR]' % (nume, self.cats.get(str(cat)))
                                    size = formatsize(size)
                                    info = {'Title': nume,
                                            'Plot': nume,
                                            'Size': size,
                                            'Poster': imagine}
                                    lists.append((nume,legatura,imagine,'torrent_links', info))
                    match = re.compile("'page-link'").findall(link)
                    if len(match) > 0:
                        if 'page=' in url:
                            new = re.compile('page=(\d+)').findall(url)
                            nexturl = re.sub('page=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=1')
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s&page=0' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
                
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':torraction, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists

class yourbittorrent:
    
    base_url = 'yourbittorrent.com'
    thumb = os.path.join(media, 'yourbittorrent.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'YourBittorrent'
    cats = {'/adult.html': 'Adult',
            '/movies.html': 'Movies',
            '/television.html': 'TV',
            '/anime.html': 'Anime'}
    
    sortare = [('Ultimele', '&sort=id&order=desc'),
               ('După seederi', '&sort=seeders&order=desc'),
               ('După nume', '&sort=name&order=desc'),
               ('După mărime', '&sort=size&order=desc')]
    
    menu = [('Recente', "https://%s/new/1.html" % base_url, 'recente', thumb)]
    l = []
    for x in cats:
        l.append((cats.get(x), 'https://%s%s/1.html' % (base_url, x.replace('.html', '')), 'get_torrent', thumb))
    menu.extend(l)
    menu.extend([('Căutare', base_url, 'cauta', searchimage)])
    
    headers = {'Host': '%s' % base_url,
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                'Referer': 'https://%s/' % base_url,
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3'}
    
    def getTorrentFile(self, url):
        content = makeRequest(url, name=self.__class__.__name__, headers=self.headers, raw='1')
        return saveTorrentFile(url, content)
    
    def cauta(self, keyword):
        url = "https://%s/?q=%s&page=1" % (self.base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        imagine = self.thumb
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url, headers=self.headers)
                if link:
                    regex = '''<tr\s+class(.+?)</tr>'''
                    regex_tr = '''<td.+?(?:.+?href=[\'"](.+?)[\'"].+?(?:title="(.+?)".+?)?|.+?)?>(.+?)</td>'''
                    blocks = re.findall(regex, link, re.DOTALL)
                    for block in blocks:
                            match=re.findall(regex_tr, block, re.DOTALL)
                            if match:
                                try:
                                    cat, nume, size, added, seeds, leeches, nimic = match
                                    cat = cat[0]
                                    if cat in self.cats:
                                        legatura = 'https://%s%s' % (self.base_url, nume[0])
                                        nume = striphtml(nume[1]).replace('&nbsp;', '').strip()
                                        size = size[2]
                                        added = added[2]
                                        seeds = seeds[2]
                                        leeches = leeches[2]
                                        nume = '%s (%s) [S/L: %s/%s] ' % (nume, size, seeds, leeches)
                                        nume = '%s [COLOR green]%s Added %s[/COLOR]' % (nume, self.cats.get(cat), added)
                                        size = formatsize(size)
                                        info = {'Title': nume,
                                                'Plot': nume,
                                                'Size': size,
                                                'Poster': imagine}
                                        lists.append((nume,legatura,imagine,'torrent_links', info))
                                except: pass
                    match = re.compile('"page-link"').findall(link)
                    if len(match) > 0:
                        if 'page=' in url:
                            new = re.compile('page=(\d+)').findall(url)
                            nexturl = re.sub('page=(\d+)', 'page=' + str(int(new[0]) + 1), url)
                        if url.endswith('.html'):
                            new = re.compile('/(\d+)\.html').findall(url)
                            nexturl = re.sub('/(\d+)\.html', '/' + str(int(new[0]) + 1) + '.html', url)
                        lists.append(('Next', nexturl, self.nextimage, 'get_torrent', {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s&page=0' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
                
        elif meniu == 'torrent_links':
            link = fetchData(url)
            try:
                url = 'https://%s%s' % (self.base_url, re.findall('href=(/down/.+?.torrent)', link)[0])
                turl = self.getTorrentFile(url)
                action = torraction if torraction else ''
                openTorrent({'Tmode':torraction, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            except: pass
            
        return lists
