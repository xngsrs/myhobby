# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'https://filme-online.to'

class filmeonlineto:
    
    thumb = os.path.join(media, 'filmeonlineto.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'Filme-Online.to'
    menu = [('Recente', base_url, 'recente', thumb),
            ('Genuri', '0', 'genuri', thumb),
            ('Filme', '0', 'filme', thumb),
            ('Seriale', '0', 'seriale', thumb),
            ('Căutare', base_url, 'cauta', searchimage)
            ]
        
    def get_search_url(self, keyword):
        url = base_url + '/search/' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword, result):
        result.append((self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')))

    def parse_menu(self, url, meniu, info={}):
        lists = []
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                gid = re.search('gid="(.+?)"', link)
                regex_submenu = '''data-movie-id="(.+?)".+?href="(.+?)".+?data-url="(.+?)".+?(?:eps">(.+?)</span.+?)?(?:quality"(?:[a-zA-Z\n\s#=":]+)?>(.+?)<.+?)?data-original="(.+?)".+?info">(.+?)</span'''
                if link:
                    match = re.compile(regex_submenu, re.DOTALL).findall(link)
                    for mid, legatura, infolink, season, calitate, imagine, nume in match:
                        nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                        info = {'Title': nume,'Plot': nume,'Poster': imagine}
                        lists.append((nume, '%sssss%sssss%s' % (mid, legatura, gid.group(1) if gid else 'nimic'), imagine, 'get_all', info))
        elif meniu == 'seriale' or meniu == 'filme' or meniu == 'gen':
            tip = 'tip'
            new_url = base_url + '/ajax/filtru.php'
            if meniu == 'gen':
                tip = 'genul'
                gen = url.split('ssss')
                try: genul = gen[0].rsplit('/', 1)[-1]
                except: genul = gen[0]
                tipmode = genul
                url = gen[1]
                #url.rsplit('/', 1)[-1]
            elif meniu == 'seriale': tipmode = 'tv'
            elif meniu == 'filme': tipmode = 'film'
            data = {tip: tipmode, 'offset': url}
            link = fetchData(new_url, data=data)
            #gid = re.search('gid="(.+?)"', link)
            regex_submenu = '''data-movie-id="(.+?)".+?href="(.+?)".+?data-url="(.+?)".+?(?:eps">(.+?)</span.+?)?(?:quality"(?:[a-zA-Z\n\s#=":]+)?>(.+?)<.+?)?data-original="(.+?)".+?info">(.+?)</span'''
            if link:
                match = re.compile(regex_submenu, re.DOTALL).findall(link)
                for mid, legatura, infolink, season, calitate, imagine, nume in match:
                    nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                    info = {'Title': nume,'Plot': nume,'Poster': imagine}
                    lists.append((nume, '%sssss%s' % (mid, legatura), imagine, 'get_all', info))
                nexturl = int(url) + 48
                if meniu == 'gen': lists.append(('Next', '%sssss%s' % (genul, nexturl), self.nextimage, meniu, {}))
                else: lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_all':
            url = url.split('ssss')
            gid = re.search('gid="(.+?)"', fetchData(url[1], base_url))
            if gid: gid = gid.group(1)
            else: gid = 'nimic'
            info = json.loads(info)
            titlu = info.get('Title')
            new_url = '%s/ajax/mep.php?id=%s' % (base_url, url[0])
            link = fetchData(new_url, rtype='json')
            regex_servers = r'''div id="sv-(.+?)</div></div>'''
            if link:
                servers = re.findall(regex_servers, link.get('html'))
                for server in servers:
                    server_number = re.findall(r'''"ep-.+?data-id=[\\'"]+(.+?)[\\'"]+.+?epNr=[\\'"]+(.+?)[\\'"]+.+?so=[\\'"]+(.+?)[\\'"]+[\s\w-]+=[\\'"]+(.+?)[\\'"]+.+?data-index=[\\'"]+(.+?)[\\'"]+.+?ep-item[\sso\d\\">]+(.+?)<''', server, flags=re.I)
                    for data_id, ep_nr, data_so, data_server, data_index, name in server_number:
                        #if data_server == '5' or data_server == '6':
                        if data_server == '5': numeserver = '1'
                        elif data_server == '6': numeserver = '2'
                        elif re.search('openload', data_server, flags=re.I): numeserver = 'OpenLoad'
                        else: numeserver = None
                        if numeserver:
                            #if ep_nr <> '0' and not '/tv/' in url[1]:
                            if '/tv/' in url[1]:
                                nume = titlu.split('-')
                                nameone = nume[0]
                                sezon = str(re.findall('season[\s+](\d+)', nume[1], re.IGNORECASE)[0])
                                episod = ep_nr
                                info['Title'] = name
                                info['Season'] = sezon
                                info['Episode'] = episod
                                info['TVShowTitle'] = nameone
                            else:
                                nameone = None
                            link1 = '%sssss%sssss%sssss%sssss%sssss%sssss%sssss%s' % (
                                url[0], data_id, data_so, data_server, url[1], gid, ep_nr, data_index)
                            lists.append(('[COLOR lime]Server - %s:[/COLOR] %s %s' % (
                                numeserver, nameone if nameone else titlu, name),link1,'','get_links', str(info)))
        elif meniu == 'get_links':
            link_parts = url.split('ssss')
            gid = link_parts[5] if not link_parts[5] == 'nimic' else ''
            url_tokens = '%s/ajax/mtoken.php?eid=%s&mid=%s&so=%s&server=%s' % (
                base_url, link_parts[1], link_parts[0], link_parts[2], link_parts[3])
            tokens = fetchData(url_tokens, link_parts[4], headers={'Host': 'filme-online.to'})
            x = re.search('''_x=['"]([^"']+)''', tokens)
            if x: x = x.group(1)
            y = re.search('''_y=['"]([^"']+)''', tokens)
            if y: y = y.group(1)
            ip = re.search('''_ip(?:[\s+])?=(?:[\s+])?['"]([^"']+)''', tokens)
            if ip: ip = ip.group(1)
            else: ip = ''
            z = re.search('''_z(?:[\s+])?=(?:[\s+])?['"]([^"']+)''', tokens)
            if z: z = z.group(1)
            else: z = ''
            if re.search('openload', link_parts[3], flags=re.I):
                url_source = '%s/ajax/movie_embed.php?eid=%s&lid=undefined&ts=&up=0&mid=%s&gid=%s&epNr=%s&type=tv&server=NaN&epIndex=%s&so=%s' % (
                    base_url, link_parts[1], link_parts[0], gid, link_parts[6], link_parts[7], link_parts[2])
            else:
                url_source = '%s/ajax/msources.php?eid=%s&x=%s&y=%s&z=%s&ip=%s&mid=%s%s&lang=rum&epIndex=%s&server=%s&so=%s&epNr=%s' % (
                    base_url, link_parts[1], x, y, z, ip, link_parts[0], '&gid=%s' % gid if gid else '', link_parts[7], link_parts[3], link_parts[2], link_parts[6])
            one_urls = fetchData(url_source, link_parts[4], rtype='json', headers={'Host': 'filme-online.to'})
            if one_urls:
                if re.search('openload', link_parts[3], flags=re.I):
                    try: 
                        playlink = one_urls.get('src')
                        sublink = None
                    except: pass
                else:
                    try: playlink = one_urls.get('playlist')[0].get('sources').get('file')
                    except: playlink = one_urls.get('playlist')[0].get('sources')[0].get('file')
                    try: 
                        dialogb = xbmcgui.Dialog()
                        tracks = one_urls.get('playlist')[0].get('tracks')
                        if len(tracks) > 1:
                            sel = dialogb.select("Alege subtitrarea", [sel_s.get('label') for sel_s in tracks])
                        else: sel = 0
                        sublink = tracks[sel].get('file')
                        sublink = '%s%s' % (base_url, sublink) if sublink.startswith('/') else sublink
                    except: sublink = None
                #log(one_urls)
                #liz = xbmcgui.ListItem(link_parts[3])
                #xbmc.Player().play(playlink, liz, False)
                #log('sublink: ' + str(sublink))
                #from resources import Core
                #core = Core.Core()
                #core.executeAction({'info': quote(info), 'favorite': 'check', 'site': 'filmeonlineto', 'landing': quote(link_parts[4]), 'nume': '5', 'switch': 'play', 'link': quote(playlink), 'action': 'OpenSite', 'watched': 'check', 'subtitrare': quote(sublink)})
                data = json.loads(info)
                if data.get('TVShowTitle'):
                    viewmark = url
                    playname = '%s %s' % (data.get('TVShowTitle'), data.get('Title'))
                else: 
                    viewmark = link_parts[4]
                    playname = data.get('Title')
                if not sublink: playname = playname + ' Fara subtitrare pe site'
                if playlink: lists.append(('Play %s' % (playname),playlink,'','play', info, viewmark, sublink))
        elif meniu == 'genuri':
            link = fetchData(base_url)
            regex = '''title="genuri"(.+?)</div'''
            regex_cats = '''href="(.+?)">(.+?)<'''
            if link:
                for cats in re.findall(regex, link, re.DOTALL | re.IGNORECASE):
                    match = re.findall(regex_cats, cats, re.DOTALL)
                    if len(match) >= 0:
                        for legatura, nume in sorted(match, key=self.getKey):
                            legatura = '%sssss0' % legatura
                            lists.append((nume,legatura,'','gen', info))
        return lists
              
