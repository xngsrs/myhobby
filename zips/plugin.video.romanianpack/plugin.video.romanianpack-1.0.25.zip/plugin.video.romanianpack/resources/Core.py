# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from functions import *
import threading
from resources.lib.scrapers import __all__, __disabled__
import json

class player(xbmc.Player):
    def __init__ (self):
        xbmc.Player.__init__(self)
        
    def run(self, url, item, params, link):
        xbmc.sleep(200)
        self.totalTime = 0
        self.currentTime = 0
        self.total = 0
        if params.get('landing'): 
            self.landing = params.get('landing')
            params.update({'link': self.landing, 'switch' : 'get_links'})
        else: self.landing = None
        self.info = params
        #item.setPath(url)
        #xbmcgui.ListItem(path=url)
        if link == url or params.get('subtitrare'):
            if params.get('subtitrare'):
                self.subtitrare = get_sub(unquote(params.get('subtitrare')), unquote(self.landing), '1')
            else:
                self.subtitrare = None#get_sub(link, unquote(self.landing))
        else: self.subtitrare = get_sub(link, unquote(self.landing))
        xbmc.Player().play(url, item)
        
        #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        self.looptime()
        
    def onPlayBackStarted(self):
        if self.subtitrare:
            xbmc.Player().setSubtitles(self.subtitrare)
    
    def looptime(self):
        for i in range(0, 240):
            if self.isPlayingVideo(): break
            xbmc.sleep(1000)
        while not xbmc.abortRequested and self.isPlaying():
                    self.totalTime = self.getTotalTime()
                    self.currentTime = self.getTime()
                    self.total = ((float(self.currentTime)/float(self.totalTime))*100) if self.currentTime > 0 else 0
                    xbmc.sleep(2000)

    def onPlayBackStopped(self):
        if self.total > 80 and self.landing and self.totalTime > 1000:
            xbmc.sleep(100)
            Core().watched({'watched' : 'save', 'watchedlink' : self.landing, 'detalii': quote(str(self.info)), 'norefresh' : '1'})
            
    def onPlayBackEnded(self):
        self.onPlayBackStopped()


class Core:
    __plugin__ = sys.modules["__main__"].__plugin__
    __settings__ = sys.modules["__main__"].__settings__
    __scriptname__ = __settings__.getAddonInfo('name')
    ROOT = sys.modules["__main__"].__root__
    scrapers = os.path.join(ROOT, 'resources', 'lib', 'scrapers')
    if scrapers not in sys.path: sys.path.append(scrapers)
    create_tables()

    def sectionMenu(self):
        
        self.drawItem('[COLOR lime]Recente[/COLOR]', 'recents', {}, image=search_icon)
        self.drawItem('[COLOR lime]Categorii[/COLOR]', 'getCats', {}, image=search_icon)
        self.drawItem('[COLOR lime]Favorite[/COLOR]', 'favorite', {'site': 'site', 'favorite': 'print'}, image=search_icon)
        self.drawItem('[COLOR lime]Căutare[/COLOR]', 'searchSites', {}, image=search_icon)
        self.drawItem('[COLOR lime]Marcate ca vizionate[/COLOR]', 'watched', {'watched': 'list'}, image=search_icon)
        #self.drawItem('[COLOR lime]Setări[/COLOR]', 'openSettings', {}, image=search_icon, isFolder=False)
        for site in __all__:
            cm = []
            imp = getattr(__import__(site), site)
            name = imp().name
            params = {'site': site}
            cm.append(self.CM('disableSite', 'disable', nume=site))
            self.drawItem(name, 'openMenu', params, image=imp().thumb, contextMenu=cm)
        for site in __disabled__:
            cm = []
            imp = getattr(__import__(site), site)
            name = imp().name
            params = {'site': site, 'nume': name, 'disableSite': 'check'}
            cm.append(self.CM('disableSite', 'enable', nume=site))
            self.drawItem('[COLOR red]%s[/COLOR]'% name, 'disableSite', params, image=imp().thumb, contextMenu=cm, isFolder=False, replaceMenu=False)

        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
    
    def disableSite(self, params={}):
        get = params.get
        action = get('disableSite')
        nume = get('nume')
        site = get('site')
        if not nume: nume = site
        if action == 'disable':
            #try:  os.rename(os.path.join(self.scrapers,'%s.py' % nume), os.path.join(self.disabled,'%s.py' % nume))
            #except: pass
            self.__settings__.setSetting(id=nume, value='false')
            xbmc.executebuiltin("Container.Refresh")
        elif action == 'enable':
            acces = '1'
            parola = self.__settings__.getSetting('parolasite')
            if parola and not parola == '0':
                dialog = xbmcgui.Dialog()
                d = dialog.input('Parola', type=xbmcgui.INPUT_NUMERIC)
                if d == self.__settings__.getSetting('parolasite'): acces = '1'
                else: acces = None
            if acces:
                self.__settings__.setSetting(id=nume, value='true')
                #os.rename(os.path.join(self.disabled,'%s.py' % nume), os.path.join(self.scrapers,'%s.py' % nume))
                xbmc.executebuiltin("Container.Refresh")
            else: ret = dialog.ok(self.__scriptname__, 'Ai introdus parola greșită')
        elif action == 'check':
            dialog = xbmcgui.Dialog()
            ret = dialog.yesno(self.__scriptname__, '%s este dezactivat' % nume, 'Vrei sa îl activezi?', yeslabel='Da', nolabel='Nu' )
            if ret == 1:
                self.disableSite({'disableSite': 'enable', 'site': site})
            #xbmc.executebuiltin('XBMC.Notification(%s, "%s dezactivat")' % (self.__scriptname__, nume))
            
    
    def openMenu(self, params={}):
        get = params.get
        site = get('site')
        imp = getattr(__import__(site), site)
        menu = imp().menu
        if menu:
            for name, url, switch, image in menu:
                params = {'site': site, 'link': url, 'switch': switch }
                self.drawItem(name, 'OpenSite', params, image=image)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
        
    def getCats(self, params={}):
        categorii = {'Actiune': ['actiune', 'action'],
                 'Adulti': ['adult +18', 'erotic', 'erotice'],
                 'Aventura': ['aventura', 'aventuri'],
                 'Biografic': ['biografie', 'biografic'],
                 'Comedie': ['comedie', 'comedy'],
                 'Crima': ['crima', 'crime'],
                 'Familie': ['familie', 'family'],
                 'Horror': ['horror', 'groaza'],
                 'Istoric' : ['istoric', 'istorice', 'istorie'],
                 'Muzical': ['musical', 'muzical', 'muzicale', 'muzica (musical)'],
                 'Psihologic': ['psihologice', 'psihologic'],
                 'Sci-Fi': ['sci-fi', 'science – fiction (sf)', 'sf', 's-f', 'sci-fi &amp; fantasy'],
                 'Romantic': ['romantic', 'romantice'],
                 'Documentar': ['documentar', 'documentare'],
                 'Fantezie': ['fantastic', 'fantezie', 'fantasy'],
                 'Seriale': ['seriale', 'seriale online'],
                 'Romanesc': ['romanesti', 'romanesc'],
                 'Thriller': ['thriller', 'suspans'],
                 'Razboi' : ['war', 'razboi']}
        cat_list = {}
        all_links = []
        threads = []
        for site in __all__:
            imp = getattr(__import__(site), site)
            menu = imp().menu
            if menu:
                for name, url, switch, image in menu:
                    if switch == 'genuri':
                        params = {'site': site, 'link': url, 'switch': switch }
                        threads.append(threading.Thread(name=imp().name, target=self.OpenSite, args=(params, '2', None, all_links)))
        get_threads(threads, 'Deschidere', 1)
        for cat in all_links:
            for j in categorii:
                for k in categorii.get(j):
                    if cat[0].lower() == k:
                        cat[0] = j
            if cat[0].lower() in cat_list:
                cat_list[cat[0].lower()].append(cat)
            else:
                cat_list[cat[0].lower()] = []
                cat_list[cat[0].lower()].append(cat)
        for nume in sorted(cat_list):
            cat_plots = []
            for cat_plot in cat_list[nume]:
                cat_plots.append(getattr(__import__(cat_plot[2].get('site')), cat_plot[2].get('site'))().name)
            params = {'categorie': quote(json.dumps(cat_list[nume])), 'info': {'Plot': 'Categorie găsită pe: \n%s' % (", ".join(cat_plots))}}
            self.drawItem(nume.capitalize(), 'openCat', params, image=search_icon)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
    
    def openCat(self, params={}):
        threads = []
        all_links = []
        nextlink = []
        get = params.get
        if get('categorie'):
            categorie = json.loads(unquote(get('categorie')))
            for nume, action, pars, imagine, cm in categorie:
                threads.append(threading.Thread(name=pars.get('site'), target=self.OpenSite, args=(pars, '2', None, all_links)))
            get_threads(threads, 'Deschidere', 1)
            for nume, action, params, imagine, cm in all_links:
                if nume == 'Next':
                    nextlink.append([nume, 'OpenSite', params, imagine, cm])
                else:
                    site = getattr(__import__(params.get('site')), params.get('site'))().name
                    self.drawItem('[COLOR red]%s:[/COLOR] %s' % (site, nume), action, params, image=imagine, contextMenu=cm)
            if len(nextlink) > 0:
                paramsnext = {'categorie': quote(json.dumps(nextlink))}
                self.drawItem('Next', 'openCat', paramsnext, image=next_icon)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
        
    def getMeta(self, params={}):
        import metainfo
        disp = metainfo.window()
        disp.get_n(unquote(params.get('nume')), unquote(params.get('getMetalink')))
        disp.doModal()
        del disp
    
    def OpenSite(self, params={}, handle=None, limit=None, all_links=[]):
        #xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        get = params.get
        switch = get('switch')
        link = unquote(get('link'))
        nume = get('nume')
        site = get('site')
        info = unquote(get('info')) if get('info') else None
        if switch == 'play':
            dp = xbmcgui.DialogProgressBG()
            dp.create(self.__scriptname__, 'Starting...')
            liz = xbmcgui.ListItem(nume)
            if info: 
                info = eval(info)
                liz.setInfo(type="Video", infoLabels=info); liz.setArt({'thumb': info['Poster']})
            else: liz.setInfo(type="Video", infoLabels={'Title':unquote(nume)})
            dp.update(50, message='Starting...')
            try:
                params.update({'info' : info})
                if not re.search('appspot|blogspot', link):
                    import urlresolver
                    hmf = urlresolver.HostedMediaFile(url=link, include_disabled=True, include_universal=False)
                    play_link = hmf.resolve()
                else:
                    if re.search('blogspot', link):
                        play_link = urllib2.urlopen(link)
                        play_link = play_link.geturl()
                        play_link = link
                    else: play_link = link
                dp.update(100, message='Starting...')
                xbmc.sleep(100)
                dp.close()
                player().run(play_link, liz, params, link)
                #xbmc.Player().play(hmf.resolve(), liz, False)
            except Exception as e:
                dp.close()
                xbmc.executebuiltin('XBMC.Notification("Eroare", "%s")' % e)
            #xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
            #xbmc.executebuiltin('Action(Back)')
        else:
            menu = getattr(__import__(site), site)().parse_menu(link, switch, info)
            count = 1
            if menu:
                for datas in menu:
                    cm = []
                    count += 1
                    nume = datas[0]
                    url = datas[1]
                    imagine = datas[2]
                    switch = datas[3]
                    infoa = datas[4]
                    if len(datas) > 5: landing = datas[5]
                    else: landing = None
                    if len(datas) > 6: subtitrare = datas[6]
                    else: subtitrare = None
                    
                    params = {'site': get('site'), 'link': url, 'switch': switch, 'nume': nume, 'info': infoa, 'favorite': 'check', 'watched': 'check'}
                    if not nume == 'Next':
                        if infoa:
                            try: cm.append(self.CM('getMeta', url=url, nume=str(nume)))
                            except: cm.append(self.CM('getMeta', url=url, nume=str(nume.encode('utf-8'))))
                        if self.favorite(params):
                            nume = '[COLOR yellow]Fav[/COLOR] - %s' % nume
                            cm.append(self.CM('favorite', 'delete', url, nume))
                        else: cm.append(self.CM('favorite', 'save', url, nume, str(params)))
                        if self.watched(params):
                            if not isinstance(params['info'], dict):
                                params['info'] = eval(str(params['info']))
                            params['info'].update({'playcount': 1, 'overlay': 7})
                            cm.append(self.CM('watched', 'delete', url))
                        else:
                            try:
                                if not isinstance(params['info'], dict):
                                    params['info'] = eval(str(params['info']))
                                params['info'].update({'playcount': 0, 'overlay': 6})
                            except: pass
                            cm.append(self.CM('watched', 'save', landing if landing else url, params=str(params)))
                        if landing: params.update({'landing': landing})
                        if subtitrare: params.update({'subtitrare': subtitrare})
                        
                    #if switch == 'get_links': self.drawItem(nume, 'OpenSite', params, isFolder=False, image=imagine, contextMenu=cm)
                    if handle: 
                        if handle == '1': all_links.append(['[COLOR red]%s:[/COLOR] %s' % (getattr(__import__(get('site')), get('site')).name, nume), 'OpenSite', params, imagine, cm])
                        elif handle == '2': all_links.append([nume, 'OpenSite', params, imagine, cm])
                    else: self.drawItem(nume, 'OpenSite', params, image=imagine, contextMenu=cm)
                    if limit:
                        if count > int(limit):
                            break
            if not handle:
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
    
    def recents(self, params):
        all_links = []
        threads = []
        for site in __all__:
            imp = getattr(__import__(site), site)
            menu = imp().menu
            if menu:
                for name, url, switch, image in menu:
                    if name.lower() == 'recente':
                        params = {'site': site, 'link': url, 'switch': switch }
                        threads.append(threading.Thread(name=imp().name, target=self.OpenSite, args=(params, '1', '5', all_links)))
                        #self.OpenSite(params, '1', '5')
        get_threads(threads, 'Deschidere', 1)
        for nume, action, params, imagine, cm in all_links:
            self.drawItem(nume, action, params, image=imagine, contextMenu=cm)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
    
    def favorite(self, params):
        get = params.get
        action = get('favorite')
        if action == "save":
            save_fav(unquote(get('nume')), unquote(get('favoritelink')), unquote(get('detalii')), get('norefresh'))
        elif action == "check":
            check = get_fav(unquote(get('link')))
            if check: return True
            else: return False
        elif action == "delete":
            del_fav(unquote(get('favoritelink')), get('norefresh'))
        elif action == "print":
            favs = get_fav()
            if favs:
                for fav in favs[::-1]:
                    cm = []
                    if fav[0]:
                        fav_info = eval(fav[2])
                        cm.append(self.CM('getMeta', url=fav_info.get('link'), nume=str(fav_info.get('nume'))))
                        if self.watched({'watched': 'check', 'link': fav[0]}):
                            fav_info['info'].update({'playcount': 1, 'overlay': 7})
                            cm.append(self.CM('watched', 'delete', fav_info.get('link')))
                        else:
                            fav_info['watched'] = 'check'
                            cm.append(self.CM('watched', 'save', fav_info.get('link'), params=str(fav_info)))
                        cm.append(self.CM('favorite', 'delete', fav[0], fav[1]))
                        name = getattr(__import__(fav_info.get('site')), fav_info.get('site'))().name
                        self.drawItem('[COLOR red]%s:[/COLOR] %s' % (name, fav[1]), 'OpenSite', fav_info, contextMenu = cm)
            xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
    
    def watched(self, params):
        get = params.get
        action = get('watched')
        if action == 'save':
            if get('norefresh'): save_watched(unquote(get('watchedlink')), unquote(get('detalii')), '1')
            else: save_watched(unquote(get('watchedlink')), unquote(get('detalii')))
        elif action == 'delete':
            delete_watched(unquote(get('watchedlink')))
        elif action == 'check':
            return get_watched(unquote(get('link')))
        elif action == 'list':
            watch = list_watched()
            if watch:
                for watcha in watch[::-1]:
                    if watcha[0]:
                        cm = []
                        watcha_info = eval(unquote(watcha[1]))
                        if not isinstance(watcha_info.get('info'), dict):
                            watcha_info['info'] = eval(str(watcha_info.get('info')))
                        watcha_ii = watcha_info.get('info').get('Title') if watcha_info.get('info').get('Title') == watcha_info.get('nume') else watcha_info.get('info').get('Title') + ' - ' + watcha_info.get('nume')
                        cm.append(self.CM('getMeta', url=watcha_info.get('link'), nume=str(watcha_ii)))
                        cm.append(self.CM('watched', 'delete', watcha[0]))
                        if self.favorite(watcha_info):
                            watcha_ii = '[COLOR yellow]Fav[/COLOR] - %s' % watcha_ii
                            cm.append(self.CM('favorite', 'delete', watcha_info.get('link'), watcha_ii))
                        else: cm.append(self.CM('favorite', 'save', watcha_info.get('link'), watcha_ii, str(watcha_info)))
                        name = getattr(__import__(watcha_info.get('site')), watcha_info.get('site'))().name
                        self.drawItem('[COLOR red]%s:[/COLOR] %s' % (name, watcha_ii), 'OpenSite', watcha_info, contextMenu = cm)
            xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
    
    def openSettings(self, params={}):
        self.__settings__.openSettings()
    
    def searchSites(self, params={}):
        get = params.get
        if get('landsearch'): landing = get('landsearch')
        else: landing = None
        if get('searchSites') == 'delete':
            del_search(unquote(get('cuvant')))
        elif get('searchSites') == 'edit':
            keyboard = xbmc.Keyboard(unquote(get('cuvant')))
            keyboard.doModal()
            if (keyboard.isConfirmed() == False): return
            keyword = keyboard.getText()
            if len(keyword) == 0: return
            else:
                save_search(keyword)
                xbmc.executebuiltin("Container.Refresh")
        elif get('searchSites') == 'noua':
            keyboard = xbmc.Keyboard('')
            keyboard.doModal()
            if (keyboard.isConfirmed() == False): return
            keyword = keyboard.getText()
            if len(keyword) == 0: return
            else: self.get_searchsite(keyword, landing)
        elif get('searchSites') == 'cuvant':
            self.get_searchsite(unquote(get('cuvant')), landing)
        elif not get('searchSites'):
            cautari = get_search()
            if cautari:
                param_new = params
                param_new['searchSites'] = 'noua'
                if get('landsearch'):
                    param_new['landsearch'] = get('landsearch')
                self.drawItem('Căutare nouă' , 'searchSites', param_new, image=search_icon)
                for cautare in cautari[::-1]:
                    cm = []
                    new_params = params
                    new_params['cuvant'] = cautare[0]
                    new_params['searchSites'] = 'cuvant'
                    if get('landsearch'):
                        param_new['landsearch'] = get('landsearch')
                    cm.append(self.CM('searchSites', 'edit', cuvant=cautare[0]))
                    cm.append(self.CM('searchSites', 'delete', cuvant=cautare[0]))
                    self.drawItem(unquote(cautare[0]) , 'searchSites', new_params, image=search_icon, contextMenu=cm )
            else:
                keyboard = xbmc.Keyboard('')
                keyboard.doModal()
                if (keyboard.isConfirmed() == False): return
                keyword = keyboard.getText()
                if len(keyword) == 0: return
                else: self.get_searchsite(keyword, landing)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)

    def get_searchsite(self, word, landing=None):
        threads = []
        result = []
        save_search(unquote(word))
        if landing:
            imp = getattr(__import__(landing), landing)
            site_name = imp().name
            total = 1
            imp().cauta(word, result)
        else:
            for i in range(len(__all__)):
            #for site in __all__:
                    site = __all__[i]
                    imp = getattr(__import__(site), site)
                    site_name = imp().name
                    #dp.update(int((100 / float(len(__all__))) * i), site_name, site_name)
                    threads.append(threading.Thread(name=site_name, target=imp().cauta, args=(word, result,)))
            get_threads(threads, progress=1)
        for results in result:
            if results[2]:
                site = results[0]
                site_name = results[1]
                for link in results[2]:
                    nume = link[0]
                    url = link[1]
                    imagine = link[2]
                    switch = link[3]
                    infoa = link[4]
                    params = {'site': site, 'link': url, 'switch': switch, 'nume': nume, 'info': infoa, 'favorite': 'check', 'watched': 'check'}
                    if nume != 'Next' or landing:
                        cm = []
                        cm.append(self.CM('getMeta', url=url, nume=str(nume)))
                        if self.watched(params):
                            params['info'].update({'playcount': 1, 'overlay': 7})
                            cm.append(self.CM('watched', 'delete', url, norefresh='1'))
                        else:
                            try: params['info'].update({'playcount': 0, 'overlay': 6})
                            except: pass
                            cm.append(self.CM('watched', 'save', url, params=str(params), norefresh='1'))
                        if self.favorite(params):
                            nume = '[COLOR yellow]Fav[/COLOR] - %s' % nume
                            cm.append(self.CM('favorite', 'delete', url, nume, norefresh='1'))
                        else:
                            cm.append(self.CM('favorite', 'save', url, nume, params, norefresh='1'))
                        self.drawItem('[COLOR red]%s[/COLOR] - %s' % (site_name, nume) if not landing else nume, 'OpenSite', params, image=imagine, contextMenu=cm)
                        
        
    def CM(self, action, subaction=None, url=None, nume=None, params=None, norefresh=None, cuvant=None):
        text = action
        if action == 'favorite' and subaction == 'delete': text = 'Șterge din favorite'
        elif action == 'favorite' and subaction == 'save': text = 'Adaugă la favorite'
        elif action == 'watched' and subaction == 'delete': text = 'Marchează ca nevizionat'
        elif action == 'watched' and subaction == 'save': text = 'Marchează ca vizionat'
        elif action == 'searchSites' and subaction == 'delete': text = 'Șterge din căutări'
        elif action == 'searchSites' and subaction == 'edit': text = 'Modifică'
        elif action == 'disableSite' and subaction == 'enable': text = 'Activează'
        elif action == 'disableSite' and subaction == 'disable': text = 'Dezactivează'
        elif action == 'getMeta': text = 'MetaInfo'
        cm = (text, 'xbmc.RunPlugin(%s?action=%s%s%s%s%s%s%s,)' % (sys.argv[0],
                                                                   action,
                                                                   '&' + action + '=' + subaction if subaction else '',
                                                                   '&' + action + 'link=' + quote(url) if url else '',
                                                                   '&nume=' + quote(nume) if nume else '',
                                                                   '&detalii=' + quote(str(params)) if params else '',
                                                                   '&norefresh=1' if norefresh else '',
                                                                   '&cuvant=' + quote(cuvant) if cuvant else ''))
        return cm
        
    def drawItem(self, title, action, link='', image='', isFolder=True, contextMenu=None, replaceMenu=True, action2='', fileSize=0L):
        #log('[drawItem]:'+str((title, action, image, isFolder, contextMenu, replaceMenu, action2, info)))
        """
        setArt(values) -- Sets the listitem's art
         values : dictionary - pairs of { label: value }.
            - Some default art values (any string possible):
                - thumb : string - image filename
                - poster : string - image filename
                - banner : string - image filename
                - fanart : string - image filename
                - clearart : string - image filename
                - clearlogo : string - image filename
                - landscape : string - image filename
                - icon : string - image filename
        example:
                - self.list.getSelectedItem().setArt({ 'poster': 'poster.png', 'banner' : 'banner.png' })
        """
        if isinstance(link, dict):
            link_url = ''
            if link.get('categorie'):
                link_url = '%s&%s=%s' % (link_url, 'categorie', link.get('categorie'))
            else:
                for key in link.keys():
                    if link.get(key):
                        if isinstance(link.get(key), dict):
                            link_url = '%s&%s=%s' % (link_url, key, quote(json.dumps(link.get(key), ensure_ascii=False)))
                        else:
                            link_url = '%s&%s=%s' % (link_url, key, quote(link.get(key)))
                            if key == 'switch' and link.get(key) == 'play': isFolder = False
            info = link.get('info')
            if info:
                if isinstance(info, str):
                    info  = eval(info)
                if isinstance(info, dict):
                    image = info.get('Poster')
            url = '%s?action=%s' % (sys.argv[0], action) + link_url
        else:
            info = {"Title": title, "plot": title}
            if not isFolder and fileSize:
                info['size'] = fileSize
            url = '%s?action=%s&url=%s' % (sys.argv[0], action, quote(link))
        if action2:
            url = url + '&url2=%s' % quote(ensure_str(action2))
        listitem = xbmcgui.ListItem(title)
        images = {'icon':image, 'thumb':image}
        images = {'icon': image, 'thumb': image,
                  'poster': image, 'banner': image,
                  #'fanart': image, 'landscape': image,
                  #'clearart': image, 'clearlogo': image,
                  }
        listitem.setArt(images)
        if isFolder:
            listitem.setProperty("Folder", "true")
            listitem.setInfo(type='Video', infoLabels=info)
        else:
            #listitem.setProperty('isPlayable', 'true')
            listitem.setInfo(type='Video', infoLabels=info)
            listitem.setArt({'thumb': image})
        if contextMenu:
            listitem.addContextMenuItems(contextMenu, replaceItems=replaceMenu)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=isFolder)

    def getParameters(self, parameterString):
        commands = {}
        splitCommands = parameterString[parameterString.find('?') + 1:].split('&')
        for command in splitCommands:
            if (len(command) > 0):
                splitCommand = command.split('=')
                if (len(splitCommand) > 1):
                    name = splitCommand[0]
                    value = splitCommand[1]
                    commands[name] = value
        return commands

    def executeAction(self, params={}):
        get = params.get
        if hasattr(self, get("action")):
            getattr(self, get("action"))(params)
        else:
            self.sectionMenu()

    def localize(self, string):
        #try:
            #return Localization.localize(string)
        #except:
        return string
