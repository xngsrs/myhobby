# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'https://filme-seriale.net'

class filmeserialegratis:
    
    thumb = os.path.join(media, 'filmeserialegratis.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'Filme-Seriale.gratis'
    menu = [('Recente', base_url, 'recente', thumb),
            ('Filme', base_url + '/filmeonline/', 'rece', thumb),
            ('Seriale', base_url + '/seriale/', 'rece', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword):
        return self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')

    def parse_menu(self, url, meniu, info={}):
        lists = []
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta' or meniu == 'rece':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                #log(link)
                regex_all = '''class="item_1 items"(.+?)paginador"'''
                regex_info = '''item".+?href="(.+?)".+?img src="(.+?)".+?"tt">(.+?)<.+?"ttx">(.+?)<.+?<.+?"year">(.+?)<.+?"calidad2">(.+?)<'''
                regex_n_v = '''(?:IMDB|TMDb):(.+?)</s.+?type.+?>(.+?)<'''
                if link:
                    for bloc in re.findall(regex_all, link, re.IGNORECASE | re.MULTILINE | re.DOTALL):
                        match = re.findall(regex_info, bloc, re.DOTALL)
                        voturi = re.findall(regex_n_v, bloc, re.IGNORECASE | re.DOTALL)
                        #for legatura, nume, tip, imagine, rating, an, sezon, episod, descriere, nume_episod, nume_serial in match:
                        for legatura, imagine, nume, descriere, an, tip in match:
                            imagine = imagine.strip()
                            try: imagine = re.findall('url=(.+?)$', imagine)[0]
                            except: pass
                            nume = htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')
                            descriere = htmlparser.HTMLParser().unescape(striphtml(descriere).decode('utf-8')).encode('utf-8')
                            info = {
                            'Title': nume,
                            'Poster': imagine,
                            'Plot': descriere.strip(),
                            'Year': an,
                            'PlotOutline': '%s' % (descriere.strip())
                            }
                            nume = (nume + ' - ' + tip) if tip else nume
                            if '/seriale/' in legatura:
                                lists.append((nume, legatura, imagine, 'get_episoade', info))
                            else:
                                lists.append((nume, legatura, imagine, 'get_links', info))
                match = re.search('"pagination"|"paginador"', link, flags=re.IGNORECASE)
                if match:
                    if '/page/' in url:
                        new = re.findall('/page/(\d+)', url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        if '/?s=' in url:
                            nextpage = re.findall('\?s=(.+?)$', url)
                            nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                        else: nexturl = url + "/page/2"
                    lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_episoade':
            link = fetchData(url)
            regex_season = '''"se-c".+?title">(.+?)<(.+?)</ul>'''
            regex_episode = '''numerando">(.+?)<.+?href="(.+?)">(.+?)<'''
            season = re.compile(regex_season, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
            info = eval(str(info))
            title = info['Title']
            for sezon, content in season:
                episode = re.compile(regex_episode, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(content)
                if sezon: lists.append(('[COLOR lime]%s[/COLOR]' % sezon,'nolink','','nimic', {}))
                #log(episode)
                for numerotare, legatura, nume_episod in episode:
                    epis = numerotare.split('x')
                    try:
                        infos = info
                        infos['Season'] = epis[0].strip()
                        infos['Episode'] = epis[1].strip()
                        infos['TVshowtitle'] = title
                        infos['Title'] = '%s S%02dE%02d' % (title, int(epis[0].strip()), int(epis[1].strip()))
                        infos['Plot'] = '%s S%02dE%02d - %s' % (title, int(epis[0].strip()), int(epis[1].strip()), plot)
                    except: pass
                    lists.append((striphtml(title + ' ' + str('S%02dE%02d' % (int(epis[0].strip()), int(epis[1].strip())))).replace("\n", ""),legatura,'','get_links', str(info)))
        elif meniu == 'get_links':
            link = fetchData(url)
            links = []
            regex_lnk = '''(?:text/javascript['"]>\s+str=["'](.+?)["']|<iframe.+?src=['"]((?:[htt]|[//]).+?)['"])'''
            match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
            for match1, match in match_lnk:
                if match1 and not match:
                    match1 = unquote(match1.replace('@','%'))
                    match1 = re.findall('<iframe.+?src="((?:[htt]|[//]).+?)"', match1, re.IGNORECASE | re.DOTALL)[0]
                    links.append((match1))
                if match:
                    links.append((match))
            for host, link1 in get_links(links):
                if not link1.endswith('.js'):
                    lists.append((host,link1,'','play', info, url))
                
        return lists
              
