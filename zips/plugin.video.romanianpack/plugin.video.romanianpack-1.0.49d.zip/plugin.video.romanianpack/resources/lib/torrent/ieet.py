# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'www.1337x.to'

class ieet:
    
    thumb = os.path.join(media, 'ieetx.png')
    nextimage = next_icon
    searchimage = search_icon
    name = '1337x'
    menu = [('Filme Recente', "https://%s/sort-cat/Movies/time/desc/1/" % base_url, 'recente', thumb),
            ('Seriale Recente', "https://%s/sort-cat/TV/time/desc/1/" % base_url, 'recente', thumb),
            ('Librarie Filme', "https://%s/movie-library/1/" % base_url, 'librarie', thumb),
            ('Filme populare in ultimele 24 ore', "https://%s/popular-movies" % base_url, 'get_torrent', thumb),
            ('Filme populare saptamana asta', "https://%s/popular-movies-week" % base_url, 'get_torrent', thumb),
            ('Filme top 100 ultima luna', "https://%s/top-100-movies" % base_url, 'get_torrent', thumb),
            ('Documentare top 100 ultima luna', "https://%s/top-100-documentaries" % base_url, 'get_torrent', thumb),
            ('Seriale', "https://%s/sort-cat/TV/seeders/desc/1/" % base_url, 'get_torrent', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    #def get_search_url(self, keyword):
        ##url = "https://%s/srch?search=%s" % (base_url, quote(keyword))
        ##url = "https://%s/sort-search/%s/seeders/desc/1/" % (base_url, quote(keyword))
        #return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword):
        url = "https://%s/sort-search/%s/seeders/desc/1/" % (base_url, quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'librarie':
            link = fetchData(url)
            regex = '''data-target.+?original="(.+?)".+?header">(.+?)<div.+?category">(.+?)</div.+?"content.+?">(.+?)</div.+?download".+?href="(.+?)"'''
            if link:
                match = re.findall(regex, link, re.DOTALL)
                for imagine, nume, categorie, descriere, legatura in match:
                    imagine = 'http:%s' % (imagine) if imagine.startswith('//') else imagine
                    #log(imagine)
                    legatura = 'https://%s%s' % (base_url, legatura)
                    descriere = htmlparser.HTMLParser().unescape(striphtml(descriere).decode('utf-8')).encode('utf-8').strip()
                    nume = htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8').strip()
                    info = {'Title': nume,
                        'Plot': descriere,
                        'Poster': imagine}
                    lists.append((nume,legatura,imagine,'get_torrent', info))
                match = re.findall('("pagination")', link, re.IGNORECASE)
                if len(match) > 0:
                    if re.search("/(\d+)/", url):
                        new = re.compile('/(\d+)/').findall(url)
                        nexturl = re.sub('/(\d+)/', '/' + str(int(new[0]) + 1) + '/', url)
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                infos = {}
                regex = '''<tr>(.+?)</tr>'''
                regex_tr = '''a><a href="(.+?)">(.+?)<.+?seeds">(.+?)<.+?leeches">(.+?)<.+?size.+?>(.+?)<'''
                tables = re.findall(regex, link, re.IGNORECASE | re.DOTALL)
                if tables:
                    for table in tables:
                        match = re.findall(regex_tr, table, re.IGNORECASE | re.DOTALL)
                        if match:
                            for legatura, nume, seeds, leechers, size in match:
                                size = size.replace('&nbsp;', ' ')
                                legatura = 'https://%s%s' % (base_url, legatura) if legatura.startswith('/') else legatura
                                nume = '%s  (%s) [S/L: %s/%s] ' % (striphtml(nume), size, seeds, leechers)
                                if not info:
                                    infos = {'Title': nume,
                                            'Plot': nume,
                                            'Poster': self.thumb}
                                else:
                                    infos = info
                                    try:

                                        infos = eval(str(infos))

                                        infos['Plot'] = '%s - %s' % (nume, infos['Plot'])
                                    except: pass
                                    #infos.update({'Plot': '%s - %s' % (nume, infos['Plot'])})
                                lists.append((nume,legatura,self.thumb,'torrent_links', infos))
                match = re.compile('"pagination"', re.IGNORECASE).findall(link)
                if len(match) > 0:
                    if re.search("/(\d+)/", url):
                        new = re.compile('/(\d+)/').findall(url)
                        nexturl = re.sub('/(\d+)/', '/' + str(int(new[0]) + 1) + '/', url)
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'torrent_links':
            openTorrent({'Tmode': 'viewtorrenter', 'Turl': url, 'site': self.__class__.__name__})
            
        return lists
              
