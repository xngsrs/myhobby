# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'http://filme-hq.ro'

class filmehq:
    
    thumb = os.path.join(media, 'filmehq.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'FilmeHQ'
    menu = [('Recente', base_url, 'recente', thumb), 
            ('Genuri', base_url, 'genuri', thumb),
            ('Cele mai vizionate', '%s/cele-mai-vizionate/' % base_url, 'filme', thumb),
            ('Cele mai comentate', '%s/cele-mai-comentate/' % base_url, 'filme', thumb),
            ('Cele mai apreciate', '%s/cele-mai-apreciate/' % base_url, 'filme', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword):
        return self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')

    def parse_menu(self, url, meniu, info={}):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else: 
                link = fetchData(url)
                regex_menu = '''"moviefilm"(.+?)</div>\s+</div'''
                regex_submenu = '''href="(.+?)".+?src="(.+?)".+?alt="(.+?)"'''
                if link:
                    for movie in re.compile(regex_menu, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                        match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                        for legatura, imagine, nume in match:
                            nume = htmlparser.HTMLParser().unescape(nume.decode('utf-8')).encode('utf-8')
                            info = {'Title': nume,'Plot': nume,'Poster': imagine}
                            lists.append((nume, legatura, imagine, 'get_all', info))
                    match = re.compile("'wp-pagenavi'", re.IGNORECASE).findall(link)
                    if len(match) > 0:
                        if '/page/' in url:
                            new = re.compile('/page/(\d+)').findall(url)
                            nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                        else:
                            if '/?s=' in url:
                                nextpage = re.compile('\?s=(.+?)$').findall(url)
                                nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                            else: nexturl = url + "/page/2"
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        
        elif meniu == "get_all":
            link = fetchData(url)
            regex_blinks = '''filmcontent.+?/>(\s+Server\s+\d+.+?)<.+?href="(http://play.filme.*?)"'''
            pages = re.findall(regex_blinks, link, re.IGNORECASE | re.DOTALL)
            if pages:
                for nume, legatura in pages:
                    lists.append((nume,legatura,'','get_links', info))
        
        elif meniu == "get_links":
            link = fetchData(url)
            regex_refresh = '''refresh.+?url=(.+?)"'''
            regex_lnk = '''<iframe.+?src=(?:")?((?:[htt]|[//]).+?)\s+'''
            if link:
                new_link = re.findall(regex_refresh, link, re.IGNORECASE | re.DOTALL)
                if new_link:
                    content = fetchData(new_link[0])
                    new_content = re.findall(regex_lnk, content, re.IGNORECASE | re.DOTALL)
                    for host, link1 in get_links(new_content):
                        lists.append((host,link1,'','play', info, url))
                    
        elif meniu == 'genuri':
            link = fetchData(url)
            regex_cats = '''"cat-item.+?href=['"](.+?)['"].+?>(.+?)<'''
            if link:
                match = re.compile(regex_cats, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
                if len(match) >= 0:
                    for legatura, nume in sorted(match, key=self.getKey):
                        lists.append((nume,legatura,'','recente', info))
        return lists
              
