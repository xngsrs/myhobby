# -*- coding: utf-8 -*-
import datetime
import os
import re
import urllib
import urllib2
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try: import HTMLParser as htmlparser
except: import html.parser as htmlparser
from resources.functions import *

base_url = 'http://www.asiafaninfo.net'
    
class asiafaninfo:
    
    media = sys.modules["__main__"].__media__
    thumb = media + "/asiafaninfo.jpg"
    nextimage = media + "/next.png"
    searchimage = media + "/search.png"
    name = 'AsiaFanInfo.net'
    menu = [('Recente', base_url, 'recente', thumb), 
            ('Categorii', base_url, 'genuri', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
                

    def cauta(self, keyword, result):
        result.append((self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'by_genre')))
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + urllib.quote_plus(keyword)
        return url

    def parse_menu(self, url, meniu, info={}):
        lists = []
        if meniu == 'recente':
            link = fetchData(url)
            regex = '''<li>(?:<strong>)?<a href=['"](.+?)['"].+?>(.+?)</li'''
            match = re.findall(regex, link, re.IGNORECASE | re.DOTALL)
            if len(match) > 0:
                for legatura, nume in match:
                    nume = htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')
                    info = {'Title': nume,'Plot': nume,'Poster': self.thumb}
                    lists.append((nume,legatura,'','get_links', info))
        elif meniu == 'get_links':
            link = fetchData(url)
            nume = ''
            regex_lnk = '''(?:((?:episodul|partea|sursa)[\s]\d+).+?)?<iframe.+?src=['"]((?:[htt]|[//]).+?)["']'''
            regex_seriale = '''(?:<h3>.+?strong>(.+?)<.+?href=['"](.+?)['"].+?)'''
            regex_infos = '''detay-a.+?description">(.+?)</div'''
            match_lnk = re.findall(regex_lnk, link, re.IGNORECASE | re.DOTALL)
            match_srl = re.compile(regex_seriale, re.IGNORECASE | re.DOTALL).findall(link)
            match_nfo = re.compile(regex_infos, re.IGNORECASE | re.DOTALL).findall(link)
            for nume, link1 in match_lnk:
                if nume: nume = htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')
                if link1.startswith("//"):
                    link1 = 'http:' + link1 #//ok.ru fix
                if 'goo.gl' in link1:
                    try:
                        a = urllib2.urlopen(link1)
                        link1 = a.geturl()
                    except: pass
                parsed_url1 = urlparse.urlparse(link1)
                if parsed_url1.scheme:
                    try: import urlresolver
                    except: pass
                    hmf = urlresolver.HostedMediaFile(url=link1, include_disabled=True, include_universal=True)
                    if hmf.valid_url() == True:
                        host = link1.split('/')[2].replace('www.', '').capitalize()
                        info = eval(str(info))
                        if len(match_nfo) > 0:
                            info['Plot'] = (striphtml(match_nfo[0]).strip())
                        lists.append(('%s %s' % (nume if nume else '', host),link1,'','play', info))#addLink(host, link1, thumb, name, 10, striphtml(match_nfo[0]))
        elif meniu == 'by_genre' or meniu == 'cauta':
            if meniu == 'cauta':
                keyboard = xbmc.Keyboard('')
                keyboard.doModal()
                if (keyboard.isConfirmed() == False): return
                search_string = keyboard.getText()
                if len(search_string) == 0: return
                url = self.get_search_url(search_string)
                link = fetchData(url)
                meniu = 'by_genre'
            else: link = fetchData(url)
            regex_all = '''id="post-(.+?)(?:</div>){2}'''
            r_link = '''href=['"](.+?)['"].+?title.+?categ'''
            r_name = '''title.+?per.+?>(.+?)<.+?categ'''
            r_genre = '''category tag">(.+?)<'''
            r_autor = '''author">(.+?)<'''
            r_image = '''author".+?src="(.+?)"'''
            if link:
                match = re.findall(regex_all, link, re.IGNORECASE | re.DOTALL)
                for movie in match:
                    legatura = re.findall(r_link, movie, re.IGNORECASE | re.DOTALL)
                    if legatura:
                        legatura = legatura[0]
                        nume = re.findall(r_name, movie, re.IGNORECASE | re.DOTALL)[0]
                        gen = [', '.join(re.findall(r_genre, movie, re.IGNORECASE | re.DOTALL))]
                        autor = re.findall(r_autor, movie, re.IGNORECASE | re.DOTALL)[0]
                        imagine = re.findall(r_image, movie, re.IGNORECASE | re.DOTALL)[0]
                        nume = htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8').strip()
                        info = {'Title': nume,'Plot': '%s \nTraducator: %s' % (nume, autor),'Poster': imagine, 'Genre': gen}
                        lists.append((nume, legatura, imagine, 'get_links', info))
                match = re.compile('"post-nav', re.IGNORECASE).findall(link)
                if len(match) > 0:
                    if '/page/' in url:
                        new = re.compile('/page/(\d+)').findall(url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        if '/?s=' in url:
                            nextpage = re.compile('\?s=(.+?)$').findall(url)
                            nexturl = '%s/page/2/?s=%s' % (base_url, nextpage[0])
                        else: 
                            nexturl = '%s%s' % (url, 'page/2/' if str(url).endswith('/') else '/page/2/')
                    lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'genuri':
            link = fetchData(url)
            regex_cat = '''class="cat-item.+?href=['"](.+?)['"][\s]?>(.+?)<'''
            if link:
                match = re.findall(regex_cat, link, re.IGNORECASE | re.DOTALL)
                if len(match) > 0:
                    for legatura, nume in match:
                        lists.append((nume,legatura.replace('"', ''),'','by_genre', info))
        return lists
              
