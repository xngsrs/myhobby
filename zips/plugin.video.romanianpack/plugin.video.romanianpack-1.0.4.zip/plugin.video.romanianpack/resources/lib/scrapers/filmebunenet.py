# -*- coding: utf-8 -*-
import datetime
import os
import re
import urllib
import urllib2
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try: import HTMLParser as htmlparser
except: import html.parser as htmlparser
from resources.functions import *

base_url = 'http://www.filme-bune.net'

class filmebunenet:
    
    media = sys.modules["__main__"].__media__
    thumb = media + "/filmebunenet.jpg"
    nextimage = media + "/next.png"
    searchimage = media + "/search.png"
    name = 'Filme-Bune.net'
    menu = [('Recente', base_url, 'recente', thumb), 
            ('Genuri', base_url, 'genuri', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + urllib.quote_plus(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword, result):
        result.append((self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')))

    def parse_menu(self, url, meniu, info={}):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                keyboard = xbmc.Keyboard('')
                keyboard.doModal()
                if (keyboard.isConfirmed() == False):
                    return
                search_string = keyboard.getText()
                if len(search_string) == 0:
                    return
                link = fetchData(self.get_search_url(search_string))
                meniu = 'recente'
            else: link = fetchData(url)
            regex_menu = '''postdate">(?:.+?)(.+?class="post.+?)</div.+?</div'''
            regex_submenu = '''>([a-zA-Z0-9,\s]+)<.+?title".+?href=['"](.+?)['"].+?>(.+?)<.+?src=['"](.+?)['"].+?entry">(.+?)a></p'''
            if link:
                for movie in re.compile(regex_menu, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                    match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                    for data, legatura, nume, imagine, descriere in match:
                        nume = htmlparser.HTMLParser().unescape(nume.decode('utf-8')).encode('utf-8')
                        descriere = htmlparser.HTMLParser().unescape(striphtml(descriere).decode('utf-8')).encode('utf-8').strip()
                        descriere = "-".join(descriere.split("\n"))
                        info = {'Title': nume,'Plot': descriere,'Poster': imagine}
                        lists.append((nume, legatura, imagine, 'get_links', info))
                match = re.compile('"pagination"', re.IGNORECASE).findall(link)
                if len(match) > 0:
                    if '/page/' in url:
                        new = re.compile('/page/(\d+)').findall(url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        if '/?s=' in url:
                            nextpage = re.compile('\?s=(.+?)$').findall(url)
                            nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                        else: nexturl = url + "/page/2"
                    lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_links':
            link = fetchData(url)
            regex_lnk = '''<iframe.+?src="((?:[htt]|[//]).+?)"'''
            regex_infos = '''"description">(.+?)</'''
            match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
            match_nfo = re.compile(regex_infos, re.IGNORECASE | re.DOTALL).findall(link)
            for link1 in match_lnk:
                if link1.startswith("//"):
                    link1 = 'http:' + link1 #//ok.ru fix
                if 'goo.gl' in link1:
                    try:
                        a = urllib2.urlopen(link1)
                        link1 = a.geturl()
                    except: pass
                parsed_url1 = urlparse.urlparse(link1)
                if parsed_url1.scheme:
                    try: import urlresolver
                    except: pass
                    hmf = urlresolver.HostedMediaFile(url=link1, include_disabled=True, include_universal=True)
                    if hmf.valid_url() == True:
                        host = link1.split('/')[2].replace('www.', '').capitalize()
                        try:
                            info = eval(str(info))
                            info['Plot'] = (striphtml(match_nfo[0]).strip())
                        except: pass
                        lists.append((host,link1,'','play', info))#addLink(host, link1, thumb, name, 10, striphtml(match_nfo[0]))
        elif meniu == 'genuri':
            link = fetchData(url)
            regex_cats = '''"cat-item.+?href=['"](.+?)['"][\s*]>(.+?)<'''
            if link:
                match = re.compile(regex_cats, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
                if len(match) >= 0:
                    for legatura, nume in sorted(match, key=self.getKey):
                        lists.append((nume,legatura.replace('"', ''),'','recente', info))#addDir(nume, legatura.replace('"', ''), 6, movies_thumb, 'recente')
        return lists
              
