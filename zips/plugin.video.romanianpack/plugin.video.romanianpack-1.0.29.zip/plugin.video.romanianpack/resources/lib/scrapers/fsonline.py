# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'https://filmeseriale.online'

class fsonline:
    
    thumb = os.path.join(media, 'fsonline.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'FilmeSeriale.online'
    menu = [('Recente', base_url, 'recente', thumb),
            ('Genuri', base_url, 'genuri', thumb),
            ('Filme', base_url + '/filme/', 'recente', thumb),
            ('Seriale', base_url + '/seriale/', 'recente', thumb),
            ('Ultimele aparute', base_url + '/ultimele-aparute', 'recente', thumb),
            ('Ultimele episoade', base_url + '/ultimele-episoade', 'recente', thumb),
            ('Top vizionate', base_url + '/top-vizionate', 'recente', thumb),
            ('Top votate', base_url + '/top-votate', 'recente', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword, result):
        result.append((self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')))

    def parse_menu(self, url, meniu, info={}):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else: 
                link = fetchData(url, base_url+ '/')
                regex = '''class="item".+?href="(.+?)".+?src="(.+?)".+?title="(.+?)">(.+?)<.+?genero">(.+?)<'''
                if link:
                    match = re.findall(regex, link, re.DOTALL)
                    for legatura, imagine, numeep, numarep, numes in match:
                        numeep = htmlparser.HTMLParser().unescape(numeep.decode('utf-8')).encode('utf-8').strip()
                        numarep = htmlparser.HTMLParser().unescape(numarep.decode('utf-8')).encode('utf-8').strip()
                        numes = htmlparser.HTMLParser().unescape(numes.decode('utf-8')).encode('utf-8').strip()
                        imagine = imagine.strip()
                        if numeep == numarep:
                            fullname = numeep
                            info = {'Title': numeep,'Plot': numeep, 'Genre': numes, 'Poster': imagine}
                            if re.search('/serial/', legatura):
                                lists.append((fullname + ' - Serial', legatura, imagine, 'seriale', str(info)))
                            else:
                                lists.append((fullname, legatura, imagine, 'get_links', str(info)))
                        else:
                            try:
                                sez_ep = re.findall('(\d+)', numeep)
                                sezon = str('%02d' % int(sez_ep[0]))
                                episod = str('%02d' % int(sez_ep[1]))
                                info = {'Title': numarep,
                                    'TVshowtitle' : numarep,
                                    'Season' : sezon,
                                    'Episode': episod,
                                    'Plot': numarep + ' ' + numes + ' ' + numeep,
                                    'Poster': imagine}
                                fullname = '%s - S%sE%s %s' % (numarep, sezon, episod, numeep)
                                lists.append((fullname, legatura, imagine, 'get_links', str(info)))
                            except: pass
                    match = re.compile('"pagination', re.IGNORECASE).findall(link)
                    if len(match) > 0:
                        if '/page/' in url:
                            new = re.compile('/page/(\d+)').findall(url)
                            nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                        else:
                            if '/?s=' in url:
                                nextpage = re.compile('\?s=(.+?)$').findall(url)
                                nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                            else: nexturl = url + "/page/2"
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_links':
            from resources.lib import requests
            from resources.lib.requests.packages.urllib3.exceptions import InsecureRequestWarning
            requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
            s = requests.Session()
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0', 'Referer': base_url + '/'}
            cookies = {'go_through': '1'}
            t = s.get(url, headers=headers, cookies=cookies)
            link = t.content
            reg = '''<iframe(?:.+?)?src="((?:[htt]|[//]).+?)"'''
            regex_infos = '''"sinopsis">(.+?)</'''
            try:
                info = eval(str(info))
                info['Plot'] = (striphtml(re.findall(regex_infos, link)[0])).strip()
            except: pass
            match_lnk = re.findall(reg, link, re.IGNORECASE | re.DOTALL)
            for host, link1 in get_links(match_lnk):
                if re.search('youtube.com', host, flags=re.IGNORECASE):
                    lists.append(('Trailer youtube',link1,'','play', info, url))
                else:
                    lists.append((host,link1,'','play', info, url))
        elif meniu == 'genuri':
            link = fetchData(url)
            regex = '''genuri.+?ul>(.+?)</ul'''
            regex_cats = '''href="(.+?)".+?i>(.+?)</i'''
            if link:
                for cats in re.findall(regex, link, re.DOTALL | re.IGNORECASE):
                    match = re.findall(regex_cats, cats, re.DOTALL)
                    if len(match) >= 0:
                        for legatura, nume in sorted(match, key=self.getKey):
                            lists.append((nume,legatura,'','recente', info))
        elif meniu == 'seriale':
            link = fetchData(url)
            #log('link: ' + str(link))
            regex = '''class="episode-title.+?href="(.+?)".+?title="(.+?)"'''
            match = re.findall(regex, link, re.DOTALL | re.IGNORECASE)
            jsinfod = eval(info)
            title = jsinfod.get('Title')
            for link, nume in match:
                jsinfo = jsinfod
                try:
                    date = re.findall('sezon.+?(\d+).+?episod.+?(\d+)', nume, re.IGNORECASE)
                    jsinfo['Season'] = date[0][0]
                    jsinfo['Episode'] = date[0][1]
                    jsinfo['Plot'] = '%s Sezon %s episod %s' % (title, date[0][0], date[0][1])
                    jsinfo['TVshowtitle'] = jsinfo.get('Title')
                except: pass
                lists.append((nume,link,'','get_links', json.dumps(jsinfo)))
        return lists
              
