# -*- coding: UTF-8 -*-
import re
import urllib2


def get_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False

def link(url):
    src = get_url(url)
    match = re.compile('<title>(.+?)<.+?file: "(.+?)".+?fileHD: (.+?)".+?fileUrlHD: "(.+?)"', re.IGNORECASE | re.DOTALL).findall(src)
    if match[0][1]:
        if match[0][2] == "\"1":
            return match[0][3]    
        else:
            return match[0][1]
    else:
        return False
