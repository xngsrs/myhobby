# -*- coding: utf-8 -*-
import datetime
import os
import re
import sys
import urllib
import urllib2
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import json

settings = xbmcaddon.Addon(id='plugin.video.rofilmedocumentare')
__addon__ = xbmcaddon.Addon()
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__cwd__        = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
__profile__    = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode("utf-8")
__resource__   = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'lib')).decode("utf-8")
__temp__       = xbmc.translatePath(os.path.join(__profile__, 'temp', '')).decode("utf-8")
search_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'search.png')
movies_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'movies.png')
next_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'next.png')
sys.path.append (__resource__)
import localdb
base_url = 'http://www.filmedocumentare.com'
try: 
    import urlresolver
except: pass

localdb.create_tables()

def ROOT():
    addDir('Cele mai recente', '%s/cele-mai-noi/' % base_url, 6, movies_thumb, 'recente')
    addDir('Cele mai vizionate', '%s/cele-mai-vizionate/' % base_url, 6, movies_thumb, 'recente')
    addDir('Cele mai votate', '%s/cele-mai-votate/' % base_url, 6, movies_thumb, 'recente')
    addDir('Cele mai comentate', '%s/cele-mai-comentate/' % base_url, 6, movies_thumb, 'recente')
    addDir('Categorii', '%s' % base_url, 6, movies_thumb, 'categorii')
    addDir('Favorite', base_url, 7, movies_thumb)
    addDir('Cautare', base_url, 3, movies_thumb)
    
def striphtml(data):
    p = re.compile('<.*?>')
    cleanp = re.sub(p, '', data)
    return cleanp
            
 
def video_list(url, name, iconimage=None, descriere=None):
    link = get_search(url)
    thumb = iconimage
    regex_lnk = '''(?:<h2.+?>(.+?)</.+?|)<iframe.+?src=['"]((?:[htt]|[//]).+?)['"]'''
    match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
    for title, link1 in match_lnk:
        if link1.startswith("//"):
            link1 = 'http:' + link1 #//ok.ru fix
        parsed_url1 = urlparse.urlparse(link1)
        if parsed_url1.scheme:
            hmf = urlresolver.HostedMediaFile(url=link1, include_disabled=True, include_universal=True)
            if hmf.valid_url() == True or 'trilulilu' in link1:
                host = '%s %s' % (link1.split('/')[2].replace('www.', '').capitalize(), title.replace('&#8211;', '-') if title else '')
                addLink(host, link1, thumb, name, 10, descriere)

            

def cauta(url):
    keyboard = xbmc.Keyboard('')
    keyboard.doModal()
    if (keyboard.isConfirmed() == False):
        return
    search_string = keyboard.getText()
    if len(search_string) == 0:
        return
    
    parse_menu(get_search_url(search_string), 'recente', 'filme')
    
def video_play(play_url, nume, imagine, descriere):
    if imagine:
        icon = imagine
        thumb = imagine
    else:
        icon = "DefaultFolder.png"
        thumb = movies_thumb
    liz = xbmcgui.ListItem(nume, iconImage=icon, thumbnailImage=thumb) 
    try: infos = json.loads(descriere); liz.setInfo(type="Video", infoLabels=infos)
    except: liz.setInfo(type="Video", infoLabels={"Title": nume, "Plot": descriere, "Poster": imagine})
    if 'trilulilu' in play_url:
        import trilulilu
        play_url = trilulilu.link(play_url)
    else:
        hmf = urlresolver.HostedMediaFile(url=play_url, include_disabled=True, include_universal=False)
        play_url = hmf.resolve()
    xbmc.Player().play(play_url, liz, False)
    
def get_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False
    
def get_search_url(keyword):
    url = base_url + '/?s=' + urllib.quote_plus(keyword)
    return url
  
def get_search(url):
    
    params = {}
    req = urllib2.Request(url, urllib.urlencode(params))
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Content-type', 'application/x-www-form-urlencoded')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False

def favorites(action, url, name, descriere, imagine):
    if action == "save":
        localdb.save_fav(url, name, descriere, imagine)
        #xbmc.executebuiltin("Container.Refresh")
    elif action == "check":
        check = localdb.get_fav(url)
        if check: return True
        else: return False
    elif action == "delete":
        localdb.del_fav(url)
    else:
        favs = localdb.get_fav()
        for fav in favs:
            info = fav[2].encode('utf-8')
            #with open(xbmc.translatePath(os.path.join('special://temp', 'files.py')), 'wb') as f: f.write(repr(info))
            addDir(fav[1].encode('utf-8'), fav[0].encode('utf-8'), 5, '%s' % (fav[3] if fav[3] else movies_thumb), descriere=info)

def reg(regex, content):
    try: result = re.compile(regex, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(content)
    except: result = False
    return result

def parse_menu(url, meniu, separare=None):
    link = get_url(url)
    if link:
        if meniu == 'recente':
            regex_all = '''<article(.+?)</article>'''
            t_l_i_d_regex = '''title=".+?">(.+?)<.+?href="(.+?)".+?<img src="(.+?)".+?v>(.+?)<'''
            views_regex = '''eye.+?i>(.+?)<'''
            rating_regex = '''gdr.+?>(.+?)<'''
            ro_regex = '''(filmul are)'''
            comm_regex = '''comm.+?i>(.+?)<'''
            tag_regex = '''href="(.+?)".+?tag">(.+?)<'''
            alltag_regex = '''tags(.+?)</div>'''
            cat_regex = '''film".+?href="(.+?)"'''
            
            for article in reg(regex_all, link):
                try: views = reg(views_regex, article)[0].strip()
                except: views = "0"
                title, links, image, description = reg(t_l_i_d_regex, article)[0]
                title = title.strip().replace('&#8211;', '-')
                rating = reg(rating_regex, article)
                ro = reg(ro_regex, article)
                try: comm = reg(comm_regex, article)[0].strip()
                except: comm = "0"
                all_tags = reg(alltag_regex, article)
                tags = reg(tag_regex, all_tags[0]) if len(all_tags) > 0 else []
                cat = reg(cat_regex, article)
                infos = {
                    'Title': title,
                    'Poster': image,
                    'Plot': description.strip(),
                    'Rating': '%s' % (rating[0]),
                    'Tagline': '%s vizionari si %s comentarii' % (views, comm),
                    'PlotOutline': '%s' % (description.strip())
                    }
                title  = '%s [COLOR yellow][RO][/COLOR]' % title if len(ro)> 0 else title
                infos = striphtml(json.dumps(infos)).replace("\n", "")
                addDir(title, links, 5, image, descriere=infos, tags=tags)
            try:
                match = re.compile('"pagination"|"paginador"', re.IGNORECASE).findall(link)
                if len(match) > 0:
                    if '/page/' in url:
                        new = re.compile('/page/(\d+)').findall(url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        if '/?s=' in url:
                            nextpage = re.compile('\?s=(.+?)$').findall(url)
                            nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                        else:
                            nexturl = '%s%s' % (url, ('page/2/' if str(url).endswith('/') else '/page/2/'))
                    addNext('Next', nexturl, 6, next_thumb, 'recente', separare)
            except: pass
        elif meniu == 'categorii':
            cats_regex = '''table-striped(.+?)</table'''
            cat_regex = '''href="(.+?)">(.+?)<'''
            for url, name in reg(cat_regex, reg(cats_regex, link)[0]):
                addDir(name, url, 6, movies_thumb, 'recente')

def playcount_movies(title,label, overlay):
	#metaget.get_meta('movie',title)
        localdb.update_watched(title,label,overlay)
	xbmc.executebuiltin("Container.Refresh")

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
                                
    return param

def addLink(name, url, iconimage, movie_name, mode=4, descriere=None):
    ok = True
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&imagine=" + urllib.quote_plus(iconimage) + "&nume=" + urllib.quote_plus(movie_name)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    if descriere != None:
        try: infos = json.loads(descriere); liz.setInfo(type="Video", infoLabels=infos)
        except: liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": descriere, "Poster": iconimage})
        u += "&descriere=" + urllib.quote_plus(descriere)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": movie_name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
    return ok

def addNext(name, page, mode, iconimage, meniu=None, descriere=None):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(page) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    if descriere != None:
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": descriere})
        u += "&descriere=" + urllib.quote_plus(descriere)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def addDir(name, url, mode, iconimage, meniu=None, descriere=None, tags=None):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&imagine=" + urllib.quote_plus(iconimage)
    ok = True
    context = []
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    if descriere != None:
        #with open(xbmc.translatePath(os.path.join('special://temp', 'files.py')), 'wb') as f: f.write(repr(descriere))
        try:
            infos = json.loads(descriere)
            playcount = 0
            playcount = localdb.get_watched(infos['Title'], name, '6')
            if playcount == '7': 
                context.append(('Marchează ca nevizionat', 'RunPlugin(%s?mode=11&url=%s&name=%s&watched=6&nume=%s)' %
                                (sys.argv[0],urllib.quote_plus(url),urllib.quote_plus(infos['Title'].encode('utf-8')),urllib.quote_plus(infos['Title'].encode('utf-8')))))
                infos.update({'playcount': 1, 'overlay': playcount})
            else: 
                context.append(('Marchează ca vizionat', 'RunPlugin(%s?mode=11&url=%s&name=%s&watched=7&nume=%s)' %
                                (sys.argv[0],urllib.quote_plus(url),urllib.quote_plus(infos['Title'].encode('utf-8')),urllib.quote_plus(infos['Title'].encode('utf-8')))))
            liz.setProperty('fanart_image',iconimage)
            liz.setInfo(type="Video", infoLabels=infos)
            if favorites("check", url, '', '', ''):
                context.append(('Șterge de la Favorite', 'RunPlugin(%s?mode=7&url=%s&action=delete)' %
                            (sys.argv[0],url)))
            else:
                context.append(('Salvează la Favorite', 'RunPlugin(%s?mode=7&url=%s&name=%s&descriere=%s&action=save&imagine=%s)' %
                            (sys.argv[0],urllib.quote_plus(url),urllib.quote_plus(infos['Title'].encode('utf-8')),urllib.quote_plus(descriere), urllib.quote_plus(iconimage))))
        except: liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": descriere, "Poster": iconimage})
        u += "&descriere=" + urllib.quote_plus(descriere)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name})
    #if tags and len(tags) > 0:
        #for tag_link, tag_name in tags:
            #context.append((tag_name, 'RunPlugin(%s?mode=6&url=%s&meniu=recente&descriere=reload)' %
                                #(sys.argv[0],urllib.quote_plus(tag_link))))
    liz.addContextMenuItems(context, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

params = get_params()

try:
    url = urllib.unquote_plus(params["url"])
except:
    url = None
try:
    imagine = urllib.unquote_plus(params["imagine"])
except:
    imagine = None
try:
    nume = urllib.unquote_plus(params["nume"])
except:
    nume = None
try:
    name = urllib.unquote_plus(params["name"])
except:
    name = None
try:
    descriere = urllib.unquote_plus(params["descriere"])
except:
    descriere = None
try:
    mode = int(params["mode"])
except:
    mode = None
try:
    meniu = urllib.unquote_plus(params["meniu"])
except:
    meniu = None
try:
    watched = urllib.unquote_plus(params["watched"])
except:
    watched = None
try:
    action = urllib.unquote_plus(params["action"])
except:
    action = None

if mode == None or url == None or len(url) < 1:
    ROOT()
        
elif mode == 3:
    cauta(url)
        
elif mode == 5:
    video_list(url, name, imagine, descriere)
        
elif mode == 6:
    parse_menu(url, meniu, descriere)

elif mode == 7:
    favorites(action, url, name, descriere, imagine)

elif mode == 4:
    VIDEO(url, name)

elif mode == 10:
    video_play(url, nume, imagine, descriere)
    
elif mode == 11:
    playcount_movies(name, nume, watched)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
