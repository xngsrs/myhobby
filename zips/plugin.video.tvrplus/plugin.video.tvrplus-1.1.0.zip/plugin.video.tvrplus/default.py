# -*- coding: utf-8 -*-
import os
import re
import sys
import urllib
import urllib2
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try: import HTMLParser as htmlparser
except: import html.parser as htmlparser


website = 'http://www.tvrplus.ro'

settings = xbmcaddon.Addon(id='plugin.video.tvrplus')

search_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'search.png')
movies_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'movies.png')
next_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'next.png')


def ROOT():
    addDir('Emisiuni TVR1', '%s/emisiuni-tvr-1-1' % website, 23, movies_thumb, 'emisiuni')
    addDir('Emisiuni TVR2', '%s/emisiuni-tvr-2-2' % website, 23, movies_thumb, 'emisiuni')
    addDir('Emisiuni TVR3', '%s/emisiuni-tvr-3-5' % website, 23, movies_thumb, 'emisiuni')
    addDir('Emisiuni TVR Internațional', '%s/emisiuni-tvr-international-3' % website, 23, movies_thumb, 'emisiuni')
    addDir('Toate Emisiunile', '%s/emisiuni' % website, 23, movies_thumb, 'emisiuni')
    addDir('Tematici emisiuni', '%s/emisiuni' % website, 23, movies_thumb, 'tematici')
    addDir('Live', 'http://www.tvrplus.ro/live-tvr-1', 23, movies_thumb, 'live')
    addDir('Cauta', 'http://nobalance.tvrplus.ro', 3, search_thumb)
         

def CAUTA(url, autoSearch=None):
    keyboard = xbmc.Keyboard('')
    keyboard.doModal()
    if (keyboard.isConfirmed() == False):
        return
    search_string = keyboard.getText()
    if len(search_string) == 0:
        return
        
    if autoSearch is None:
        autoSearch = ""
    
    parse_menu(get_search_url(search_string), 'search', urllib.quote_plus(search_string))

def striphtml(data):
        p = re.compile('<.*?>')
        cleanp = re.sub(p, '', data)
        return cleanp

def SXVIDEO_GENERIC_PLAY(sxurl, name, image):
    link = get_search(sxurl)
    match = re.compile('file: "http://(.+?)"', re.IGNORECASE | re.MULTILINE).findall(link)
    match2 = re.compile('<meta property="og:title" content="(.+?)".+?\n\s*.+?content="(.+?)"', re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
    if len(match) > 0:
        if len(match2) > 0:
            #var player_config.+?\n\s*.+?\n\s*"url": "(.+?)",(\n\s*.+?){15}url": "(.+?)",\n\s*.+?netConnectionUrl": \'(.+?)\'
            iconimage = "DefaultVideo.png"
            item = xbmcgui.ListItem(match2[0][0] + ' ' + name, iconImage=image, thumbnailImage=image)
            item.setInfo('video', {'Title': match2[0][0] + ' ' + name, 'Plot': match2[0][1]})
            item.setPath('http://' + match[0])
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
            return True
            #xbmc.Player().play('http://' + match[0], item)

    
def get_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False
    
def get_search_url(keyword, offset=None):
    url = 'http://nobalance.tvrplus.ro/cauta/cauta-ajax?termen=' + urllib.quote_plus(keyword)
    return url

def get_search(url):
    
    params = {}
    req = urllib2.Request(url, urllib.urlencode(params))
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Content-type', 'application/x-www-form-urlencoded')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
                                
    return param

def sxaddLink(name, url, iconimage, movie_name, mode=4, descript=None):
    ok = True
    u = '%s?url=%s&mode=%s&name=%s&imagine=%s' % (sys.argv[0],
                                                  urllib.quote_plus(url),
                                                  str(mode),
                                                  urllib.quote_plus(name),
                                                  urllib.quote_plus(iconimage))
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    if descript != None:
        liz.setInfo(type="Video", infoLabels={"Title": movie_name, "Plot": descript})
    else:
        liz.setInfo(type="Video", infoLabels={"Title": movie_name})
    liz.setProperty('isPlayable', 'true')
    liz.setProperty('resumetime', str(0))
    liz.setProperty('totaltime', str(1))
    #xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
    return ok

def addNext(name, page, mode, iconimage, meniu=None):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(page) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    #xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def addDir(name, url, mode, iconimage, meniu=None, descript=None):
    u = '%s?url=%s&mode=%s&name=%s' % (sys.argv[0], urllib.quote_plus(url), str(mode), urllib.quote_plus(name))
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    if descript != None:
        u += "&descriere=" + urllib.quote_plus(descript)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    if descript != None:
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": descript})
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok
      
def parse_menu(url, meniu, searchterm=None):
    dp = xbmcgui.DialogProgress()
    count = 0
    if url == None:
        url = website
    link = get_search(url)
    if meniu == 'emisiuni':
        match = re.findall('"emisiune.+?<p.+?>(.+?)<.+?<a href="(.+?)".+?data-original="(.+?)".+?ec">(.+?)<.+?<p>(.+?)<.+?<a href.+?">(.+?)<',
                           link,
                           re.IGNORECASE | re.DOTALL)
    elif meniu == 'emlink':
        match = re.findall('<li .+?\s<a href="(.+?)".+?alt="(.+?)".+?">(.+?)<', link, re.IGNORECASE | re.DOTALL)
    elif meniu == 'search':
        match = re.findall('<a.+? href="(.+?)".+?alt="(.+?)".+?<a.+?>(.+?)</a.+?<p.+?>(.+?)<.+?">(.+?)<', link, re.IGNORECASE | re.DOTALL)
    elif meniu == 'live':
        match = re.findall('<li class="floatL" s.+?<a href="(.+?)".+?src="(.+?)"', link, re.IGNORECASE | re.DOTALL)
    elif meniu == 'tematici':
        match = re.findall('"tematici"(.+?)</ul', link, re.IGNORECASE | re.DOTALL)
    if len(match) > 0:
        total = len(match)
        print match
        if meniu == 'emisiuni':
            dp.create('Încărcare', 'Încărcare %s emisiuni' % str(total))
            dp.update(1, "", str(count) + '%', "")
            for nume, legatura, imagine, posttv, data, descriere in match:
                if dp.iscanceled():
                    break
                linkem = website + legatura
                nume = htmlparser.HTMLParser().unescape(striphtml('%s - %s : %s' % (nume, posttv, data)).decode('utf-8')).encode('utf-8').strip()
                descriere = htmlparser.HTMLParser().unescape(striphtml('%s - %s\n%s' % (posttv,
                                                                                        data,
                                                                                        descriere)).decode('utf-8')).encode('utf-8').strip()
                addDir(nume, linkem, 23, imagine, 'emlink', descriere)
                count += 1
                percent = int((count * 100) / total)
                dp.update(percent, "", str(percent) + '%', "")
            dp.close()
        elif meniu == 'emlink':
            dp.create('Încărcare', 'Încărcare %s emisiuni' % str(total))
            dp.update(1, "", str(count) + '%', "")
            for linkem, imagine, nume in match:
                if dp.iscanceled():
                    break
                linkem = website + linkem
                sxaddLink(nume, linkem, imagine, nume, 10)
                count += 1
                percent = int((count * 100) / total)
                dp.update(percent, "", str(percent) + '%', "")
            dp.close()
        elif meniu == 'search':
            dp.create('Încărcare', 'Încărcare rezultate')
            dp.update(1, "", str(count) + '%', "")
            for legatura, imagine, titlu1, titlu2, descriere in match:
                if dp.iscanceled():
                    break
                nume = titlu1 + '-' + titlu2
                linkem = website + legatura
                sxaddLink(nume, linkem, imagine, nume, 10, descriere)
                count += 1
                percent = int((count * 100) / total)
                dp.update(percent, "", str(percent) + '%', "")
            dp.close()
        elif meniu == 'live':
            for legatura, imagine in match:
                nume = re.sub('/live', '', legatura)
                nume = re.sub('-', ' ', nume)
                linkem = website + legatura
                sxaddLink(nume.upper(), linkem, imagine, nume, 10)
            xbmcplugin.setContent(int(sys.argv[1]), 'musicvideos')
        elif meniu == 'tematici':
            for lista in match:
                tematici = re.findall('''li>.+?href=['"](.+?)['"]>(.+?)<''', lista, re.IGNORECASE | re.DOTALL)
                for legatura, titlu in tematici:
                    legatura = website + legatura
                    addDir(titlu, legatura, 23, movies_thumb, 'emisiuni')
	    
    match = re.findall('pagina/(\d)"', link, re.IGNORECASE | re.DOTALL)
    if len(match) > 0:
        page_num = re.findall('pagina/(.+?)\?', str(url), re.IGNORECASE)
        if len(page_num) > 0:
            pagen = int(page_num[0]) + 1
            nexturl = re.sub('pagina/(\d+)', 'pagina/' + str(pagen), url)
        else:
            nexturl = 'http://nobalance.tvrplus.ro/cauta/cauta-ajax/pagina/2?termen=' + str(searchterm)
        #f = open( '/storage/.kodi/temp/files.py', 'w' )
        #f.write( 'match = ' + repr(url) + '\n' )
        #f.close()  
        addNext('Next', nexturl, 23, next_thumb, 'search')
params = get_params()
try: url = urllib.unquote_plus(params["url"])
except: url = None
try: mode = int(params["mode"])
except: mode = None
try: meniu = urllib.unquote_plus(params["meniu"])
except: meniu = None
try: image = urllib.unquote_plus(params['imagine'])
except: image = None
try: name = urllib.unquote_plus(params['name'])
except: name = None

#print "Mode: "+str(mode)
#print "URL: "+str(url)
#print "Name: "+str(name)

if mode == None or url == None or len(url) < 1:
    ROOT()
        
elif mode == 3:
    CAUTA(url)
        
elif mode == 23:
    parse_menu(url, meniu)

elif mode == 10:
    SXVIDEO_GENERIC_PLAY(url, name, image)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
