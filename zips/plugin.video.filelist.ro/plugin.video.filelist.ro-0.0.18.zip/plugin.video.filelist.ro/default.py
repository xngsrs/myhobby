# -*- coding: utf-8 -*-

import control,client,cache
import urlparse,urllib,json,re,sys,os


class indexer:
    def __init__(self):
        self.list = []
        self.base_link = 'https://filelist.ro'
        self.detail_link = '/details.php?id=%s'
        self.login_link = '/takelogin.php'
        self.browse_link = '/browse.php'
        self.user = control.setting('filelist.user')
        self.password = control.setting('filelist.pass')
        self.metatype = control.setting('metatype')
        self.engine = '0'
        self.login_post = {'username': self.user, 'password': self.password, 'unlock': '1'}
        self.torrenter_addon = control.condVisibility('System.HasAddon(plugin.video.torrenter)')
        self.transmission_addon = control.condVisibility('System.HasAddon(service.downloadmanager.transmission)')
        self.quasar_addon = control.condVisibility('System.HasAddon(plugin.video.quasar)')


    def root(self):
        try:
            if (self.user == '' or self.password == ''):
                return control.execute('Addon.OpenSettings(%s)' % control.addonInfo('id'))

            self.list = [
            {
            'title': 30001,
            'action': 'search_dir',
            'url': 'http://filelist.ro/browse.php?page=0&search=%s&cat=0&searchin=1&sort=2',
            'image': '1000'
            },

            {
            'title': 30002,
            'url': 'http://filelist.ro/browse.php?cats[]=25&cats[]=20&cats[]=4&cats[]=19&cats[]=1&cats[]=21&cats[]=23&cats[]=14&cats[]=15&cats[]=24&cats[]=13&cats[]=6&cats[]=26&cats[]=27&page=0',
            'image': '1001'
            },

            {
            'title': 30014,
            'url': 'http://filelist.ro/browse.php?cats[]=6&page=0',
            'image': '6'
            },
            
            {
            'title': 30015,
            'url': 'http://filelist.ro/browse.php?cats[]=26&page=0',
            'image': '26'
            },
            
            {
            'title': 30003,
            'url': 'http://filelist.ro/browse.php?cats[]=25&page=0',
            'image': '25'
            },

            {
            'title': 30004,
            'url': 'http://filelist.ro/browse.php?cats[]=20&page=0',
            'image': '20'
            },

            {
            'title': 30005,
            'url': 'http://filelist.ro/browse.php?cats[]=4&page=0',
            'image': '4'
            },

            {
            'title': 30006,
            'url': 'http://filelist.ro/browse.php?cats[]=19&page=0',
            'image': '19'
            },

            {
            'title': 30007,
            'url': 'http://filelist.ro/browse.php?cats[]=1&page=0',
            'image': '1'
            },

            {
            'title': 30016,
            'url': 'http://filelist.ro/browse.php?cats[]=27&page=0',
            'image': '27'
            },
            
            {
            'title': 30008,
            'url': 'http://filelist.ro/browse.php?cats[]=21&page=0',
            'image': '21'
            },

            {
            'title': 30009,
            'url': 'http://filelist.ro/browse.php?cats[]=23&page=0',
            'image': '23'
            },

            {
            'title': 30011,
            'url': 'http://filelist.ro/browse.php?cats[]=24&page=0',
            'image': '24'
            },

            {
            'title': 30012,
            'url': 'http://filelist.ro/browse.php?cats[]=15&page=0',
            'image': '15'
            },

            {
            'title': 30013,
            'url': 'http://filelist.ro/browse.php?cats[]=13&page=0',
            'image': '13'
            }]

            self.addDirectory(self.list)
            return self.list
        except:
            pass


    def get(self, url):
        try:
            if (self.user == '' or self.password == ''):
                return control.execute('Addon.OpenSettings(%s)' % control.addonInfo('id'))

            self.list = self.filelist_list(url)
            self.addDirectory(self.list, content='files')
            return self.list
        except: pass

    def search(self, url, word=None):
        try:
            if word:
                cache.save_search(urllib.unquote_plus(word))
                url = url % word

                self.list = self.filelist_list(url)
                self.addDirectory(self.list, content='files')
                return self.list
            else:
                if (self.user == '' or self.password == ''):
                    return control.execute('Addon.OpenSettings(%s)' % control.addonInfo('id'))

                t = control.infoLabel('listitem.label')
                k = control.keyboard('', t) ; k.doModal()
                query = k.getText() if k.isConfirmed() else None

                if (query == None or query == ''): return
            
                cache.save_search(query)
                
                url = url % urllib.quote_plus(query)

                self.list = self.filelist_list(url)
                self.addDirectory(self.list, content='files')
                return self.list
        except:
            pass
    
    def search_dir(self, url, switch=None, word=None):
        if switch == "sterge":
            cache.del_search(word)
        elif switch == "edit":
            k = control.keyboard(word, word) ; k.doModal()
            query = k.getText() if k.isConfirmed() else None
            if (query == None or query == ''): return
            cache.save_search(query)
            control.execute("Container.Refresh")
        else:
            cautari = cache.get_search()
            if cautari:
                self.list.append({'title': 'Căutare Nouă', 'action': 'search', 'url': url, 'image': '1000'})
                for cautare in cautari[::-1]:
                    self.list.append({'action': 'search',
                                        'title': cautare[0],
                                    'url': url,
                                    'word': cautare[0],
                                    'image': '1000'})
                self.addDirectory(self.list, content='files')
            else: self.search(url)


    def play(self, url, engine, openonly=None, token=None):
        try:
            cookie = client.source(urlparse.urljoin(self.base_link, self.login_link), post=urllib.urlencode(self.login_post), output='cookie')

            url = urlparse.urljoin(self.base_link, self.detail_link % url)
            result = client.source(url, cookie=cookie)
            url = re.findall('(?:\'|\")(download.+?)(?:\'|\")', result)

            for url in url:
                if token:
                    if '&usetoken=1' in url:
                        url = url
                        break
                    else: url = url
                else:
                    if not '&usetoken=1' in url:
                        url = url
                        break
            tmp_torr = os.path.join(control.dataPath, 'temp.torrent')
            control.deleteFile(tmp_torr)
            #import xbmc
            #xbmc.log("### : %s" % (url), level=xbmc.LOGNOTICE )
            #import sys
            #sys.exit()
            url = client.source(self.base_link + '/' + url, cookie=cookie)
            with open(tmp_torr, 'wb') as f: f.write(url)
            url = urllib.quote_plus(url)
            if openonly:
                if openonly == 'transmission':
                    url = 'plugin://plugin.video.torrenter/?action=downloadFilesList&url=%s' % tmp_torr
                    control.execute('XBMC.Container.Update(%s)' % url)
                elif openonly == 'view':
                    url = 'plugin://plugin.video.torrenter/?action=torrentPlayer&url=%s' % tmp_torr
                    control.execute('XBMC.Container.Update(%s)' % url)
            else:
                if engine == None:
                    if self.engine == '0' and self.torrenter_addon:
                        engine = 'torrenter'
                    else:
                        engine = None
                if 'Filme Blu-Ray' in result or 'Filme 4K Blu-Ray' in result:
                    url = 'plugin://plugin.video.torrenter/?action=torrentPlayer&url=%s' % tmp_torr
                    control.execute('XBMC.ActivateWindow(Videos,%s)' % url)
                    control.execute('Dialog.Close(all, true)')
                else:
                    url = 'plugin://plugin.video.torrenter/?action=playSTRM&url=%s&not_download_only=True' % tmp_torr
                    control.execute('PlayMedia(%s)' % url)
                    control.execute('Dialog.Close(all, true)')
        except:
            pass


    def filelist_list(self, url):
        try:
            cookie = client.source(urlparse.urljoin(self.base_link, self.login_link), post=urllib.urlencode(self.login_post), output='cookie')

            result = client.source(url, cookie=cookie)

            items = client.parseDOM(result, 'div', attrs = {'class': 'torrentrow'})
        except:
            return
        try:
            next = client.parseDOM(result, 'div', attrs = {'class': 'pager'})[-1]
            next = re.findall('(<a .+?</a>)', next)
            next = [(client.parseDOM(i, 'a', ret='href'), client.parseDOM(i, 'a')) for i in next]
            next = [(i[0][0], i[1][0]) for i in next if len(i[0]) > 0 and len(i[1]) > 0]
            next = [i[0] for i in next if 'raquo' in i[1]][-1]
            next = urlparse.urljoin(self.base_link, self.browse_link) + next
            next = client.replaceHTMLCodes(next)
            next = next.encode('utf-8')
        except:
            next = ''

        for item in items:
            try:
                seed = client.parseDOM(item, 'div', attrs = {'class': 'torrenttable'})[:-2][-1]
                seed = client.parseDOM(seed, 'span')[0]
                try: seed = client.parseDOM(seed, 'font')[0]
                except: pass
                try: seed = client.parseDOM(seed, 'b')[0]
                except: pass

                leech = client.parseDOM(item, 'div', attrs = {'class': 'torrenttable'})[:-1][-1]
                leech = client.parseDOM(leech, 'span')[0]
                try: leech = client.parseDOM(leech, 'font')[0]
                except: pass
                try: leech = client.parseDOM(leech, 'b')[0]
                except: pass

                size = client.parseDOM(item, 'div', attrs = {'class': 'torrenttable'})[:-4][-1]
                size = client.parseDOM(size, 'span')[0]
                try: size = client.parseDOM(size, 'font')[0]
                except: pass
                size = re.sub('<.+?>|</.+?>', ' ', size)

                date = '0'
                try: premiered = re.findall('(\d*/\d*/\d{4})', item)[0]
                except: pass

                cat = client.parseDOM(item, 'div', attrs = {'class': 'torrenttable'})[0]
                cat = re.findall('cat=(\d*)', cat)[0]
                
                if not cat in ['25', '20', '4', '19', '1', '21', '23', '14', '24', '15', '13', '6', '26', '27', '12']: raise Exception()

                url = client.parseDOM(item, 'div', attrs = {'class': 'torrenttable'})[1]
                url = re.findall('id=(\d*)', url)[0]
                name = re.findall('<b>(.+?)</b>', item)[0]


                title = name
                title += ' [COLOR yellow][%s / %s][/COLOR]' % (seed, leech)
                if 'freeleech.png' in item: title += ' [COLOR green][FREE][/COLOR]'
                title += ' [COLOR red][%s][/COLOR]' % size
                title = client.replaceHTMLCodes(title)
                title = title.encode('utf-8')

                plot = name
                plot += '\nS: %s / L: %s' % (seed, leech)
                if 'freeleech.png' in item: plot += '  [FREE]'
                if not date == '0': plot += '\n%s' % date
                plot += '\n%s' % size
                plot = client.replaceHTMLCodes(plot)
                plot = plot.encode('utf-8')

                genre = '\n%s' % plot

                image = cat
                try: poster = re.findall("img src='(http.+?)'", item)[0]
                except: poster = image
                meta = {'Title': title, 'overview': plot, 'Genre': genre, 'Poster': poster}
                
                if cat in ['25', '20', '4', '19', '1', '6', '26']:

                    t, y = xbmc.getCleanMovieTitle(name)
                    t = t.encode('utf-8')

                    u = 'http://api.themoviedb.org/3/search/movie?api_key=%s&query=%s&year=%s' % (client.tmdb_key(), urllib.quote_plus(t), y)# if self.metatype == "1" else 'http://www.omdbapi.com/?t=%s&y=%s&apikey=%s' % (urllib.quote_plus(t), y, client.omdb_key())
                    def moviemeta(url): return client.request(url, timeout='10')
                    meta = cache.get(moviemeta, 720, u)
                    meta = json.loads(meta)


                elif cat in ['21', '23', '27']:

                    t = re.sub('[\.|\(|\[|\s](\d{4}|UK|US|AU)[\.|\(|\[|\s]', '.', name)
                    t = re.sub('(\.|\(|\[|\s)(S\d*E\d*|S\d+)(\.|\)|\]|\s|)(.+|)', '', t)
                    t = re.sub('\.|\:|\-|\(|\)|\[|\]|IMAX|Re-Seed', ' ', t).strip()
                    t = client.replaceHTMLCodes(t)
                    t = t.encode('utf-8')
                    #t, y = xbmc.getCleanMovieTitle(name)

                    u = 'http://api.themoviedb.org/3/search/tv?api_key=%s&query=%s' % (client.tmdb_key(), urllib.quote_plus(t)) if self.metatype == "1" else 'http://www.omdbapi.com/?t=%s&apikey=%s' % (urllib.quote_plus(t), client.omdb_key())
                    def tvmeta(url): return client.request(url, timeout='10')
                    meta = cache.get(tvmeta, 720, u)
                    meta = json.loads(meta)
                try: meta = meta['results'][0]
                except: meta = meta
                
                try: originaltitle = meta['Title']
                except: originaltitle = title
                originaltitle = client.replaceHTMLCodes(originaltitle)
                originaltitle = originaltitle.encode('utf-8')
                
                try: 
                    if not poster.startswith('http'): 
                        if meta['Poster'].startswith('http'):
                            poster = meta['Poster']
                            if poster == None or poster == '' or poster == 'N/A': poster = '0'
                        else: poster = '0'
                            #if not ('_SX' in poster or '_SY' in poster): poster = '0'
                    poster = re.sub('_SX\d*|_SY\d*|_CR\d+?,\d+?,\d+?,\d*','_SX500', poster)
                except:
                    try:
                        if meta['poster_path'] == None or meta['poster_path'] == '' or meta['poster_path'] == 'N/A': poster = '0'
                        else: poster = 'http://image.tmdb.org/t/p/w500/%s' % meta['poster_path']
                    except: poster = '0'
                poster = poster.encode('utf-8')

                try:
                    image = 'http://image.tmdb.org/t/p/original/%s' % meta['backdrop_path']
                    #thumb = 'http://image.tmdb.org/t/p/original/%s' % meta['backdrop_path']
                except: image = image

                try: 
                    year = meta['Year']
                    year = re.sub('[^0-9]', '', str(year))
                except:
                    try:
                        year = str(re.search('\d{4}', meta['release_date']).group(0))
                    except:
                        year = '0'
                year = year.encode('utf-8')

                try: imdb = meta['imdbID']
                except: imdb = '0'
                if imdb == None or imdb == '' or imdb == 'N/A': imdb = '0'
                imdb = imdb.encode('utf-8')

                try: 
                    premiered = meta['Released']
                    if premiered == None or premiered == '' or premiered == 'N/A': premiered = '0'
                    premiered = re.findall('(\d*) (.+?) (\d*)', premiered)
                    try: premiered = '%s-%s-%s' % (premiered[0][2], {'Jan':'01', 'Feb':'02', 'Mar':'03', 'Apr':'04', 'May':'05', 'Jun':'06', 'Jul':'07', 'Aug':'08', 'Sep':'09', 'Oct':'10', 'Nov':'11', 'Dec':'12'}[premiered[0][1]], premiered[0][0])
                    except: premiered = '0'
                except:
                    try: premiered = meta['release_date']
                    except: premiered = '0'
                premiered = premiered.encode('utf-8')

                try: duration = meta['Runtime']
                except: duration = '0'
                if duration == None or duration == '' or duration == 'N/A': duration = '0'
                duration = re.sub('[^0-9]', '', str(duration))
                duration = duration.encode('utf-8')

                try: 
                    rating = meta['imdbRating']
                    if rating == None or rating == '' or rating == 'N/A' or rating == '0.0': rating = '0'
                except:
                    try:
                        rating = str(meta['vote_average'])
                    except:
                        rating = '0'
                rating = rating.encode('utf-8')

                try: 
                    votes = meta['imdbVotes']
                    try: votes = str(format(int(votes),',d'))
                    except: pass
                    if votes == None or votes == '' or votes == 'N/A': votes = '0'
                except: 
                    try:
                        votes = str(meta['vote_count'])
                    except:
                        votes = '0'
                votes = votes.encode('utf-8')

                try:
                    if 'genre_ids' in meta:
                        genre = ""
                        g = len(meta['genre_ids'])
                        h = 1
                        for i in meta['genre_ids']:
                            genre += '%s%s' % (self.get_genre(str(i)), (', ' if h < g else ""))
                            h += 1
                    else:
                        genre = meta['Genre']
                except:
                    genre = ""

                try: mpaa = meta['Rated']
                except: mpaa = '0'
                if mpaa == None or mpaa == '' or mpaa == 'N/A': mpaa = '0'
                mpaa = mpaa.encode('utf-8')

                try : plot = '%s...%s' % (plot, meta['Plot'])
                except:
                    try: plot = '%s...%s' % (plot, meta['overview'])
                    except: plot = plot
                
                try: plot_outline = meta['Plot']
                except: 
                    try: plot_outline = meta['overview']
                    except: plot_outline = ""
                
                try: director = meta['Director']
                except: director = '0'
                if director == None or director == '' or director == 'N/A': director = '0'
                director = director.replace(', ', ' / ')
                director = re.sub(r'\(.*?\)', '', director)
                director = ' '.join(director.split())
                director = director.encode('utf-8')

                try: writer = meta['Writer']
                except: writer = '0'
                if writer == None or writer == '' or writer == 'N/A': writer = '0'
                writer = writer.replace(', ', ' / ')
                writer = re.sub(r'\(.*?\)', '', writer)
                writer = ' '.join(writer.split())
                writer = writer.encode('utf-8')

                try: cast = meta['Actors']
                except: cast = '0'
                if cast == None or cast == '' or cast == 'N/A': cast = '0'
                cast = [x.strip() for x in cast.split(',') if not x == '']
                try: cast = [(x.encode('utf-8'), '') for x in cast]
                except: cast = []
                if cast == []: cast = '0'


                self.list.append({'title': title, 'originaltitle': originaltitle, 'year': year, 'url': url, 'premiered': premiered, 'duration': duration, 'rating': rating, 'votes': votes, 'mpaa': mpaa, 'director': director, 'writer': writer, 'cast': cast, 'plot': plot, 'PlotOutline': plot_outline, 'code': imdb, 'imdb': imdb, 'genre': genre, 'image': image, 'poster': poster, 'action': 'play', 'next': next})
            except: pass
    
        return self.list

    def get_genre(self, ids):
        self.genre = {"28": "Action",
                "12": "Adventure",
                "16": "Animation",
                "35": "Comedy",
                "80": "Crime",
                "99": "Documentary",
                "18": "Drama",
                "10751": "Family",
                "14": "Fantasy",
                "36": "History",
                "27": "Horror",
                "10402": "Music",
                "9648": "Mystery",
                "10749": "Romance",
                "878": "Science Fiction",
                "10770": "TV Movie",
                "53": "Thriller",
                "10752": "War",
                "37": "Western"
                }
        return self.genre[ids]
        
    def addDirectory(self, items, content=None):
        if items == None or len(items) == 0: return

        sysaddon = sys.argv[0]
        artPath = os.path.join(control.addonInfo('path'), 'resources', 'media')

        for i in items:
            try:
                try: title = control.lang(i['title']).encode('utf-8')
                except: title = i['title']

                info = True if 'poster' in i and not i['poster'] == '0' else False

                image = os.path.join(artPath, '%s-image.png' % i['image'])

                fanart = os.path.join(artPath, '%s-fanart.png' % i['image'])

                if info == True: image = fanart = i['poster']


                mode = i['action'] if 'action' in i else 'get'
                isFolder = True if not mode == 'play' else False

                url = '%s?action=%s' % (sysaddon, mode)
                try: url += '&url=%s' % urllib.quote_plus(i['url'])
                except: pass
                try: url += '&switch=%s' % urllib.quote_plus(i['switch'])
                except: pass
                try: url += '&word=%s' % urllib.quote_plus(i['word'])
                except: pass

                meta = dict((k,v) for k, v in i.iteritems() if not v == '0')
                try: meta.update({'duration': str(int(meta['duration']) * 60)})
                except: pass

                cm = []
                if info == True:
                    cm.append(('Information', 'Action(Info)'))

                if content == 'files' and self.torrenter_addon and not i.get('action') == 'search':
                    try: 
                        cm.append((control.lang(30055).encode('utf-8'), 'RunPlugin(%s?action=play&url=%s&engine=torrenter)' % (sysaddon, urllib.quote_plus(i['url']))))
                        cm.append(('Play cu FLToken în Torrenter', 'RunPlugin(%s?action=play&url=%s&engine=torrenter&token=yes)' % (sysaddon, urllib.quote_plus(i['url']))))
                        cm.append(('Vezi conținut în Torrenter', 'RunPlugin(%s?action=play&url=%s&engine=torrenter&openonly=view)' % (sysaddon, urllib.quote_plus(i['url']))))
                        cm.append(('Vezi conținut cu FLToken în Torrenter', 'RunPlugin(%s?action=play&url=%s&engine=torrenter&openonly=view&token=yes)' % (sysaddon, urllib.quote_plus(i['url']))))
                        if self.transmission_addon: 
                            cm.append(('Descarcă cu Transmission', 'RunPlugin(%s?action=play&url=%s&engine=torrenter&openonly=transmission)' % (sysaddon, urllib.quote_plus(i['url']))))
                            cm.append(('Descarcă cu FLToken în Transmission', 'RunPlugin(%s?action=play&url=%s&engine=torrenter&openonly=transmission&token=yes)' % (sysaddon, urllib.quote_plus(i['url']))))
                    except: pass
                if i.get('action') == 'search':
                    try: 
                        cm.append(('Șterge', 'RunPlugin(%s?action=search_dir&switch=sterge&word=%s)' % (sysaddon, urllib.quote_plus(i['word']))))
                        cm.append(('Edit', 'RunPlugin(%s?action=search_dir&switch=edit&word=%s)' % (sysaddon, urllib.quote_plus(i['word']))))
                    except: pass
                item = control.item(label=title, iconImage=image, thumbnailImage=image)

                try: item.setArt({'poster': image, 'tvshow.poster': image, 'season.poster': image, 'banner': image, 'tvshow.banner': image, 'season.banner': image})
                except: pass
                item.setInfo(type='Video', infoLabels = meta)
                item.addContextMenuItems(cm, replaceItems=False)
                item.setProperty('Fanart_Image', fanart)
                control.addItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=isFolder)
            except:
                pass

        try:
            url = items[0]['next']
            if url == '': raise Exception()
            url = '%s?action=get&url=%s' % (sysaddon, urllib.quote_plus(url))
            image = os.path.join(artPath, '%s-image.png' % items[0]['image'])
            fanart = os.path.join(artPath, '%s-fanart.png' % items[0]['image'])
            item = control.item(label='Next Page', iconImage=image, thumbnailImage=image)
            item.addContextMenuItems([], replaceItems=True)
            item.setProperty('Fanart_Image', fanart)
            control.addItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=True)
        except:
            pass


        viewDict = {'skin.estuary': 54, 'skin.confluence': 51, 'skin.dotsmart': 52}
        if not content == None: control.content(int(sys.argv[1]), content)
        control.directory(int(sys.argv[1]), cacheToDisc=True)

        for i in range(0, 200):
            if content == None: return
            if control.condVisibility('Container.Content(%s)' % content):
                try: return control.execute('Container.SetViewMode(%s)' % str(viewDict[control.skin]))
                except: return
            control.sleep(100)




params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))


try: action = params['action']
except: action = None
try: engine = params['engine']
except: engine = None
try: url = params['url']
except: url = None
try: switch = params['switch']
except: switch = None
try: word = params['word']
except: word = None
try: openonly = params['openonly']
except: openonly = None
try: token = params['token']
except: token = None

if action == None:
    indexer().root()

elif action == 'get':
    indexer().get(url)

elif action == 'search':
    indexer().search(url, word)

elif action == 'search_dir':
    indexer().search_dir(url, switch, word)

elif action == 'play':
    indexer().play(url, engine, openonly, token)


