import xbmcaddon


if __name__ == '__main__':
	_addon = xbmcaddon.Addon(id='script.module.torrent2http')
	_addon.openSettings()
