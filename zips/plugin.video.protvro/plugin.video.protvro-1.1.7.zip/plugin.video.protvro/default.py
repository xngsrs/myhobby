import os
import re
import sys
import urllib
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import time
import datetime


website = 'https://protvplus.ro'

__addon__ = xbmcaddon.Addon()
__cwd__        = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
__resource__   = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'lib')).decode("utf-8")
search_thumb   = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'media', 'search.png')).decode("utf-8")
movies_thumb   = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'media', 'movies.png')).decode("utf-8")
next_thumb   = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'media', 'next.png')).decode("utf-8")

sys.path.append (__resource__)
import requests
ua = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.80 Safari/537.36"
headers = {'User-Agent': ua, 'Host': 'protvplus.ro', 'Referer': '%s/portal/' % website}

def ROOT():
    addDir('Prima Pagina', '%s/page/home/' % website, 23, movies_thumb, 'primapagina')
    addDir('Emisiuni', '%s/page/all_shows/' % website, 23, movies_thumb, 'emisiuni')
    #addDir('Stirile ProTV', 'http://protvplus.ro/', 23, movies_thumb, 'stiri')
    addDir('Cauta', '%s/page/search/?term=' % website, 3, search_thumb)

def log(msg):
    try:
        xbmc.log("###Response: %s" % (msg), level=xbmc.LOGNOTICE )
    except UnicodeEncodeError:
        xbmc.log("###Response: %s" % (msg.encode("utf-8", "ignore")), level=xbmc.LOGNOTICE )
    except:
        xbmc.log("###Response: %s" % ('ERROR LOG'), level=xbmc.LOGNOTICE )

def CAUTA(url, autoSearch=None):
    keyboard = xbmc.Keyboard('')
    keyboard.doModal()
    if (keyboard.isConfirmed() == False):
        return
    search_string = keyboard.getText()
    if len(search_string) == 0:
        return
    
    parse_menu('%s%s' % (url, search_string), 'cautare')
    
def play_video(url, icon):
    s = requests.Session()
    dp = xbmcgui.DialogProgressBG()
    dp.create('ProTV', 'Starting...')
    try:
        dp.update(25, message='Starting...')
        response = s.get(url, headers=headers).json()
        referer = '%s/portal%s' % (website, response.get('head').get('page'))
        header = {'User-Agent': ua, 'Host': 'protvplus.ro', 'Referer': referer, 'SID': 'test_udid', 'Udid': 'test'}
        response = s.get('%s%s' % (website, response.get('head').get('media')), headers=header).json()
        header = {'User-Agent': ua, 'Host': 'avodencapi.protvplus.ro', 'Referer': referer}
        #cookie = {'SERVERID': 'web13.prd'}
        titlu = response.get('head').get('title')
        info = {"Title": titlu, "Plot": '%s %s' % (response.get('head').get('published_at'), response.get('head').get('description'))}
        #log(response)
        #requests.utils.add_dict_to_cookiejar(s.cookies, cookie)
        videourl = '%s?date_c=%s' % (response.get('media')[0].get('link'), str(int(time.time())))
        getvideo = s.get(videourl, headers=header).json()
        dp.update(50, message='Starting...')
        xbmc.sleep(2000)
        dp.update(90, message='Starting...')
        getvideo = s.get(videourl, headers=header).json()
        #log(getvideo)
        dp.update(100, message='Starting...')
        item = xbmcgui.ListItem(titlu, iconImage=icon, thumbnailImage=icon)
        item.setInfo(type='Video', infoLabels=info)
        dp.close()
        xbmc.Player().play(getvideo.get('manifest_url'), item)
    except: 
        dp.close()
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('ProTV', 'Video indisponibil')))

def get_search(url):
    header = {'User-Agent': ua,
        'Host': 'protvplus.ro'}
    try:
        response = requests.get(url, headers=header)
        link = response.text
        return link
    except:
        return False

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
                                
    return param

def sxaddLink(name, url, iconimage, movie_name, mode=4, descript=None):
    ok = True
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name.encode('utf-8')) + "&icon=" + urllib.quote_plus(iconimage.encode('utf-8'))
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.addContextMenuItems([('Watched/Unwatched', 'Action(ToggleWatched)')])
    if descript != None:
        liz.setInfo(type="Video", infoLabels={"Title": movie_name, "Plot": descript})
    else:
        liz.setInfo(type="Video", infoLabels={"Title": movie_name})
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok

def addNext(name, page, mode, iconimage, meniu=None):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(page) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def addDir(name, url, mode, iconimage, meniu=None, descript=None):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    if descript != None:
        u += "&descriere=" + urllib.quote_plus(descript)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    if descript != None:
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": descript})
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok
      
def parse_menu(url, meniu):
    if url == None:
        url = 'https://protvplus.ro/'
    response = requests.get(url, headers=headers).json()
    if meniu == 'emisiuni':
        for shows in response.get('content').get('areas'):
            if shows.get('items'):
                for show in shows.get('items'):
                    try:
                        titlu = show.get('title')
                        poster = show.get('poster') if show.get('poster') else movies_thumb
                        sid = show.get('id')
                        backdrop = show.get('backdrop')
                        legatura = '%s%s' % (website, show.get('target'))
                        addDir(titlu, legatura, 23, poster, 'episoade')
                    except: pass
    if meniu == 'episoade':
        for shows in response.get('content').get('areas'):
            if shows.get('title') == 'Episoade integrale' or not shows.get('title'):
                try:
                    for show in shows.get('items'):
                        titlu = show.get('title')
                        poster = show.get('poster') if show.get('poster') else movies_thumb
                        media = '%s%s' % (website, show.get('media'))
                        mid = show.get('mid')
                        link = '%s%s' % (website, show.get('link'))
                        sid = show.get('id')
                        pagina = show.get('page')
                        legatura = '%s%s' % (website, show.get('target'))
                        descriere = '%s %s ' % (show.get('published_at'), show.get('description') if show.get('description') else show.get('synopsis'))
                        sxaddLink(titlu, link, poster, titlu, 10, descript=descriere)
                except: pass
    if meniu == 'primapagina':
        for shows in response.get('content').get('areas'):
            try:
                for show in shows.get('items'):
                    titlu = show.get('title')
                    poster = show.get('poster') if show.get('poster') else movies_thumb
                    media = '%s%s' % (website, show.get('media'))
                    mid = show.get('mid')
                    link = '%s%s' % (website, show.get('link'))
                    sid = show.get('id')
                    pagina = show.get('page')
                    legatura = '%s%s' % (website, show.get('target'))
                    descriere = '%s %s ' % (show.get('published_at'), show.get('description') if show.get('description') else show.get('synopsis'))
                    sxaddLink(titlu, link, poster, titlu, 10, descript=descriere)
            except: pass
    if meniu == 'cautare':
        for shows in response.get('content').get('areas'):
            if (shows.get('title') == 'Episoade') or shows.get('title') == 'Clipuri':
                try:
                    for show in shows.get('items'):
                        titlu = show.get('title')
                        poster = show.get('poster') if show.get('poster') else movies_thumb
                        media = '%s%s' % (website, show.get('media'))
                        mid = show.get('mid')
                        link = '%s%s' % (website, show.get('link'))
                        sid = show.get('id')
                        pagina = show.get('page')
                        legatura = '%s%s' % (website, show.get('target'))
                        descriere = '%s %s ' % (show.get('published_at'), show.get('description') if show.get('description') else show.get('synopsis'))
                        sxaddLink(titlu, link, poster, titlu, 10, descript=descriere)
                except: pass
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')  
               
params = get_params()

try:
    url = urllib.unquote_plus(params["url"])
except:
    url = None
try:
    mode = int(params["mode"])
except:
    mode = None
try:
    meniu = urllib.unquote_plus(params["meniu"])
except:
    meniu = None
try:
    icon = urllib.unquote_plus(params["icon"])
except:
    icon = None


#print "Mode: "+str(mode)
#print "URL: "+str(url)
#print "Name: "+str(name)

if mode == None or url == None or len(url) < 1:
    ROOT()
        
elif mode == 3:
    CAUTA(url)
        
elif mode == 23:
    parse_menu(url, meniu)

elif mode == 10:
    play_video(url, icon)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
