import sys

from resources.cinemagia.cinemagia import Cinemagia

cm = Cinemagia()
cm.debug = True
cm.execute()

