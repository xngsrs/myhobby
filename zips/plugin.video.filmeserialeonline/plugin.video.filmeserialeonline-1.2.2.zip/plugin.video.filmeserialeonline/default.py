# -*- coding: utf-8 -*-
import datetime
import os
import re
import sys
import urllib
import urllib2
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import json
try: import HTMLParser as htmlparser
except: import html.parser as htmlparser

settings = xbmcaddon.Addon(id='plugin.video.filmeserialeonline')
__addon__ = xbmcaddon.Addon()
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__cwd__        = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
__profile__    = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode("utf-8")
__resource__   = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'lib')).decode("utf-8")
__temp__       = xbmc.translatePath(os.path.join(__profile__, 'temp', '')).decode("utf-8")
search_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'search.png')
movies_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'movies.png')
next_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'next.png')
sys.path.append (__resource__)
import localdb
base_url = 'http://filme-seriale.gratis'

localdb.create_tables()

def ROOT():
    addDir('Filme adăugate Recent', base_url, 6, movies_thumb, 'recente', 'filme')
    addDir('Filme după Gen', base_url, 6, movies_thumb, 'genuri', 'filme')
    addDir('Filme după Ani', base_url, 6, movies_thumb, 'ani', 'filme')
    addDir('Filme după Calitate', base_url, 6, movies_thumb, 'calitate', 'filme')
    addDir('Listă Seriale', 'http://filme-seriale.gratis/seriale-online', 6, movies_thumb, 'recente', 'seriale')
    addDir('Episoade adăugate Recent', 'http://filme-seriale.gratis/episod', 6, movies_thumb, 'recente', 'episoade')
    addDir('Seriale după Gen', base_url, 6, movies_thumb, 'genuri', 'seriale')
    addDir('Seriale după Ani', base_url, 6, movies_thumb, 'ani', 'seriale')
    addDir('Căutare', base_url, 8, movies_thumb)
    addDir('Favorite', base_url, 7, movies_thumb)
    
def striphtml(data):
    p = re.compile('<.*?>')
    cleanp = re.sub(p, '', data)
    return cleanp

def cauta_film(url):
    link = get_search(url)
                   
    regex_menu = '''<div class="eTitle"(.+?)</div></td></tr></table><br />'''
    regex_submenu = '''<a href="(.+?)".+?>(.+?)</a>'''
    for meniu in re.compile(regex_menu, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
        match = re.compile(regex_submenu, re.DOTALL).findall(meniu)
        for legatura, nume in match:
            addDir(striphtml(nume), legatura, 5, movies_thumb)

    match = re.compile('"swchItem"', re.IGNORECASE).findall(link)
    if len(match) > 0:
        new = re.compile('/\?q=.+?t=\d+;p=(\d+);md').findall(url)
        if new:
            nexturl = re.sub('p=\d+', 'p=' + (str(int(new[0]) + 1)), url)
        else:
            nexturl = url + ';t=0;p=2;md='
      
        print "NEXT " + nexturl
      
        addNext('Next', nexturl, 2, next_thumb)
            
 
def video_list(url, name, iconimage=None, descriere=None):
    link = get_search(url)
    thumb = iconimage
    regex_lnk = '''(?:"movieplay"|"player\d+").+?iframe.+?src="((?:[htt]|[//]).+?)"'''
    match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
    #with open(xbmc.translatePath(os.path.join('special://temp', 'files.py')), 'wb') as f: f.write(repr(match_lnk))
    for link1 in match_lnk:
            if link1.startswith("//"):
                link1 = 'http:' + link1 #//ok.ru fix
            if 'goo.gl' in link1:
                try:
                    a = urllib2.urlopen(link1)
                    link1 = a.geturl()
                except: pass
            parsed_url1 = urlparse.urlparse(link1)
            if parsed_url1.scheme:
                try: import urlresolver
                except: pass
                hmf = urlresolver.HostedMediaFile(url=link1, include_disabled=True, include_universal=True)
                if hmf.valid_url() == True:
                    host = link1.split('/')[2].replace('www.', '').capitalize()
                    addLink(host, link1, thumb, name, 10, descriere)

            
def cauta_dir(switch=None, word=None):
    if switch == "sterge":
        localdb.del_search(word)
    cautari = localdb.get_search()
    if cautari:
        addDir('Căutare Nouă', base_url, 3, movies_thumb)
        for cautare in cautari[::-1]:
            addDir(urllib.unquote_plus(cautare[0]), get_search_url(urllib.unquote_plus(cautare[0])), 6, search_thumb, 'recente', 'filme', "1")
    else: cauta()
    
def cauta():
    keyboard = xbmc.Keyboard('')
    keyboard.doModal()
    if (keyboard.isConfirmed() == False): return
    search_string = keyboard.getText()
    if len(search_string) == 0: return
    else: localdb.save_search(urllib.quote_plus(search_string))
    
    parse_menu(get_search_url(search_string), 'recente', 'filme')
    
def video_play(play_url, nume, imagine, descriere):
    if imagine:
        icon = imagine
        thumb = imagine
    else:
        icon = "DefaultFolder.png"
        thumb = movies_thumb
    liz = xbmcgui.ListItem(nume, iconImage=icon, thumbnailImage=thumb) 
    try: infos = json.loads(descriere); liz.setInfo(type="Video", infoLabels=infos)
    except: liz.setInfo(type="Video", infoLabels={"Title": nume, "Plot": descriere, "Poster": imagine})
    try: import urlresolver
    except: pass
    hmf = urlresolver.HostedMediaFile(url=play_url, include_disabled=True, include_universal=False) 
    xbmc.Player().play(hmf.resolve(), liz, False)
    
def get_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False
    
def get_search_url(keyword):
    url = base_url + '/?s=' + urllib.quote_plus(keyword)
    return url
  
def get_search(url):
    
    params = {}
    req = urllib2.Request(url, urllib.urlencode(params))
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Content-type', 'application/x-www-form-urlencoded')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False

def favorites(action, url, name, descriere, imagine):
    if action == "save":
        localdb.save_fav(url, name, descriere, imagine)
        #xbmc.executebuiltin("Container.Refresh")
    elif action == "check":
        check = localdb.get_fav(url)
        if check: return True
        else: return False
    elif action == "delete":
        localdb.del_fav(url)
    else:
        favs = localdb.get_fav()
        for fav in favs:
            try:
                info = fav[2].encode('utf-8')
                if 'serial' in fav[1].lower(): addDir(fav[1].encode('utf-8'), fav[0].encode('utf-8'), 6, '%s' % (fav[3] if fav[3] else movies_thumb), 'episoade', descriere=info)
                else: addDir(fav[1].encode('utf-8'), fav[0].encode('utf-8'), 5, '%s' % (fav[3] if fav[3] else movies_thumb), descriere=info)
            except: pass

def parse_menu(url, meniu, separare=None):
    link = get_url(url)
    if link:
        if meniu == 'recente':
            if separare and (separare == 'filme' or separare == 'seriale'):
                regex_all = '''<div id="mt-(.+?year">.+?</span>)(?:.+?<span class="calidad2">(.+?)</span>)?'''
                regex_info = '''src="(.+?)".+?boxinfo.+?href="(.+?)".+?"tt">(.+?)</.+?"ttx">(.+?)</.+?"year">(.+?)<'''
                regex_n_v = '''(?:IMDB|TMDb):(.+?)</s.+?type.+?>(.+?)<'''
                for bloc, tip in re.compile(regex_all, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                    match = re.compile(regex_info, re.DOTALL).findall(bloc)
                    voturi = re.findall(regex_n_v, bloc, re.IGNORECASE | re.DOTALL)
                    if voturi:
                        rating = striphtml(voturi[0][0]).split("/")[0].strip()
                        votes = striphtml(voturi[0][0]).split("/")[1].strip()
                        post = voturi[0][1]
                    else: rating = None; votes = None; post = ''
                    for imagine, legatura, nume, descriere, an in match:
                        imagine = imagine.strip()
                        try: imagine = re.findall('url=(.+?)$', imagine)[0]
                        except: pass
                        infos = {
                            'Title': nume,
                            'Poster': imagine,
                            'Plot': descriere.strip(),
                            'Year': an,
                            'Rating': '%s' % rating,
                            'Votes': '%s' % votes,
                            'PlotOutline': '%s' % (descriere.strip())
                            }
                        infos = striphtml(json.dumps(infos)).replace("\n", "")
                        nume = striphtml((nume + ' - ' + tip) if tip else nume)
                        if 'eri' in tip or 'epis' in post or '/seriale/' in legatura:
                            separare = 'seriale'
                        else:
                            separare = 'filme'
                        if separare == 'filme':
                            addDir(nume, legatura, 5, imagine, descriere=infos)
                        else:
                            addDir(nume, legatura, 6, imagine, 'episoade', infos)
            if separare and separare == 'episoade':
                regex_all = '''<td class="bb">.+?href=".+?>(.+?)<.+?href=".+?>(.+?)<.+?src="(.+?)".+?href="(.+?)".+?>(.+?)<.+?p>(.+?)</p.+?"dd"><center>(.+?)<.+?"ee"><center>(.+?)<.+?'''
                match = re.compile(regex_all, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
                for serial, e_pisod, imagine, legatura, nume, descriere, add_data, traducator in match:
                    imagine = imagine.strip()
                    try: imagine = re.findall('url=(.+?)$', imagine)[0]
                    except: pass
                    pisod = re.compile('sezonul-(\d+)?.+?episodul-(\d+)?', re.IGNORECASE | re.DOTALL).findall(e_pisod)
                    infos = {
                        'Title': '%s S%s-E%s %s' % (serial.strip(), pisod[0][0], pisod[0][1], nume.strip()),
                        'Poster': imagine,
                        'Plot': descriere.strip(),
                        'TVShowTitle': serial.strip(),
                        'Season': pisod[0][0],
                        'Episode': pisod[0][1]
                        }
                    name = '%s: %s : %s'% (serial.strip(), e_pisod, nume.strip())
                    infos = striphtml(json.dumps(infos))
                    addDir(striphtml(name), legatura, 5, imagine, descriere=infos)
            match = re.compile('"pagination"|"paginador"', re.IGNORECASE).findall(link)
            if len(match) > 0:
                if '/page/' in url:
                    new = re.compile('/page/(\d+)').findall(url)
                    nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                else:
                    nexturl = '%s%s' % (url, ('page/2' if str(url).endswith('/') else '/page/2'))
                addNext('Next', nexturl, 6, next_thumb, 'recente', separare)
        elif meniu == 'genuri':
            regex_cats = '''"categorias">(.+?)</div'''
            regex_cat = '''href="(.+?)"(?:\s)?>(.+?)<.+?n>(.+?)<'''
            gen = re.compile(regex_cats, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
            if separare and separare == 'filme':
                match = re.compile(regex_cat, re.DOTALL).findall(gen[0])
            elif separare and separare == 'seriale':
                match = re.compile(regex_cat, re.DOTALL).findall(gen[1])
            for legatura, nume, cantitate in match:
                addDir((nume + ' - ' + cantitate), legatura, 6, movies_thumb, 'recente', separare)
        elif meniu == 'ani':
            regex_cats = '''"filtro_y">.+?anul(.+?)</div'''
            regex_cat = '''href="(.+?)"(?:\s)?>(.+?)<.+?n>(.+?)<'''
            an = re.compile(regex_cats, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
            if separare and separare == 'filme':
                match = re.compile(regex_cat, re.DOTALL).findall(an[0])
            elif separare and separare == 'seriale':
                match = re.compile(regex_cat, re.DOTALL).findall(an[1])
            for legatura, nume, cantitate in match:
                addDir((nume + ' - ' + cantitate), legatura, 6, movies_thumb, 'recente', separare)
        elif meniu == 'calitate':
            regex_cats = '''"filtro_y">.+?calita(.+?)</div'''
            regex_cat = '''href="(.+?)"(?:\s)?>(.+?)<.+?n>(.+?)<'''
            for cat in re.compile(regex_cats, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                match = re.compile(regex_cat, re.DOTALL).findall(cat)
                for legatura, nume, cantitate in match:
                    addDir((nume + ' - ' + cantitate), legatura, 6, movies_thumb, 'recente', 'filme')
        elif meniu == 'episoade':
            regex_all = '''numerando">(\d+ x \d+)<.+?href="(.+?)">(.+?)<.+?date">(.+?)<'''
            episod = re.compile(regex_all, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
            for numero, legatura, nume, data in episod:
                ep_data = numero.split(' x ')
                infos = json.loads(separare)
                infos['TVShowTitle'] = infos['Title']
                infos['Title'] = '%s S%02dE%02d %s' % (infos['TVShowTitle'].encode('utf-8'), int(ep_data[0]), int(ep_data[1]), nume.strip())
                infos['Season'] = ep_data[0]
                infos['Episode'] = ep_data[1]
                infos = json.dumps(infos)
                addDir(striphtml(str(numero) + ' ' + nume + ' - ' + data).replace("\n", ""), legatura, 5, movies_thumb, descriere=infos)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def playcount_movies(title,label, overlay):
	#metaget.get_meta('movie',title)
        localdb.update_watched(title,label,overlay)
	xbmc.executebuiltin("Container.Refresh")

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
                                
    return param

def addLink(name, url, iconimage, movie_name, mode=4, descriere=None):
    ok = True
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&imagine=" + urllib.quote_plus(iconimage) + "&nume=" + urllib.quote_plus(movie_name)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    if descriere != None:
        try: infos = json.loads(descriere); liz.setInfo(type="Video", infoLabels=infos)
        except: liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": descriere, "Poster": iconimage})
        u += "&descriere=" + urllib.quote_plus(descriere)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": movie_name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
    return ok

def addNext(name, page, mode, iconimage, meniu=None, descriere=None):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(page) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    if descriere != None:
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": descriere})
        u += "&descriere=" + urllib.quote_plus(descriere)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def addDir(name, url, mode, iconimage, meniu=None, descriere=None, cautare=None):
    try: name = htmlparser.HTMLParser().unescape(name.decode('utf-8'))
    except: name = name
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name.encode('utf-8')) + "&imagine=" + urllib.quote_plus(iconimage)
    ok = True
    context = []
    if cautare:
        context.append(('Șterge din Căutări', 'RunPlugin(%s?mode=8&url=sterge&name=%s)' %
                                (sys.argv[0],urllib.quote_plus(name.encode('utf-8')))))
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    if descriere != None:
        #with open(xbmc.translatePath(os.path.join('special://temp', 'files.py')), 'wb') as f: f.write(repr(descriere))
        try:
            infos = json.loads(descriere)
            playcount = 0
            playcount = localdb.get_watched(infos['Title'], name, '6')
            if playcount == '7': 
                context.append(('Marchează ca nevizionat', 'RunPlugin(%s?mode=11&url=%s&name=%s&watched=6&nume=%s)' %
                                (sys.argv[0],url,urllib.quote_plus(infos['Title'].encode('utf-8')),urllib.quote_plus(infos['Title'].encode('utf-8')))))
                infos.update({'playcount': 1, 'overlay': playcount})
            else: 
                context.append(('Marchează ca vizionat', 'RunPlugin(%s?mode=11&url=%s&name=%s&watched=7&nume=%s)' %
                                (sys.argv[0],url,urllib.quote_plus(infos['Title'].encode('utf-8')),urllib.quote_plus(infos['Title'].encode('utf-8')))))
            liz.setProperty('fanart_image',iconimage)
            liz.setInfo(type="Video", infoLabels=infos)
            if favorites("check", url, '', '', ''):
                context.append(('Șterge de la Favorite', 'RunPlugin(%s?mode=7&url=%s&action=delete)' %
                            (sys.argv[0],url)))
            else:
                context.append(('Salvează la Favorite', 'RunPlugin(%s?mode=7&url=%s&name=%s&descriere=%s&action=save&imagine=%s)' %
                            (sys.argv[0],url,urllib.quote_plus(name.encode('utf-8')),urllib.quote_plus(descriere), urllib.quote_plus(iconimage))))
        except: liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": descriere, "Poster": iconimage})
        u += "&descriere=" + urllib.quote_plus(descriere)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.addContextMenuItems(context, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok
              
params = get_params()

try: url = urllib.unquote_plus(params["url"])
except: url = None
try: imagine = urllib.unquote_plus(params["imagine"])
except: imagine = None
try: nume = urllib.unquote_plus(params["nume"])
except: nume = None
try: name = urllib.unquote_plus(params["name"])
except: name = None
try: descriere = urllib.unquote_plus(params["descriere"])
except: descriere = None
try: mode = int(params["mode"])
except: mode = None
try: meniu = urllib.unquote_plus(params["meniu"])
except: meniu = None
try: watched = urllib.unquote_plus(params["watched"])
except: watched = None
try: action = urllib.unquote_plus(params["action"])
except: action = None

if mode == None or url == None or len(url) < 1: ROOT()
elif mode == 2: cauta_film(url)
elif mode == 3: cauta()
elif mode == 5: video_list(url, name, imagine, descriere)
elif mode == 6: parse_menu(url, meniu, descriere)
elif mode == 7: favorites(action, url, name, descriere, imagine)
elif mode == 4: VIDEO(url, name)
elif mode == 8: cauta_dir(url, name)
elif mode == 10: video_play(url, nume, imagine, descriere)
elif mode == 11: playcount_movies(name, nume, watched)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
