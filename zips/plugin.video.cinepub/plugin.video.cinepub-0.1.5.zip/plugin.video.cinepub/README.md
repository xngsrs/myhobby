# cinepub-kodi
KODI plug-in for cinepub.ro
