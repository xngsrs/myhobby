# -*- coding: utf-8 -*-
import json
import os
import re
import sys
import urllib
import urllib2
import xbmc
import xbmcaddon
import xbmcgui

__addon__ = xbmcaddon.Addon()
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')

__cwd__        = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
__profile__    = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode("utf-8")
__resource__   = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'lib')).decode("utf-8")
__temp__       = xbmc.translatePath(os.path.join(__profile__, 'temp', '')).decode("utf-8")

sys.path.append (__resource__)

import requests

class window(xbmcgui.WindowDialog):

    def get_n(self, url, name):
        #from metahandler import metahandlers
        #mg = metahandlers.MetaData()
        #with open('/storage/.kodi/temp/files.py', 'wb') as f: f.write(repr(name))
        raw = self.get_data(url)
        nume, an = xbmc.getCleanMovieTitle(name)
        #nume = nume.replace(" ", "+")
        nume = nume.replace('ț', 't').replace('ă', 'a')
        if raw:
            genuri = self.striphtml(re.compile('Categorie: (.+?)</div', re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(raw)[0]).strip().decode('utf-8')
            descriere = self.striphtml(re.compile('content_box">.+?p>(.+?)</p', re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(raw)[0])
            nota = re.compile('IMDB :(.+?)<', re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(raw)[0]
            poster = re.compile('"col-right".+?src="(.+?)"', re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(raw)[0]
        else:
            genuri = ''
            descriere = nume
            nota = ''
            poster = ''
        #nume = urllib.quote_plus(nume)
        #info_url = 'http://www.omdbapi.com/?t=%s&y=%s&plot=full&r=json' % (nume, an)
        #met = self.get_data(info_url)
        fundal = os.path.join(__cwd__, 'resources', 'media', 'ContentPanel.png')
        self.background = xbmcgui.ControlImage(180, 0, 1120, 720, fundal)
        self.addControl(self.background)
        
        self.fanart = xbmcgui.ControlImage(200, 100, 270, 380, poster, aspectRatio=2)
        self.addControl(self.fanart)
        
        #self.glassoverlay = xbmcgui.ControlImage(204, 104, 200, 230, 'GlassOverlay.png', aspectRatio=2)
        #self.addControl(self.glassoverlay)
        
        self.title = xbmcgui.ControlLabel(500, 40, 1030, 30, ('Titlu: %s' % nume))
        self.addControl(self.title)
        
        self.title = xbmcgui.ControlTextBox(210, 527, 1030, 120)
        self.addControl(self.title)
        self.title.setText('Plot: %s' % descriere)
       
        self.list = xbmcgui.ControlList (500, 90, 740, 390)
        self.addControl(self.list)
        
        self.list.addItem ("genre: %s" % genuri)
        self.list.addItem ("rating: %s" % nota)
        self.list.addItem ("year: %s" % an)
        #self.list.addItem ("director: %s" % meta['Director'])
        #self.list.addItem ("writer: %s" % meta['Writer'])
        #self.list.addItem ("cast: %s" % meta['Actors'])
        #self.list.addItem ("country: %s" % meta['Country'])
        #self.list.addItem ("language: %s" % meta['Language'])
        
    def get_data(self, url):
        params = {}
        req = urllib2.Request(url, urllib.urlencode(params))
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Content-type', 'application/x-www-form-urlencoded')
        try:
            response = urllib2.urlopen(req)
            link = response.read()
            response.close()
            return link
        except:
            return False

    def striphtml(self, data):
        p = re.compile(r'<.*?>')
        return p.sub('', data)
        
