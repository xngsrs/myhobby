﻿# -*- coding: UTF-8 -*-

import xbmcaddon
import xbmc
import os
try: from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
import hashlib
import time

__addon__ = xbmcaddon.Addon()
__scriptname__ = __addon__.getAddonInfo('name')
dataPath = xbmc.translatePath(__addon__.getAddonInfo("profile")).decode("utf-8")
addonCache = os.path.join(dataPath,'cache.db')
language = __addon__.getLocalizedString

def create_tables():
    try:
        import xbmcvfs
        if xbmcvfs.exists(dataPath) == 0: xbmcvfs.mkdir(dataPath)
    except BaseException as e: _log(u"localdb.create_tables makedir ##Error: %s" % str(e))
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS watched (""title TEXT, ""overlay TEXT, ""UNIQUE(title)"");")
        dbcur.execute("CREATE TABLE IF NOT EXISTS favorites (""title TEXT, ""url TEXT, ""UNIQUE(title)"");")
        dbcur.execute("CREATE TABLE IF NOT EXISTS search (""search TEXT"");")
        dbcur.execute("CREATE TABLE IF NOT EXISTS cache (""title TEXT, ""added TEXT, ""info TEXT, ""UNIQUE(title)"");")
        dbcon.commit()
    except BaseException as e: _log(u"localdb.create_tables ##Error: %s" % str(e))

def get_watched(title):
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT overlay FROM watched WHERE title = '%s'" % (title))
        found = dbcur.fetchone()
        if not found:
            return "6"
        else:
            return found[0]
    except BaseException as e: _log(u"localdb.get_watched ##Error: %s" % str(e))

def save_watched(title,overlay):
    try:
        dbcon = database.connect(addonCache)
        dbcon.text_factory = str
        dbcur = dbcon.cursor()
        dbcur.execute("INSERT OR REPLACE INTO watched Values (?, ?)", (title, overlay))
        dbcon.commit()
        dbcur.execute("VACUUM")
        xbmc.executebuiltin("Container.Refresh")
    except BaseException as e: _log(u"localdb.save_watched ##Error: %s" % str(e))
    
def save_fav(title, url):
    try:
        dbcon = database.connect(addonCache)
        dbcon.text_factory = str
        dbcur = dbcon.cursor()
        #dbcur.execute("DELETE FROM favorites WHERE url = '%s'" % (url))
        dbcur.execute("INSERT INTO favorites Values (?, ?)", (title, url))
        dbcur.execute("VACUUM")
        dbcon.commit()
        xbmc.executebuiltin('Notification(%s,%s)' % (__scriptname__, 'Salvat în Favorite'))
        xbmc.executebuiltin("Container.Refresh")
    except BaseException as e: _log(u"localdb.save_fav ##Error: %s" % str(e))

def get_fav(title=None):
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        if title:
            dbcur.execute("SELECT title FROM favorites WHERE title = '%s'" % (title))
            found = dbcur.fetchone()
        else:
            dbcur.execute("SELECT * FROM favorites")
            found = dbcur.fetchall()
        return found
    except BaseException as e: _log(u"localdb.get_fav ##Error: %s" % str(e))

def del_fav(title):
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM favorites WHERE title = '%s'" % (title))
        dbcur.execute("VACUUM")
        dbcon.commit()
        xbmc.executebuiltin('Notification(%s,%s)' % (__scriptname__, 'Șters din favorite'))
        xbmc.executebuiltin("Container.Refresh")
    except BaseException as e: _log(u"localdb.del_fav ##Error: %s" % str(e))

def save_search(cautare):
    try:
        dbcon = database.connect(addonCache)
        dbcon.text_factory = str
        dbcur = dbcon.cursor()
        dbcur.execute("INSERT INTO search (search) Values (?)", (cautare,))
        dbcon.commit()
    except BaseException as e: _log(u"localdb.save_search ##Error: %s" % str(e))

def del_search(text):
    try:
        dbcon = database.connect(addonCache)
        dbcon.text_factory = lambda x: unicode(x, "utf-8", "ignore")
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM search WHERE search = '%s'" % (text))
        dbcur.execute("VACUUM")
        dbcon.commit()
        xbmc.executebuiltin('Notification(%s,%s)' % (__scriptname__, 'Șters din Căutări'))
        xbmc.executebuiltin("Container.Refresh")
    except BaseException as e: _log(u"localdb.del_search ##Error: %s" % str(e))

def get_search():
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT search FROM search")
        found = dbcur.fetchall()
        return found
    except BaseException as e: _log("localdb.get_search ##Error: %s" % str(e))
    
def save_cache(title, info, force=None):
    try:
        t = int(time.time())
        dbcon = database.connect(addonCache)
        dbcon.text_factory = str
        dbcur = dbcon.cursor()
        if force:
            dbcur.execute("DELETE FROM cache WHERE title = '%s'" % (title))
            dbcur.execute("INSERT INTO cache Values (?, ?, ?)", (title, t, info))
            dbcur.execute("VACUUM")
            dbcon.commit()
        else:
            dbcur.execute("SELECT title FROM cache WHERE title = '%s'" % (title))
            entry = dbcur.fetchone()
            if entry is None:
                dbcur.execute("INSERT INTO cache Values (?, ?, ?)", (title, t, info))
                dbcon.commit()
    except BaseException as e: _log("localdb.save_cache ##Error: %s" % str(e))
    
def get_cache(title, timeout):
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM cache WHERE title = '%s'" % title)
        found = dbcur.fetchall()
        if found:
            t1 = int(found[0][1])
            t2 = int(time.time())
            update = (abs(t2 - t1) / 3600) >= int(timeout)
            if update == False:
                return found[0][2]
            else: return "1"
        else:
            return found
    except BaseException as e: _log("localdb.get_cache ##Error: %s" % str(e))

def get_fav_det(title):
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM cache WHERE title = '%s'" % title)
        found = dbcur.fetchall()
        return found
    except BaseException as e: _log("localdb.get_fav_det ##Error: %s" % str(e))

def h(text):
    return hashlib.md5(text).hexdigest()

def _log(msg):
    s = "%s" % (msg)
    xbmc.log(s.encode('utf-8'), level=xbmc.LOGDEBUG)
    #xbmc.log(s, level=xbmc.LOGNOTICE)
