﻿# -*- coding: UTF-8 -*-
import json
import xbmcaddon
import os
import localdb
import urllib
import urllib2

#getSetting = xbmcaddon.Addon().getSetting


def open_url(url,post=None):
    if post == None: req = urllib2.Request(url)
    else: req = urllib2.Request(url,post)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:10.0a1) Gecko/20111029 Firefox/10.0a1')
    req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    try: 
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
    except BaseException as e: localdb._log(u"open_url ERROR: %s - %s" % (str(url),str(e).encode('ascii','xmlcharrefreplace')))
    except urllib2.HTTPError, e: localdb._log(u"open_url HTTPERROR: %s - %s" % (str(url),str(e.code)))
    except urllib2.URLError, e: localdb._log(u"open_url URLERROR: %s - %s" % (str(url),str(e.reason)))
    except httplib.HTTPException, e: localdb._log(u"open_url HTTPException: %s" % (str(url)))

def searchmovielist(list,result):
    localdb._log(u"tmdb.searchmovielist list: %s" % list)
    for num, title, year, url, nume, imagine, numero in list:
        moviedata = searchmovie(title,year,nume, imagine, numero)
        if moviedata: result.append([num,moviedata,url,nume])
    #localdb._log(u"tmdb.searchmovielist result: %s" % result)

def searchmovie(t, y, nume, p, numero):
    listgenre = []
    listcast = []
    listcastr = []
    cast = ''
    genre = ''
    title = ''
    plot = ''
    tagline = ''
    director = ''
    writer = ''
    credits = ''
    poster = ''
    fanart = ''
    temptitle = ''
    originaltitle = ''
    language = ''
    unique = str(localdb.h(nume.encode('utf-8')))
    ##cached
    cached = localdb.get_cache(unique, 720)
    if cached and cached != "1":
        response = json.loads(cached)
        return response
    ##cached
    try:
        if 'serial' in nume.lower():
            jsonpage = open_url('https://api.themoviedb.org/3/search/tv?api_key=%s&query=%s&page=1&%s' % (tmdb_key(), urllib.quote_plus(t), (('first_air_date_year=' + y) if y else '')))
            jdef = json.loads(jsonpage)
        else:
            jsonpage = open_url('http://api.themoviedb.org/3/search/movie?api_key=%s&query=%s&year=%s' % (tmdb_key(), urllib.quote_plus(t), y))
            jdef = json.loads(jsonpage)
            if len(jdef['results']) < 1:
                jsonpage = open_url('http://api.themoviedb.org/3/search/movie?api_key=%s&query=%s' % (tmdb_key(), urllib.quote_plus(t)))
                jdef = json.loads(jsonpage)
                if len(jdef['results']) < 1:
                    jsonpage = open_url('http://api.themoviedb.org/3/search/movie?api_key=%s&query=%s' % (tmdb_key(), urllib.quote_plus(numero)))
                    jdef = json.loads(jsonpage)
    except: pass
    if jsonpage and len(jdef['results']) > 0:
        jdef = jdef['results'][0]
        try: jdef['title'] = jdef['title']
        except: jdef['title'] = jdef['name']
        try: jdef['original_title'] = jdef['original_title']
        except: jdef['original_title'] = jdef['original_name']
        try: jdef['release_date'] = jdef['release_date']
        except: jdef['release_date'] = jdef['first_air_date']
        if 'genre_ids' in jdef:
            genre_l = []
            for i in jdef['genre_ids']:
                genre_l.append(get_genre(str(i)))
            genre = ', '.join(str(x) for x in genre_l)
        else: genre = ''
        temptitle = jdef['title'].encode('ascii','ignore').replace(' ','')
        if temptitle <> '':
            if not title: title = jdef['title']
        temporiginaltitle = jdef['original_title'].encode('ascii','ignore')
        if temptitle == '': originaltitle = jdef['title']
        if temporiginaltitle == '': originaltitle = jdef['title']
        else: originaltitle = jdef['original_title']
        if not poster: poster = jdef['poster_path']
        if not fanart: fanart = jdef['backdrop_path']
        if not fanart: fanart = poster
        if fanart: fanart = 'http://image.tmdb.org/t/p/original%s' % (fanart)
        if poster: poster = 'http://image.tmdb.org/t/p/w500%s' % (poster)
        if not plot: plot = jdef['overview']
        if not tagline: tagline = ''
        try: language = jdef['original_language']
        except: pass
        trailer = ''
        try: year = jdef["release_date"].split("-")[0]
        except: year = ''
        try: studio = jdef['production_companies'][0]['name']
        except: studio = ''
        if cast == '':
            cast = []
            castr = []
        director = ''
        credits = ''
        writer = ''
        duration = ''
        info = {
            "genre": genre, 
            "year": year,
            "rating": jdef['vote_average'], 
            "cast": cast,
            "castandrole": castr,
            "director": director,
            "plot": plot,
            "plotoutline": plot,
            "title": title,
            "originaltitle": originaltitle,
            "duration": duration,
            "studio": studio,
            "tagline": tagline,
            "writer": writer,
            "premiered": jdef['release_date'],
            "code": jdef['id'],
            "credits": credits,
            "votes": jdef['vote_count'],
            "trailer": trailer,
            "audiolanguage": language
            }
        response = {
        "site_title" : nume,
        "label": '%s (%s)' % (title,year),
        "originallabel": '%s (%s)' % (originaltitle,year),		
        "poster": poster,
        "fanart_image": fanart,
        "imdbid": str(jdef['id']),
        "year": year,
        "unique": unique,
        "info": info
        }
        if cached == "1": localdb.save_cache(unique,json.dumps(response),"force")
        else: localdb.save_cache(unique,json.dumps(response))
        return response
    else:
        response = {
        "site_title" : nume,
        "label": '%s (%s)' % (t,y),
        "originallabel": '%s (%s)' % (t,y),
        "poster": p,
        "fanart_image": p,
        "imdbid": unique,
        "year": y,
        "unique": unique,
        "info": {'title': t, 'year': y}
        }
        if cached == "1": localdb.save_cache(unique,json.dumps(response),"force")
        else: localdb.save_cache(unique,json.dumps(response))
        return response

def tmdb_key():
    import base64
    return base64.urlsafe_b64decode('ODFlNjY4ZTdhMzdhM2Y2NDVhMWUyMDYzNjg3ZWQ3ZmQ=')

def get_genre(ids):
    genre = {"28": "Action",
            "12": "Adventure",
            "16": "Animation",
            "35": "Comedy",
            "80": "Crime",
            "99": "Documentary",
            "18": "Drama",
            "10751": "Family",
            "14": "Fantasy",
            "36": "History",
            "27": "Horror",
            "10402": "Music",
            "9648": "Mystery",
            "10749": "Romance",
            "878": "Science Fiction",
            "10770": "TV Movie",
            "53": "Thriller",
            "10752": "War",
            "37": "Western",
            "10769": "Foreign",
            "10759": "Action and Adventure",
            "10762": "Kids",
            "10763": "News",
            "10764": "Reality",
            "10765": "Sci-Fi and Fantasy",
            "10766": "Soap",
            "10767": "Talk",
            "10768": "War and Politics",
            }
    try: return genre[ids]
    except: return str(ids)
