# -*- coding: utf-8 -*-
import datetime
import os
import re
import sys
import urllib
import urllib2
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import threading
import json
try: import HTMLParser as htmlparser
except: import html.parser as htmlparser

try: import urlresolver
except: pass


settings = xbmcaddon.Addon(id='plugin.video.filmehdnet')
__addon__ = xbmcaddon.Addon()
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__cwd__        = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
__profile__    = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode("utf-8")
__resource__   = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'lib')).decode("utf-8")
__temp__       = xbmc.translatePath(os.path.join(__profile__, 'temp', '')).decode("utf-8")
search_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'search.png')
movies_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'movies.png')
next_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'next.png')
base_url = 'http://filmehd.net'
sys.path.append (__resource__)
import localdb
import tmdb
localdb.create_tables()

def ROOT():
    addDir('Recent Adăugate', 'http://filmehd.net/page/1', 6, movies_thumb, 'filme')
    addDir('Categorii', 'http://filmehd.net', 6, movies_thumb, 'categorii')
    addDir('După ani', 'http://filmehd.net/despre/', 6, movies_thumb, 'ani')
    addDir('Seriale', 'http://filmehd.net/seriale', 6, movies_thumb, 'filme')
    addDir('De colecție', 'http://filmehd.net/filme-vechi', 6, movies_thumb, 'filme')
    addDir('Căutare', base_url, 8, movies_thumb)
    addDir('Favorite', base_url, 7, movies_thumb)
    
def striphtml(data):
    p = re.compile(r'<.*?>')
    return p.sub('', data)
        

def cauta_dir(switch=None, word=None):
    if switch == "sterge":
        localdb.del_search(word)
    cautari = localdb.get_search()
    if cautari:
        addDir('Căutare Nouă', base_url, 3, movies_thumb)
        for cautare in cautari[::-1]:
            addDir(urllib.unquote_plus(cautare[0]), get_search_url(urllib.unquote_plus(cautare[0])), 6, search_thumb, cautare="1")
    else: cauta()
    
def cauta():
    keyboard = xbmc.Keyboard('')
    keyboard.doModal()
    if (keyboard.isConfirmed() == False): return
    search_string = keyboard.getText()
    if len(search_string) == 0: return
    else: localdb.save_search(urllib.quote_plus(search_string))
    
    parse_menu(get_search_url(search_string), 'filme')

def VIDEOS(sxurl, name, desc):
    desc = json.loads(desc)
    link = get_url(sxurl)
    liz = xbmcgui.ListItem(name, iconImage=desc['poster'], thumbnailImage=desc['fanart_image'])
    liz.setInfo(type="Video", infoLabels=desc['info'])
    regex_lnk = '''<iframe(?:.+?)?src=['"]((?:[htt]|[//]).+?)['"]'''
    match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
    hmf = urlresolver.HostedMediaFile(url=match_lnk[0], include_disabled=True, include_universal=False) 
    xbmc.Player ().play(hmf.resolve(), liz, False)
    
def get_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False

def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext


def get_search_url(keyword):
    url = 'http://filmehd.net/?s=' + urllib.quote_plus(keyword)
    return url
  
def get_search(url):
    
    params = {}
    req = urllib2.Request(url, urllib.urlencode(params))
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Content-type', 'application/x-www-form-urlencoded')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False

def getKey(item):
    return item[0]

def parse_menu(url, meniu, desc):
    match = []
    if url == None:
        url = 'http://filmehd.net'
    link = get_url(url)
    if meniu == 'ani':
        an = datetime.datetime.now().year
        while (an > 1929):
            legatura = url + '/despre/filme-' + str(an)
            addDir(str(an), legatura, 6, movies_thumb, 'filme')
            an -= 1
    if meniu == 'filme':
        match = re.compile('class="imgleft">.+?href="(.+?)".+?src="(.+?)".+?href.+?>(.+?)<', re.DOTALL).findall(link)
        order = 0
        sendlist = []
        threads = []
        result = []
        for legatura, imagine, nume in match:
            try: year = (re.search('(\(\d+\))', nume)).group(1)
            except: year = ""
            try:
                numeall = nume.split('&#8211;')
                numeen = numeall[0].replace("&#8217;","'").replace("&#038;", "&")
                numero = numeall[1].replace("&#8217;","'").replace("&#038;", "&")
                numero, garbage = xbmc.getCleanMovieTitle(numero)
            except:
                numeen = numero = nume.replace("&#8217;","'").replace("&#038;", "&")
            if not re.search('(\(\d+\))', numeen):
                numeen = '%s %s' % (numeen,year)
            titlu, year = xbmc.getCleanMovieTitle(numeen)
            order += 1
            nume = htmlparser.HTMLParser().unescape(nume.decode('utf-8'))
            sendlist.append([order, titlu, year, legatura, nume, imagine, numero])
        target = tmdb.searchmovielist
        chunks = [sendlist[x:x + 5] for x in xrange(0, len(sendlist), 5)]
        for i in range(len(chunks)): threads.append(threading.Thread(name='listmovies' + str(i), target=target, args=(chunks[i], result,)))
        [i.start() for i in threads]
        [i.join() for i in threads]
        result = sorted(result, key=getKey)
        for id, lists, m_url, nume in result:
            addDir(nume, m_url, 6, lists['poster'], 'linkuri', lists)
    elif meniu == 'linkuri':
        regex_lnk = '''(?:id="tabs_desc_.+?_(.+?)".+?)?(?:<center>(.+?)</center>.+?)?data-src=['"]((?:[htt]|[//]).+?)['"]'''
        regex_infos = '''Descriere film.+?p>(.+?)</p'''
        match_lnk = re.findall(regex_lnk, link, re.IGNORECASE | re.DOTALL)
        match_nfo = re.findall(regex_infos, link, re.IGNORECASE | re.DOTALL)
        desc = json.loads(desc)
        try: desc['info']['plot'] = desc['info']['plot']
        except: desc['info']['plot'] = striphtml(re.compile(regex_infos, re.IGNORECASE | re.DOTALL).findall(link)[0]).strip()
        for server, name, legatura in match_lnk:
            if server: addDir('Server %s' % server,legatura, 55, '', 'nimic')
            if not legatura.startswith('http'):
                legatura = '%s%s' % (base_url, legatura.replace('&amp;', '&'))
                name = striphtml(name)
                if name: 
                    addLink(name, legatura, movies_thumb, name, descriere=json.dumps(desc))
                    
    elif meniu == 'categorii':
        regex_menu = '''<ul[\s]+class="sub-menu(.+?)</li></ul></div> '''
        regex_submenu = '''<li.+?a href="(.+?)">(.+?)<'''
        for meniu in re.compile(regex_menu, re.IGNORECASE | re.DOTALL).findall(link):
            match = re.compile(regex_submenu, re.DOTALL).findall(meniu)
            for legatura, nume in match:
                nume = htmlparser.HTMLParser().unescape(nume.decode('utf-8'))
                addDir(nume, legatura, 6, movies_thumb, 'filme')
        more_cat = [('Romanesti', 'http://filmehd.net/despre/filme-romanesti'),
            ('Noi', 'http://filmehd.net/despre/filme-romanesti')]
        for nume, legatura in more_cat:
            addDir(nume, legatura, 6, movies_thumb, 'filme')
    match = re.compile('class=\'wp-pagenavi', re.IGNORECASE).findall(link)
    if len(match) > 0:
        new = re.compile('/(\d+)').findall(url)
        if new:
            nexturl = re.sub('/(\d+)', '/' + str(int(new[0]) + 1), url)
            print "NEXT " + nexturl
            addNext('Next', nexturl, 6, next_thumb, 'filme')
        else:
            new = re.compile('page/(\d+)/').findall(url)
            if new:
                re.sub('page/\d+', 'page/' + (str(int(new[0]) + 1)), url)
            else:
                nexturl = url + '/page/2/'
            addNext('Next', nexturl, 6, next_thumb, 'filme')
    
def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
                                
    return param

def addLink(name, url, iconimage, movie_name, mode=9, descriere=None):
    ok = True
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&mname=" + urllib.quote_plus(movie_name)
    if descriere != None:
        descriere = json.loads(descriere)
        liz = xbmcgui.ListItem(name, iconImage=descriere['poster'], thumbnailImage=descriere['fanart_image'])
        liz.setInfo(type="Video", infoLabels=descriere['info'])
        u += "&desc=" + urllib.quote_plus(json.dumps(descriere))
    else:
        liz.setInfo(type="Video", infoLabels={"Title": movie_name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok

def addNext(name, page, mode, iconimage, meniu=None):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(page) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def addDir(name, url, mode, iconimage, meniu=None, descriere=None, cautare=None, fav=None):
    ok = True
    cm = []
    if cautare:
        cm.append(('Șterge din Căutări', 'RunPlugin(%s?mode=8&url=sterge&name=%s)' %
                                (sys.argv[0],urllib.quote_plus(name.encode('utf-8')))))
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + name
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    if descriere != None:
            infos = descriere['info']
            #with open('/storage/.kodi/temp/files.py', 'wb') as f: f.write(repr(infos))
            playcount = 0
            playcount = localdb.get_watched(descriere['unique'])
            try: 
                if infos['audiolanguage'] != '':
                    name += ' [COLOR red]%s[/COLOR]' % infos['audiolanguage']
            except: pass
            if playcount == '7': 
                cm.append(('Marchează ca nevizionat', 'RunPlugin(%s?mode=11&url=%s&watched=6)' %
                                (sys.argv[0],descriere['unique'])))
                infos.update({'playcount': 1, 'overlay': int(playcount)})
            else: 
                cm.append(('Marchează ca vizionat', 'RunPlugin(%s?mode=11&url=%s&watched=7)' %
                                (sys.argv[0],descriere['unique'])))
            if favorites("check", descriere['unique'], url):
                if not fav: name += ' - [COLOR yellow]FAV[/COLOR]'
                cm.append(('Șterge de la Favorite', 'RunPlugin(%s?mode=7&url=%s&action=delete)' % (sys.argv[0], descriere['unique'])))
            else: cm.append(('Salvează la Favorite', 'RunPlugin(%s?mode=7&url=%s&name=%s&action=save)' %
                            (sys.argv[0], urllib.quote_plus(url), descriere['unique'])))
            liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
            liz.setProperty('fanart_image',descriere['fanart_image'])
            liz.setInfo(type="Video", infoLabels=infos)
            u += "&desc=" + urllib.quote_plus(json.dumps(descriere))
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.addContextMenuItems(cm, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def favorites(action, title, url):
    if action == "save":
        localdb.save_fav(title, url)
    elif action == "check":
        check = localdb.get_fav(title)
        if check: return True
        else: return False
    elif action == "delete":
        localdb.del_fav(url)
    else:
        favs = localdb.get_fav()
        if favs:
            for fav in favs[::-1]:
                response = localdb.get_fav_det(fav[0])
                if len(response) > 0:
                    data = json.loads(response[0][2])
                    addDir(data['site_title'], fav[1], 6, data['fanart_image'], 'linkuri', descriere=data, fav="1")

def playcount_movies(title, overlay):
    localdb.save_watched(title, overlay)
              
params = get_params()

try: url = urllib.unquote_plus(params["url"])
except: url = None
try: name = urllib.unquote_plus(params["name"])
except: name = None
try: mname = urllib.unquote_plus(params["mname"])
except: mname = None
try: desc = urllib.unquote_plus(params["desc"])
except: desc = None
try: mode = int(params["mode"])
except: mode = None
try: meniu = urllib.unquote_plus(params["meniu"])
except: meniu = None
try: action = urllib.unquote_plus(params["action"])
except: action = None
try: watched = urllib.unquote_plus(params["watched"])
except: watched = None

if mode == None or url == None or len(url) < 1: ROOT()
elif mode == 3: cauta()
elif mode == 6: parse_menu(url, meniu, desc)
elif mode == 7: favorites(action, name, url)
elif mode == 8: cauta_dir(url, name)
elif mode == 9: VIDEOS(url, name, desc)
elif mode == 11: playcount_movies(url, watched)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
