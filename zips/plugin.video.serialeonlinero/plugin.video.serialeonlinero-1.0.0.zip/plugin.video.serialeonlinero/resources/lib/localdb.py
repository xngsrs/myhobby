﻿# -*- coding: UTF-8 -*-

import xbmcaddon,xbmc,os
try: from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database

__addon__ = xbmcaddon.Addon()
__scriptname__ = __addon__.getAddonInfo('name')
dataPath		= xbmc.translatePath(__addon__.getAddonInfo("profile")).decode("utf-8")
addonCache		= os.path.join(dataPath,'cache.db')
language		= __addon__.getLocalizedString

def create_tables():
    try:
        import xbmcvfs
        if xbmcvfs.exists(dataPath) == 0: xbmcvfs.mkdir(dataPath)
    except BaseException as e: _log(u"localdb.create_tables makedir ##Error: %s" % str(e))
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS watched (""title TEXT, ""label TEXT, ""overlay TEXT, ""UNIQUE(title)"");")
        dbcur.execute("CREATE TABLE IF NOT EXISTS favorites (""url TEXT, ""title TEXT, ""info TEXT, ""tip TEXT, ""UNIQUE(url)"");")
        dbcur.execute("CREATE TABLE IF NOT EXISTS search (""search TEXT"");")
        dbcon.commit()
    except BaseException as e: _log(u"localdb.create_tables ##Error: %s" % str(e))

def get_watched(title,label,overlay):
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT overlay FROM watched WHERE title = '%s'" % (title))
        found = dbcur.fetchone()
        if not found:
            save_watched(title,label,overlay)
            #_log(u"returned overlay: %s" % str(overlay))
            return overlay
        else:
            #_log(u"returned found: %s" % str(found[0]))
            return found[0]
    except BaseException as e: _log(u"localdb.get_watched ##Error: %s" % str(e))

def save_watched(title,label,overlay):
    try:
        dbcon = database.connect(addonCache)
        dbcon.text_factory = str
        dbcur = dbcon.cursor()
        dbcur.execute("INSERT INTO watched Values (?, ?, ?)", (title, label, overlay))
        dbcon.commit()
    except BaseException as e: _log(u"localdb.save_watched ##Error: %s" % str(e))

def update_watched(title, label, overlay):
    try:
        dbcon = database.connect(addonCache)
        dbcon.text_factory = str
        dbcon.execute("UPDATE watched SET overlay = '%s' WHERE title = '%s'" % (overlay, title))
        dbcon.commit()
        xbmc.executebuiltin("Container.Refresh")
    except BaseException as e: _log(u"localdb.update_watched ##Error: %s" % str(e))

def delete_watched():
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM watched")
        dbcur.execute("VACUUM")
        dbcon.commit()
    except BaseException as e: _log(u"localdb.delete_watched ##Error: %s" % str(e))
    
def save_fav(title, url, descriere, tip):
    try:
        dbcon = database.connect(addonCache)
        dbcon.text_factory = lambda x: unicode(x, "utf-8", "ignore")
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM favorites WHERE url = '%s'" % (url))
        dbcur.execute("INSERT INTO favorites Values (?, ?, ?, ?)", (url, title, descriere, tip))
        dbcur.execute("VACUUM")
        dbcon.commit()
        xbmc.executebuiltin('Notification(%s,%s)' % (__scriptname__, 'Salvat în Favorite'))
        xbmc.executebuiltin("Container.Refresh")
    except BaseException as e: _log(u"localdb.save_fav ##Error: %s" % str(e))

def get_fav(url=None):
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        if url:
            dbcur.execute("SELECT title FROM favorites WHERE url = '%s'" % (url))
        else:
            dbcur.execute("SELECT * FROM favorites")
        found = dbcur.fetchall()
        return found
    except BaseException as e: _log(u"localdb.get_fav ##Error: %s" % str(e))

def del_fav(url):
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM favorites WHERE url = '%s'" % (url))
        dbcur.execute("VACUUM")
        dbcon.commit()
        xbmc.executebuiltin('Notification(%s,%s)' % (__scriptname__, 'Șters din favorite'))
        xbmc.executebuiltin("Container.Refresh")
    except BaseException as e: _log(u"localdb.del_fav ##Error: %s" % str(e))

def save_search(cautare):
    try:
        dbcon = database.connect(addonCache)
        dbcon.text_factory = str
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM search WHERE search = '%s'" % (cautare))
        dbcur.execute("INSERT INTO search (search) Values (?)", (cautare,))
        dbcur.execute("VACUUM")
        dbcon.commit()
    except BaseException as e: _log(u"localdb.save_search ##Error: %s" % str(e))

def del_search(text):
    try:
        dbcon = database.connect(addonCache)
        dbcon.text_factory = lambda x: unicode(x, "utf-8", "ignore")
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM search WHERE search = '%s'" % (text))
        dbcur.execute("VACUUM")
        dbcon.commit()
        xbmc.executebuiltin('Notification(%s,%s)' % (__scriptname__, 'Șters din Căutări'))
        xbmc.executebuiltin("Container.Refresh")
    except BaseException as e: _log(u"localdb.del_search ##Error: %s" % str(e))

def get_search():
    try:
        dbcon = database.connect(addonCache)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT search FROM search")
        found = dbcur.fetchall()
        return found
    except BaseException as e: _log(u"localdb.get_search ##Error: %s" % str(e))

def _log(msg):
    s = u"%s" % (msg)
    #xbmc.log(s.encode('utf-8'), level=xbmc.LOGDEBUG)
    xbmc.log(s.encode('utf-8'), level=xbmc.LOGNOTICE)
