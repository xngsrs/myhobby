# -*- coding: utf-8 -*-
import datetime
import os
import re
import sys
import urllib
import urllib2
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import json
try: import HTMLParser as htmlparser
except: import html.parser as htmlparser
from resources.lib import localdb

settings = xbmcaddon.Addon(id='plugin.video.serialeonlinero')
__addon__ = xbmcaddon.Addon()
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__cwd__        = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
__profile__    = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode("utf-8")
__resource__   = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'lib')).decode("utf-8")
__temp__       = xbmc.translatePath(os.path.join(__profile__, 'temp', '')).decode("utf-8")
search_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'search.png')
movies_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'movies.png')
next_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'next.png')
base_url = 'https://www.serialeonline.ro'

localdb.create_tables()

def ROOT():
    addDir('Seriale Românești', '%s/romanesti/' % base_url, 6, movies_thumb, 'recente')
    addDir('Seriale Americane', '%s/americane/' % base_url, 6, movies_thumb, 'recente')
    addDir('Seriale Turcești', '%s/turcesti/' % base_url, 6, movies_thumb, 'recente')
    addDir('Alte Seriale', '%s/alte-seriale/' % base_url, 6, movies_thumb, 'recente')
    addDir('Publicate recent', '%s' % base_url, 6, movies_thumb, 'ultimele')
    addDir('Căutare', base_url, 8, search_thumb)
    addDir('Favorite', base_url, 7, movies_thumb)
    
def striphtml(data):
    p = re.compile('<.*?>')
    cleanp = re.sub(p, '', data)
    return cleanp
            
 
def video_list(url, name, iconimage=None, descriere=None):
    link = get_search(url)
    thumb = iconimage
    links = re.search('= \[(.+?)\]', link, re.IGNORECASE | re.MULTILINE | re.DOTALL).group(1).replace('\\', '')
    #exit()
    regex_lnk = '''iframe.+?src="((?:[htt]|[//]).+?)"'''
    match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(links)
    for link1 in match_lnk:
            link1 = re.sub('(https://www.serialeonline.ro/frame.php\?[\w\d]=(?:[\w\d]&[\w\d]=|))', '', link1)
            if link1.startswith("//"):
                link1 = 'http:' + link1 #//ok.ru fix
            parsed_url1 = urlparse.urlparse(link1)
            if parsed_url1.scheme:
                import urlresolver
                hmf = urlresolver.HostedMediaFile(url=link1, include_disabled=True, include_universal=False)
                if hmf.valid_url() == True:
                    host = link1.split('/')[2].replace('www.', '').capitalize()
                    addLink(host, link1, thumb, name, 10, descriere)

            
def cauta_dir(switch=None, word=None):
    if switch == "sterge":
        localdb.del_search(word)
    elif switch == "edit":
        key = cauta(word)
    cautari = localdb.get_search()
    if cautari:
        addDir('Căutare Nouă', base_url, 3, search_thumb)
        for cautare in cautari[::-1]:
            addDir(urllib.unquote_plus(cautare[0]), get_search_url(urllib.unquote_plus(cautare[0])), 6, search_thumb, 'cautare', cautare="1")
    else: cauta()
    
def cauta(word=None):
    keyboard = xbmc.Keyboard('')
    if word: keyboard.setDefault(word)
    keyboard.doModal()
    if (keyboard.isConfirmed() == False): return
    search_string = keyboard.getText()
    if len(search_string) == 0: return
    else:
        if word: 
            localdb.save_search(urllib.quote_plus(search_string))
            return get_search_url(search_string)
        else:
            localdb.save_search(urllib.quote_plus(search_string))
            parse_menu(get_search_url(search_string), 'cautare')
    
def video_play(play_url, nume, imagine, descriere):
    if imagine:
        icon = imagine
        thumb = imagine
    else:
        icon = "DefaultFolder.png"
        thumb = movies_thumb
    liz = xbmcgui.ListItem(nume, iconImage=icon, thumbnailImage=thumb) 
    try: infos = json.loads(descriere); liz.setInfo(type="Video", infoLabels=infos); liz.setArt({'thumb':infos['Poster'], 'fanart':infos['Poster']})
    except: liz.setInfo(type="Video", infoLabels={"Title": nume, "Plot": descriere, "Poster": imagine})
    import urlresolver
    hmf = urlresolver.HostedMediaFile(url=play_url, include_disabled=True, include_universal=False) 
    xbmc.Player().play(hmf.resolve(), liz, False)
    
def get_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link
    
def get_search_url(keyword):
    url = base_url + '/?s=' + urllib.quote_plus(keyword)
    return url
  
def get_search(url):
    
    params = {}
    req = urllib2.Request(url, urllib.urlencode(params))
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Content-type', 'application/x-www-form-urlencoded')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False

def favorites(action, title, url, descriere, tip):
    if action == "save":
        localdb.save_fav(title, url, descriere, tip)
    elif action == "check":
        check = localdb.get_fav(url)
        if check: return True
        else: return False
    elif action == "delete":
        localdb.del_fav(url)
    else:
        favs = localdb.get_fav()
        if favs:
            for fav in favs[::-1]:
                data = json.loads(fav[2])
                if fav[3] == "None": addDir(data['Title'], fav[0], 5, data['Poster'], descriere=data)
                else: addDir(data['Title'], fav[0], 6, data['Poster'], fav[3], descriere=data)

def parse_menu(url, meniu, descriere=None):
    link = get_url(url)
    if meniu == 'recente':
        regex_all = '''category">(.+?)</div>'''
        regex = '''href=['"](.+?)['"].+?srcset=['"](.+?)['"].+?title.+?>(.+?)<'''
        match = re.compile(regex_all, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
        if len(match) > 0:
            for serial in match:
                date = re.compile(regex, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(serial)
                for link, image, name in date:
                    image = image.split(',')[-1].split(' ')[-2]
                    addDir(name, link, 6, image, 'episoade', name)
    elif meniu == 'episoade':
        regex_all = '''episode-list"(.+?)(?:</div>){2}'''
        regex = '''href=['"](.+?)['"]>(.+?)<'''
        match = re.compile(regex_all, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
        if len(match) > 0:
            for episod in match:
                date = re.compile(regex, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(episod)
                for link, name in date:
                    addDir(name, link, 5, movies_thumb, descriere=descriere)
    elif meniu == 'ultimele':
        regex_all = '''recent_entries(.+?)</ul'''
        regex = '''href=["'](.+?)["']>(.+?)<'''
        match = re.compile(regex_all, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
        if len(match) > 0:
            date = re.compile(regex, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(match[0])
            for link, name in date:
                addDir(name, link, 5, movies_thumb)
    elif meniu == 'cautare':
        regex = '''"featured-image".+?src=['"](.+?)["'].+?href=['"](.+?)['"].+?>(.+?)<'''
        date = re.compile(regex, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link)
        for image, legatura, name in date:
            addDir(name, legatura, 5, image)
    match = re.compile('default-wp-page', re.IGNORECASE).findall(link)
    if len(match) > 0:
        if '/page/' in url:
            new = re.compile('/page/(\d+)').findall(url)
            nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
        else:
            nexturl = re.sub('(https://www.serialeonline.ro/)', r'\1page/2/', url)
        addNext('Next', nexturl, 6, next_thumb, meniu)

def playcount_movies(title,label, overlay):
    localdb.update_watched(title,label,overlay)

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
                                
    return param

def addLink(name, url, iconimage, movie_name, mode=4, descriere=None):
    ok = True
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&imagine=" + urllib.quote_plus(iconimage) + "&nume=" + urllib.quote_plus(movie_name)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    if descriere != None:
        try: infos = json.loads(descriere); liz.setInfo(type="Video", infoLabels=infos); liz.setArt({'thumb':infos['Poster'], 'fanart':infos['Poster']})
        except: liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": descriere, "Poster": iconimage})
        u += "&descriere=" + urllib.quote_plus(descriere)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": movie_name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
    return ok

def addNext(name, page, mode, iconimage, meniu=None, descriere=None):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(page) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    if descriere != None:
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": descriere})
        u += "&descriere=" + urllib.quote_plus(descriere)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def addDir(name, url, mode, iconimage, meniu=None, descriere=None, cautare=None):
    try: name = htmlparser.HTMLParser().unescape(name.decode('utf-8'))
    except: name = name
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name.encode('utf-8')) + "&imagine=" + urllib.quote_plus(iconimage)
    ok = True
    context = []
    if cautare:
        context.append(('Editează și caută iar', 'RunPlugin(%s?mode=8&url=edit&name=%s)' %
                                (sys.argv[0],urllib.quote_plus(name.encode('utf-8')))))
        context.append(('Șterge din Căutări', 'RunPlugin(%s?mode=8&url=sterge&name=%s)' %
                                (sys.argv[0],urllib.quote_plus(name.encode('utf-8')))))
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    if meniu != None:
        u += "&meniu=" + urllib.quote_plus(meniu)
    if descriere != None:
        #with open(xbmc.translatePath(os.path.join('special://temp', 'files.py')), 'wb') as f: f.write(repr(descriere))
        if descriere:
            try:
                infos = json.loads(descriere)
                liz.setArt({'thumb':infos['Poster'], 'fanart':infos['Poster']})
            except:
                infos = {'Title': name,'Plot': name,'Poster': iconimage}
                liz.setArt({'thumb':iconimage, 'fanart':iconimage})
            infos.update({'Title': name})
            playcount = 0
            playcount = localdb.get_watched(infos['Title'], name, '6')
            if playcount == '7': 
                context.append(('Marchează ca nevizionat', 'RunPlugin(%s?mode=11&url=%s&name=%s&watched=6&nume=%s)' %
                                (sys.argv[0],url,urllib.quote_plus(infos['Title'].encode('utf-8')),urllib.quote_plus(infos['Title'].encode('utf-8')))))
                infos.update({'playcount': 1, 'overlay': playcount})
            else: 
                context.append(('Marchează ca vizionat', 'RunPlugin(%s?mode=11&url=%s&name=%s&watched=7&nume=%s)' %
                                (sys.argv[0],url,urllib.quote_plus(infos['Title'].encode('utf-8')),urllib.quote_plus(infos['Title'].encode('utf-8')))))
            liz.setInfo(type="Video", infoLabels=infos)
            if favorites("check", '', url, '', ''):
                context.append(('Șterge de la Favorite', 'RunPlugin(%s?mode=7&url=%s&action=delete)' %
                            (sys.argv[0],url)))
            else:
                context.append(('Salvează la Favorite', 'RunPlugin(%s?mode=7&url=%s&name=%s&descriere=%s&action=save&meniu=%s)' %
                            (sys.argv[0],url,urllib.quote_plus(name.encode('utf-8')),urllib.quote_plus(json.dumps(infos)), meniu)))
        #except: liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": descriere, "Poster": iconimage})
        try: infos = json.dumps(infos)
        except: infos = infos
        u += "&descriere=" + urllib.quote_plus(infos)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.addContextMenuItems(context, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok
              
params = get_params()

try: url = urllib.unquote_plus(params["url"])
except: url = None
try: imagine = urllib.unquote_plus(params["imagine"])
except: imagine = None
try: nume = urllib.unquote_plus(params["nume"])
except: nume = None
try: name = urllib.unquote_plus(params["name"])
except: name = None
try: descriere = urllib.unquote_plus(params["descriere"])
except: descriere = None
try: mode = int(params["mode"])
except: mode = None
try: meniu = urllib.unquote_plus(params["meniu"])
except: meniu = None
try: watched = urllib.unquote_plus(params["watched"])
except: watched = None
try: action = urllib.unquote_plus(params["action"])
except: action = None

if mode == None or url == None or len(url) < 1: ROOT()
elif mode == 2: cauta_film(url)
elif mode == 3: cauta()
elif mode == 5: video_list(url, name, imagine, descriere)
elif mode == 6: parse_menu(url, meniu, descriere)
elif mode == 7: favorites(action, name, url, descriere, meniu)
elif mode == 4: VIDEO(url, name)
elif mode == 8: cauta_dir(url, name)
elif mode == 10: video_play(url, nume, imagine, descriere)
elif mode == 11: playcount_movies(name, nume, watched)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
