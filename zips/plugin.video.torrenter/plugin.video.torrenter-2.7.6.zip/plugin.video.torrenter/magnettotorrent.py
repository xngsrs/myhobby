## -*- coding: utf-8 -*-

from python_libtorrent import get_libtorrent
import time
import os
import hashlib
import xbmcgui
import xbmcvfs
from functions import log

def md5(string):
        hasher = hashlib.md5()
        try:
            hasher.update(string)
        except:
            hasher.update(string.encode('utf-8', 'ignore'))
        return hasher.hexdigest()

def mag2tor(storageDirectory, mag_link):
    libtorrent = get_libtorrent()
    sess = libtorrent.session()
    sess.set_alert_mask(libtorrent.alert.category_t.error_notification | libtorrent.alert.category_t.status_notification | libtorrent.alert.category_t.storage_notification)
    #sess.set_alert_mask(lt.alert.category_t.all_categories)
    sess.start_lsd()
    sess.start_upnp()
    sess.start_natpmp()

    # Session settings
    try:
        sess_settings = sess.get_settings()
        #
        sess_settings['announce_to_all_tiers'] = True
        sess_settings['announce_to_all_trackers'] = True
        sess_settings['peer_connect_timeout'] = 2
        sess_settings['rate_limit_ip_overhead'] = True
        sess_settings['request_timeout'] = 1
        sess_settings['torrent_connect_boost'] = 50
        sess_settings['user_agent'] = ''
        sess_settings['connections_limit'] = 200
        sess_settings['unchoke_slots_limit'] = 10
        sess_settings['connection_speed'] = 200
        sess_settings['file_pool_size'] = 40

        #sess_settings['cache_size'] = 0
        #sess_settings['use_read_cache'] = False

    except:
        #0.15 compatibility
        log('[initsess]: sess settings 0.15 compatibility')
        sess_settings = sess.settings()

        sess_settings.announce_to_all_tiers = True
        sess_settings.announce_to_all_trackers = True
        sess_settings.connection_speed = 100
        sess_settings.peer_connect_timeout = 2
        sess_settings.rate_limit_ip_overhead = True
        sess_settings.request_timeout = 1
        sess_settings.torrent_connect_boost = 100
        sess_settings.user_agent = ''
    #
    sess.set_settings(sess_settings)
    #log(storageDirectory)
    prms = {
        'save_path':storageDirectory,
        # 'storage_mode':libtorrent.storage_mode_t(2),
        'paused':False,
        'auto_managed':False,
        'upload_mode':True,
    }
    progressBar = xbmcgui.DialogProgress()
    progressBar.create('Please Wait', 'Magnet-link is converting')
    torr = libtorrent.add_magnet_uri(sess, mag_link, prms)
    dots = 0
    while not torr.has_metadata():
        progressBar.update(dots, 'Please Wait', 'Magnet-link is converting'+'.' * (dots % 4), ' ')
        dots += 1
        time.sleep(1)
        if progressBar.iscanceled():
            progressBar.update(0)
            progressBar.close()
            return
    sess.pause()
    progressBar.update(dots, 'Please Wait', 'Geting magnet info'+'.' * (dots % 4), ' ')
    if progressBar.iscanceled():
        progressBar.update(0)
        progressBar.close()
        return
    tinf = torr.get_torrent_info()
    torrpath = os.path.join(storageDirectory, 'torrents') + os.sep
    if not xbmcvfs.exists(torrpath):
        xbmcvfs.mkdirs(torrpath)
    torrname = torrpath + md5(mag_link) + '.torrent'
    progressBar.update(dots, 'Please Wait', 'Writing data'+'.' * (dots % 4), ' ')
    f = open(torrname, 'wb')
    f.write(libtorrent.bencode(
        libtorrent.create_torrent(tinf).generate()))
    f.close()
    sess.remove_torrent(torr)
    dots = 100
    progressBar.update(0)
    progressBar.close()
    #log(torrname)
    return torrname
