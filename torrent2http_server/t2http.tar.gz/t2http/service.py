# -*- coding: utf-8 -*-

import sys, time

from lib.torrent2http.remote.server import Server
from lib.torrent2http.remote.log import debug


def main():
	debug('Starting server')
	
	server = Server()
	server.loop()
	
	try:
		while True:
			server.loop()
			time.sleep(10)
			
	except KeyboardInterrupt:
		# Exit on ctrl+C
		debug('Exit')
		server.stop()
		sys.exit()
		
	debug('Exit')
	server.stop()

main()
