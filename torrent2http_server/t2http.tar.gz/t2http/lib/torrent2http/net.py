# -*- coding: utf-8 -*-

import os
import time
import re
import base64
import tempfile

import requests
try:
    import urllib2
    py3 = False
except ImportError:
    py3 = True

class HTTP:
    def __init__(self):
        self._dirname = tempfile.gettempdir()
        for subdir in ('xbmcup', 'script.module.libtorrent'):
            self._dirname = os.path.join(self._dirname, subdir)
            if not os.path.exists(self._dirname):
                os.mkdir(self._dirname)

    def fetch(self, request, **kwargs):
        self.request =  request
        self.dest = kwargs.get('download')
        s = requests.Session()
        r = s.head(self.request, allow_redirects=False)
        if 'location' in r.headers:
            r = s.get(r.headers.get('location'))

        bs = 1024 * 8
        size = -1
        read = 0
        name = "Torrent2http.zip"
        fd = open(self.dest, 'wb')
        
        with open(self.dest, 'wb') as fd:
            for buf in r.iter_content(chunk_size=bs):
                if buf:
                    fd.write(buf)

        return True  

    def _progress(self, read, size, name):
        res = []
        res2 = ''
        if size < 0:
            res.append(1)
        else:
            res.append(int(float(read) / (float(size) / 100.0)))
        if name:
            res2 += u'File: %s \n' % name
        if size != -1:
            res2 += u'Size: %s \n' % self._human(size)
        res2 += u'Load: %s' % self._human(read)
        res.append(res2)
        return res

    def _human(self, size):
        power = 2**10
        n = 0
        power_labels = {0 : 'B', 1: 'KB', 2: 'MB', 3: 'GB', 4: 'TB'}
        while size > power:
            size /= power
            n += 1
        return '{:.2f}{}'.format(size, power_labels[n])
