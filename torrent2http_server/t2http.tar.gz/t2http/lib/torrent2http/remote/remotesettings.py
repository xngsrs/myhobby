﻿import os
from . import filesystem

abs_path = os.path.abspath(os.getcwd())
_bin_dir = os.path.join(abs_path, 'bin')
_ADDON_NAME = 'script.module.torrent2http'
_addon = ''


class Settings:
    def __init__(self, path=None):
        
        self.mrsp = True
        
        self.role = 'server'
        
        self.mrsprole = True
        
        #you must change this path to where you want do download torrents
        self.storage_path = os.path.join(abs_path, 'Torrents')
        self.remote_host = self.get_ip()

        self.storage_path  = filesystem.abspath(self.storage_path)
        
        self.remote_port = 2830

        self.binaries_path = _bin_dir
    
    def get_ip(self):
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # doesn't even have to be reachable
            s.connect(('10.255.255.255', 1))
            IP = s.getsockname()[0]
        except Exception:
            IP = '127.0.0.1'
        finally:
            s.close()
        return IP
