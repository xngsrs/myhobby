#import sys
import os
import time
from .net import HTTP
try:
    import urllib2
    py3 = False
except ImportError:
    py3 = True

__libbaseurl__ = "https://github.com/xngsrs/script.module.torrent2http/raw/master/bin"
#__settings__ = xbmcaddon.Addon(id='script.module.torrent2http')
#__version__ = __settings__.getAddonInfo('version')
#__plugin__ = __settings__.getAddonInfo('name') + " v." + __version__

def get_libname(platform):
    return ["torrent2http" + (".exe" if 'windows' in platform else "")]

#def getSettingAsBool(setting):
    #return __settings__.getSetting(setting).lower() == "true"

class LibraryManager():
    def __init__(self, dest_path, platform):
        self.dest_path = dest_path
        self.platform = platform

    def check_update(self):
        need_update=False
        for libname in get_libname(self.platform):
            self.libpath = os.path.join(self.dest_path, libname)
            self.sizepath=os.path.join(self.dest_path, libname+'.size.txt')
            size=str(os.path.getsize(self.libpath))
            size_old=open( self.sizepath, "r" ).read()
            if size_old!=size:
                need_update=True
        return need_update

    def update(self):
        if self.check_update():
            for libname in get_libname(self.platform):
                self.libpath = os.path.join(self.dest_path, libname)
                os.remove(self.libpath)
            self.download()

    def download(self):
        from . import patoolib
        if not os.path.exists(self.dest_path):
            os.mkdir(self.dest_path)
        for libname in get_libname(self.platform):
            dest = os.path.join(self.dest_path, libname)
            print("try to fetch %s" % libname)
            url = "%s/%s/%s.zip" % (__libbaseurl__, self.platform, libname)
            try:
                self.http = HTTP()
                self.http.fetch(url, download=dest + ".zip", progress=True)
                print("%s -> %s" % (url, dest))
                time.sleep(2)
                patoolib.extract_archive('%s.zip' % dest, outdir=self.dest_path)
                os.remove(dest + ".zip")
            except BaseException as e:
                print(e)
        return True
